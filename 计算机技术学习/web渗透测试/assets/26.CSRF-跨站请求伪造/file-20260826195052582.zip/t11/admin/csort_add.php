<?php
require '../conn/conn.php';
require '../conn/function.php';
require 'admin_check.php';

$D_domain=splitx($_SERVER["HTTP_HOST"].$_SERVER["PHP_SELF"],"/$C_admin",0);
$action=$_GET["action"];
$S_id=intval($_GET["S_id"]);

if($S_id!=""){
	$aa="edit&S_id=".$S_id;
	$S=getrs("select * from sl_csort where S_id=".$S_id);
	if ($S!="") {
		$S_title=$S["S_title"];
		$S_content=$S["S_content"];
		$S_sub=$S["S_sub"];
		$S_order=$S["S_order"];
	}
}else{
	$aa="add";
	$S_pic="nopic.png";
	$S_sub=0;
	$S_order=0;
}

if($action=="add"){
	$S_title=$_POST["S_title"];
	$S_content=$_POST["S_content"];
	$S_sub=intval($_POST["S_sub"]);
	$S_order=intval($_POST["S_order"]);

	if($S_title!=""){
		mysqli_query($conn,"insert into sl_csort(S_title,S_content,S_sub,S_order) values('$S_title','$S_content',$S_sub,$S_order)");
		mysqli_query($conn, "insert into sl_log(L_aid,L_time,L_add,L_ip,L_title) values(".$_SESSION["A_id"].",'".date('Y-m-d H:i:s')."','".$_SESSION["add"]."','".getip()."','新增卡密分类')");
		die("success");
	}else{
		die("error");
	}
}

if($action=="edit"){
	$S_title=$_POST["S_title"];
	$S_content=$_POST["S_content"];
	$S_sub=intval($_POST["S_sub"]);
	$S_order=intval($_POST["S_order"]);

	if($S_title!=""){
		mysqli_query($conn, "update sl_csort set
		S_title='$S_title',
		S_sub=$S_sub,
		S_order=$S_order,
		S_content='$S_content'
		where S_id=".$S_id);
		mysqli_query($conn, "insert into sl_log(L_aid,L_time,L_add,L_ip,L_title) values(".$_SESSION["A_id"].",'".date('Y-m-d H:i:s')."','".$_SESSION["add"]."','".getip()."','编辑卡密分类')");
		die("success");
	}else{
		die("error");
	}
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>

		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>卡密分类设置 - 后台管理</title>

		<!--favicon -->
		<link rel="icon" href="../media/<?php echo $C_ico?>" type="image/x-icon"/>

		<!--Bootstrap.min css-->
		<link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">

		<!--Icons css-->
		<link rel="stylesheet" href="assets/css/icons.css">

		<!--Style css-->
		<link rel="stylesheet" href="assets/css/style.css">

		<!--mCustomScrollbar css-->
		<link rel="stylesheet" href="assets/plugins/scroll-bar/jquery.mCustomScrollbar.css">

		<!--Sidemenu css-->
		<link rel="stylesheet" href="assets/plugins/toggle-menu/sidemenu.css">

		<!--Toastr css-->
		<link rel="stylesheet" href="assets/plugins/toastr/build/toastr.css">

		<script type="text/javascript" src="../upload/upload.js"></script>
		<style type="text/css">
		.showpic{height: 50px;border: solid 1px #DDDDDD;padding: 5px;}
		.list-group a{text-decoration:none}
	</style>
	</head>

	<body class="app ">

		<div id="spinner"></div>

		<div id="app">
			<div class="main-wrapper" >
				
					<?php
					require 'nav.php';
					?>

				<div class="app-content">
					<section class="section">
                    	<ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="card_list.php">卡密管理</a></li>
                            <li class="breadcrumb-item active"><a href="csort_add.php">卡密分类</a></li>
                            <li class="breadcrumb-item"><a href="card_out.php">导出卡密</a></li>
                        </ol>
                        <style type="text/css">
                        .active a{font-weight: bold;color: #a2a9d4}
                    	</style>

						<div class="section-body ">
							
							<div class="row">
								
								<div class="col-lg-3">

									<div class="card card-primary">

										<div class="card-header">
											<h4>卡密分类列表</h4>

										</div>
												<ul class="list-group">
												
											
											<?php 
													$sql="select * from sl_csort where S_del=0 and S_sub=0 order by S_order,S_id desc";
														$result = mysqli_query($conn, $sql);
														if (mysqli_num_rows($result) > 0) {
														while($row = mysqli_fetch_assoc($result)) {
															if($row["S_id"]==$S_id){
																$active="active";
															}else{
																$active="";
															}

															
															echo "<div style=\"position:relative;border-top:solid 1px #EEEEEE;\" id=\"s".$row["S_id"]."\"><a href=\"?S_id=".$row["S_id"]."\" id=\"s".$row["S_id"]."\" class=\"list-group-item ".$active."\"><b>└ ".$row["S_title"]."</b>
															
															</a>
															<button data-toggle=\"collapse\" 
		data-target=\"#d".$row["S_id"]."\" type=\"button\" style=\"position:absolute;right:10px;top:10px;z-index:999\" class=\"btn btn-sm btn-warning cc\">+ 展开</button> 
															</div><div id=\"d".$row["S_id"]."\" class=\"collapse\">";

															$sql2="select * from sl_csort where S_del=0 and S_sub=".$row["S_id"]." order by S_order,S_id desc";
																$result2 = mysqli_query($conn, $sql2);
																if (mysqli_num_rows($result2) > 0) {
																while($row2 = mysqli_fetch_assoc($result2)) {
																	if($row2["S_id"]==$S_id){
																		$active2="active";
																	}else{
																		$active2="";
																	}

																	
																	echo "<a href=\"?S_id=".$row2["S_id"]."\" id=\"s".$row2["S_id"]."\" class=\"list-group-item ".$active2."\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└ ".$row2["S_title"]."</a>";
																}
															}
															echo "</div>";
														}
													}
											?>
											
										</ul>
											
									</div>
									<a href="csort_add.php" class="btn btn-sm btn-primary"><i class="fa fa-plus-circle"></i> 新增卡密分类</a>
								</div>

								<div class="col-lg-9">
									<div class="card card-primary">
										<div class="card-header ">
											<h4>卡密分类管理</h4>
										</div>
										<div class="card-body">
											<form id="form">
												<div class="form-group row">
													<label class="col-md-3 col-form-label" >分类标题</label>
													<div class="col-md-9">
														<input type="text"  name="S_title" class="form-control" value="<?php echo htmlspecialchars($S_title)?>">
													</div>
												</div>

												<div class="form-group row">
													<label class="col-md-3 col-form-label" >卡密备注</label>
													<div class="col-md-9">
														<div style="position: relative;">
															<textarea  name="S_content" id="P_file" class="form-control"><?php echo htmlspecialchars($S_content)?></textarea>
															<button type="button" class="btn btn-sm btn-info" style="position: absolute;right: 10px;bottom: 10px;" onClick="showUpload('P_file','<?php echo gethttp().$D_domain?>','../media');"><i class="fa fa-paperclip"></i> 上传附件</button>
														</div>
													</div>
												</div>

												<div class="form-group row">
													<label class="col-md-3 col-form-label" >上级分类</label>
													<div class="col-md-9">
														<select name="S_sub" class="form-control">
															<option value="0">根分类</option>
															<?php
															$sql="select * from sl_csort where S_del=0 and S_sub=0 and not S_id=$S_id order by S_order,S_id desc";
																$result = mysqli_query($conn, $sql);
																if (mysqli_num_rows($result) > 0) {
																while($row = mysqli_fetch_assoc($result)) {
																	if($S_sub==$row["S_id"]){
																		$selected="selected";
																	}else{
																		$selected="";
																	}
																	echo "<option value=\"".$row["S_id"]."\" ".$selected.">".$row["S_title"]."</option>";
																}
															}

															?>
														</select>
														
													</div>
												</div>

												<div class="form-group row">
													<label class="col-md-3 col-form-label" >分类排序</label>
													<div class="col-md-9" style="position: relative;">
														<input type="text"  name="S_order" class="form-control" value="<?php echo $S_order?>">
														
													</div>
												</div>

												<div class="form-group row">
													<label class="col-md-3 col-form-label" ></label>
													<div class="col-md-9">
														<button class="btn btn-info" type="button" onClick="csort_add_save(1)">保存</button>
														<button class="btn btn-primary" type="button" onClick="csort_add_save(2)">保存并返回</button>
														
													</div>
												</div>
											</form>
										</div>
									</div>
								</div>

							</div>
							
						</div>
					</section>
				</div>


			</div>
		</div>

		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
		<script src="assets/plugins/toggle-menu/sidemenu.js"></script>
		<script src="assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="assets/js/scripts.js"></script>
		<script src="assets/js/help.js"></script>
		<script src="assets/plugins/toastr/build/toastr.min.js"></script>
		<script src="ajax.js"></script>
		<script type="text/javascript">
		var $aa="<?php echo $aa?>";

			$(".cc").click(function(){
				if($(this).html()=="+ 展开"){
					$(this).attr("class","btn btn-sm btn-info cc").html("- 收起");
				}else{
					$(this).attr("class","btn btn-sm btn-warning cc").html("+ 展开");
				}
  
			});
			<?php if($S_sub>0){?>
			$("#s<?php echo $S_id?>").parent().attr("class","collapse show");
			$("#s<?php echo $S_id?>").parent().prev().find("button").attr("class","btn btn-sm btn-info cc").html("- 收起");
			<?php }?>
		</script>
		
	</body>
</html>
