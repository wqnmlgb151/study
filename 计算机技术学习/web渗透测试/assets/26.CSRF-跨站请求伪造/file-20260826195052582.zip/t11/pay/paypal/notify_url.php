<?php 
require_once("../../conn/conn.php");
require_once("../../conn/function.php");
$info=getbody("https://www.paypal.com/cgi-bin/webscr",$_POST."&cmd=_notify-validate");
$D_domain=splitx($_SERVER["HTTP_HOST"].$_SERVER["PHP_SELF"],"/pay",0);

if($info=="VERIFIED") {
	$trade_no=$_POST["txn_id"];
	$body = explode("|",$_POST["option_selection1"]);
	$type = $body[0];
	$id = intval($body[1]);
	$genkey = $body[2];
	$email = $body[3];
	$no=intval($body[4]);
	$M_id=intval($body[5]);
	$_SESSION["uid"]=intval($body[6]);
	$total_fee=$_POST["payment_gross"]
	notify($trade_no,$type,$id,$genkey,$email,$no,$M_id,$total_fee,$D_domain,"PAYPAL");
}
?>