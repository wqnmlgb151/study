<?php
require_once("../../conn/conn.php");
require_once("../../conn/function.php");
?>
<!DOCTYPE HTML>
<html>
    <head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>支付宝即时到账交易接口</title>
	</head>
    <body>
    <?php echo $_SESSION["return"];?>
    </body>
    </html>