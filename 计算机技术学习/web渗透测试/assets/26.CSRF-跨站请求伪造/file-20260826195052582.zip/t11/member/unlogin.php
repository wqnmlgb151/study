<?php
require '../conn/conn.php';
require '../conn/function.php';

$type=$_GET["type"];
$genkey=t($_REQUEST["genkey"]);
$from=t($_REQUEST["from"]);

if($type=="download"){
	downloadFile("../media/".t($_GET["path"]).".txt");
}

if($type=="msg"){
	if(is_array($_POST["email"])){
        for ($i=0 ;$i<count($_POST["email"]);$i++ ) {
            $email=$email.$_POST["email"][$i]."__";
        }
        $email=substr($email,0,strlen($email)-2);
    }else{
        $email=$_POST["email"];
    }

    $city=$_POST["city"];
    switch($_POST["pay"]){
    	case "hk":
    	$paytype="转账汇款";
    	break;
    	case "paypal":
    	$paytype="PAYPAL";
    	break;
    	case "alipay":
    	$paytype="支付宝";
    	break;
    	case "alipaynew":
    	$paytype="支付宝";
    	break;
    	case "wxpay":
    	$paytype="微信支付";
    	break;
    	case "qpay":
    	$paytype="QQ钱包";
    	break;
    	case "dmf":
    	$paytype="当面付";
    	break;
    	case "7pay":
    	$paytype="7支付";
    	break;
    	case "payjs":
    	case "payjs_alipay":
    	$paytype="PAYJS";
    	break;
    	case "money":
    	$paytype="余额支付";
    	break;
    	case "codepay_alipay":
    	case "codepay_wxpay":
    	case "codepay_qpay":
    	$paytype="码支付";
    	break;
    	case "jipay_alipay":
    	case "jipay_wxpay":
    	$paytype="极支付";
    	break;
    	case "hupay_alipay":
    	case "hupay_wxpay":
    	$paytype="虎皮椒";
    	break;
    	case "epay_alipay":
    	case "epay_wxpay":
    	case "epay_qpay":
    	$paytype="易支付";
    	break;
    }
	
	$O=getrs("select * from sl_orders where O_id=".intval($_POST["O_id"]));
	$P=getrs("select * from sl_product where P_id=".intval($O["O_pid"]));
	if($P!=""){
		//判断手机号
		if($P["P_msg"]!=""){
			$msg=explode("|",$P["P_msg"]);
			for($i=0;$i<count($msg);$i++){
				if(strpos(splitx($msg[$i],"__",0),"手机")!==false && $P["P_selltype"]!=2){
					if(!is_mobile($_POST["email"][$i])){
						die("请填写正确的手机号码！".$_POST["email"][$i]);
					}
				}
			}
		}
		//处理优惠券
		if($config->quan=="true"){
			$Q_id=intval($_POST["quan"]);
			$Q=getrs("select * from sl_quan where Q_id=".$Q_id." and Q_del=0 and Q_money<=".$O["O_price"]*$O["O_num"]." and Q_usetime>now() and ((Q_fid=".$P["P_mid"]." and Q_pid=0) or (Q_pid=".$O["O_pid"]." and Q_fid=".$P["P_mid"]."))");
			if($Q!=""){
				$quan=$Q["Q_minuse"]+($O["O_price"]*$O["O_num"]-$Q["Q_minuse"])*$Q["Q_discount"]/100;
			}else{
				$quan=0;
			}
		}else{
			$quan=0;
		}
	
		//判断是否为实物商品
		if($P["P_ggsell"]=="" || $O["O_gg"]=="标配" || $O["O_gg"]==""){
			$selltype=$P["P_selltype"];
		}else{
			$O_gg=splitx($O["O_gg"],"|",0);
			$gg=splitx(splitx($P["P_gg"],"@",0),"_",1);
			$gg=explode("|",$gg);
			for($z=0;$z<count($gg);$z++){
				if($O_gg==$gg[$z]){
					$selltype=splitx(splitx($P["P_ggsell"],"\n",$z),"|",0);
				}
			}
		}

		//处理邮费
		if($config->postage=="true"){
			if($selltype==2 && $O["O_price"]*$O["O_num"]<$C_baoyou){//实物商品 && 达不到包邮标准
				$postage=$C_postage;
			}else{
				$postage=0;
			}
		}else{
			$postage=0;
		}
	}else{
		$quan=0;
		$postage=0;
	}

	$O_client=t($_POST["O_client"]);
	mysqli_query($conn,"update sl_orders set O_city='$city',O_ip='".getip()."',O_client='$O_client',O_address='".t($email)."',O_paytype='$paytype',O_quan=$quan,O_postage=$postage where O_genkey='$genkey' and O_id=".intval($_POST["O_id"]));
	die("success");
}

if($type=="quan"){
	$Q_id=intval($_GET["id"]);
	$Q=getrs("select * from sl_quan where Q_id=".$Q_id." and Q_del=0");
	if($Q==""){
		die("{\"id\":\"$Q_id\",\"discount\":\"0\",\"minuse\":\"0\"}");
	}else{
		die("{\"id\":\"$Q_id\",\"discount\":\"".$Q["Q_discount"]."\",\"minuse\":\"".$Q["Q_minuse"]."\"}");
	}
}

if($type=="check"){
	$L_id=getrs("select * from sl_list where L_genkey='".t($genkey)."' and not L_genkey=''","L_id");
	if($L_id==""){
		die("0");
	}else{
		die("1");
	}
}


if($type=="fahuo"){
	$sql="select * from sl_orders,sl_list where O_genkey=L_genkey and O_state>0 and O_genkey='".t($genkey)."' and not O_genkey=''";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_assoc($result);
	if (mysqli_num_rows($result) > 0) {
		$P=getrs("select * from sl_product where P_id=".$row["O_pid"]);
			if($P!=""){
			$P_bz=$P["P_bz"];
			if($P_bz!=""){
				$P_bz=$P_bz."\r\n";
			}
			$P_msg=$P["P_msg"];
			if($P_msg!=""){
				$msg=explode("|",$P_msg);
				$add=explode("__",$row["O_address"]);
				for($i=0;$i<count($msg);$i++){
					$O_address=$O_address.splitx($msg[$i],"_",0)."：".$add[$i]." ";
				}
			}else{
				$O_address=str_replace("__"," ",$row["O_address"]);
			}
		}
		echo '<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8"> 
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title>发货内容</title>
			<link href="../media/'.$C_ico.'" rel="shortcut icon" />
			<link rel="stylesheet" href="css/bootstrap.css">
			<script src="js/jquery.min.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="../js/qrcode.min.js"></script>
			<script src="https://cdn.bootcss.com/html2canvas/0.5.0-beta4/html2canvas.js"></script>
		</head>
		<body style="padding-top:0px">
		<div class="container">
		<a href="../"><img src="../media/'.$C_logo.'" style="height:60px;margin:10px 0"></a>
		<a href="../" class="btn btn-primary pull-right" style="margin-top:20px;">返回首页</a>';


if($P["P_selltype"]==2){
	echo '<div style="text-align:center;margin-bottom:30px;margin-top:10px"><svg t="1640249538074" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2084" width="100" height="100"><path d="M464.247573 677.487844C474.214622 686.649009 489.665824 686.201589 499.086059 676.479029L798.905035 367.037897C808.503379 357.131511 808.253662 341.319802 798.347275 331.721455 788.44089 322.12311 772.62918 322.372828 763.030833 332.279215L463.211857 641.720346 498.050342 640.711531 316.608838 473.940461C306.453342 464.606084 290.653675 465.271735 281.319298 475.427234 271.984922 485.582733 272.650573 501.382398 282.806071 510.716774L464.247573 677.487844Z" p-id="2085" fill="#009900"></path><path d="M1024 512C1024 229.230208 794.769792 0 512 0 229.230208 0 0 229.230208 0 512 0 794.769792 229.230208 1024 512 1024 629.410831 1024 740.826187 984.331046 830.768465 912.686662 841.557579 904.092491 843.33693 888.379234 834.742758 877.590121 826.148587 866.801009 810.43533 865.021658 799.646219 873.615827 718.470035 938.277495 618.001779 974.048781 512 974.048781 256.817504 974.048781 49.951219 767.182496 49.951219 512 49.951219 256.817504 256.817504 49.951219 512 49.951219 767.182496 49.951219 974.048781 256.817504 974.048781 512 974.048781 599.492834 949.714859 683.336764 904.470807 755.960693 897.177109 767.668243 900.755245 783.071797 912.462793 790.365493 924.170342 797.659191 939.573897 794.081058 946.867595 782.373508 997.013826 701.880796 1024 608.898379 1024 512Z" p-id="2086" fill="#009900"></path></svg>
	<h2>恭喜，支付成功</h2>
	<p style="color:#999">感谢您的购买，请等待卖家发货</p>
	</div>';
}

			echo '<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">订单信息</h3>
				</div>
				<div class="panel-body">
				<div class="row">
				<div class="col-md-3">
					<p><img src="'.pic2(splitx($row["O_pic"],"|",0)).'" width="100%"></p>
				</div>
				<div class="col-md-9">
					<p>商品名称：'.$row["O_title"].'</p>
					<p>商品规格：'.str_replace("|"," ",$row["O_gg"]).'</p>
					<p>商品价格：'.$row["O_price"].'元</p>
					<p>购买数量：'.$row["O_num"].'件</p>
					<p>购买时间：'.$row["O_time"].'</p>
					<p>收货信息：'.$O_address.'</p>
					<p>付款方式：'.$row["O_paytype"].'</p>
					<p>订单编号：'.$row["L_no"].'</p>
				</div>
				</div>
					
					
				</div>
			</div>';

if($P["P_selltype"]<2){
			echo '<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">发货内容</h3>
				</div>
				<div class="panel-body">';

				$oc=$row["O_content"];
				$oc=explode("||",$oc);
				for($i=0;$i<count($oc);$i++){
					if(strtolower(splitx($oc[$i],".",1))=="jpg" || strtolower(splitx($oc[$i],".",1))=="png" || strtolower(splitx($oc[$i],".",1))=="gif" || strtolower(splitx($oc[$i],".",1))=="jpeg"){
						echo "<p><a href=\"../media/".$oc[$i]."\" target=\"_blank\"><img src=\"../media/".$oc[$i]."\" style=\"max-width:200px;max-height:100px;\"></a> 点击图片放大</p>";
					}
				}

				$x=getrs("select * from sl_product where P_id=".$row["O_pid"]);
				if(strlen($row["O_content"])>10000){
					$file=t($genkey);
					file_put_contents("../media/".$file.".txt",str_replace('||',"\r\n",$row["O_content"]));
					echo '<a class="btn btn-info" style="margin-top:10px;" href="?type=download&path='.$file.'">下载文件</a>';
				}else{
					echo '<textarea class="form-control" rows="5" id="content_copy">'.$P_bz.str_replace('||',"\r\n",$row["O_content"]).'</textarea> <button class="btn btn-info" style="margin-top:10px;" onclick="copy()">复制</button>';
				}
					
				echo ' <button class="btn btn-success" style="margin-top:10px;" onclick="qr()">生成二维码</button>';
				if(substr($row["O_content"],0,4)=="http"){
					echo " <a href=\"".splitx($row["O_content"]," ",0)."\" class=\"btn btn-primary\" style=\"margin-top:10px;\" target=\"_blank\">打开链接</a>";
				}
				if($x!=""){
					if($x["P_selltype"]==1){
						echo "<div style=\"margin-top:5px\">".getrs("select S_content from sl_csort where S_id=".$x["P_sell"],"S_content")."</div>";
					}
				}
					
				echo '</div>
			</div>';
}


		echo '</div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">生成二维码</h4>
            </div>
            <div class="modal-body" style="text-align:center">
            <div id="billImage" style="display:inline-block"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
                <button type="button" class="btn btn-primary" onclick="save()">保存二维码</button>
            </div>
        </div>
    </div>
</div>
		<script>
			function copy(){
				var e=document.getElementById("content_copy");
		        e.select();
		        document.execCommand("Copy");
		       alert("复制成功")
			}
			function qr(){
				qrcode.makeCode(window.location.href);
				$("#myModal").modal("show");
			}
			function save(){
			var copyDom = $("#billImage"); //要保存的dom
			var width = copyDom.offsetWidth; //dom宽
			var height = copyDom.offsetHeight; //dom高
			var scale = 2; //放大倍数

    	html2canvas(
                    copyDom[0],
                    {
                    	dpi: window.devicePixelRatio * 2,
					    scale: scale,
					    width: width,
					    heigth: height,
					    useCORS: true,
                        onrendered: function (canvas) {                         
                            var pageData = canvas.toDataURL("image/png", 1.0);
							console.log(pageData)
							saveFile(pageData.replace("image/png", "image/octet-stream"),new Date().getTime()+".png");
						}
                    })
}

    function convertCanvasToImage(canvas) {
        var image = new Image();
        image.src = canvas.toDataURL("image/png");
        document.body.appendChild(image);
        return image;
    }
    function saveFile(data, filename){
                var save_link = document.createElementNS("http://www.w3.org/1999/xhtml", "a");
                save_link.href = data;
                save_link.download = filename;
 
                var event = document.createEvent("MouseEvents");
                event.initMouseEvent("click", true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
                save_link.dispatchEvent(event);
            };

			var qrcode = new QRCode("billImage", {width: 300,height: 300,colorDark: "#000000",colorLight: "#ffffff",correctLevel: QRCode.CorrectLevel.H});
		</script>
		</body>
		</html>';
		die();
	}else{
		die("未获取到发货内容，请联系客服");
	}
}

$sql="select * from sl_orders where O_genkey='$genkey' and not O_genkey=''";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
if (mysqli_num_rows($result) > 0) {
	$O_id=$row["O_id"];
	$O_title=$row["O_title"];
	$O_price=$row["O_price"];
	$O_pic=$row["O_pic"];
	$O_gg=$row["O_gg"];
	$O_ggx=$row["O_gg"];
	$O_num=$row["O_num"];
	$O_type=$row["O_type"];
	$O_pid=$row["O_pid"];
	$O_nid=$row["O_nid"];
	$O_cid=$row["O_cid"];
	$O_content=$row["O_content"];
	$O_mid=$row["O_mid"];

	if($O_type==0){
		$P=getrs("select * from sl_product where P_id=$O_pid");
		$P_id=$O_pid;
		$P_mid=$P["P_mid"];
	}

	$M=getrs("select * from sl_member where M_id=".$O_mid);
	$M_viptime=$M["M_viptime"];
	$M_viplong=$M["M_viplong"];
	$M_downloadtimes=$M["M_downloadtimes"];

	if($M_viplong-(time()-strtotime($M_viptime))/86400>0){
		if($M_viplong>30000){
			if($C_freetimes3==0){
				$freetimes=999999;
			}else{
				$freetimes=$C_freetimes3-$M_downloadtimes;
			}
			
		}else{
			if($C_freetimes2==0){
				$freetimes=999999;
			}else{
				$freetimes=$C_freetimes2-$M_downloadtimes;
			}
		}
	}else{
		if($C_freetimes1==0){
			$freetimes=999999;
		}else{
			$freetimes=$C_freetimes1-$M_downloadtimes;
		}
	}

	
	if($O_price==0){
		if($O_type==0){
			$start_date = $M["M_freetime"];
			$end_date = date('Y-m-d H:i:s');

			$datetime_start = new DateTime($start_date);
			$datetime_end = new DateTime($end_date);
			$days = $datetime_start->diff($datetime_end)->days;

			if($days>0){//不是当天
				mysqli_query($conn,"update sl_member set M_freetime='".date('Y-m-d H:i:s')."',M_downloadtimes=1 where M_id=".$O_mid);
			}else{
				if($freetimes>0){//是当天
					mysqli_query($conn,"update sl_member set M_downloadtimes=M_downloadtimes+1 where M_id=".$O_mid);
				}else{
					die("<script>alert(\"您今日免费资源下载次数已用尽，请明日再来！\");history.back();</script>");
				}
			}

			if($P["P_ggsell"]=="" || $O_gg=="标配"){//如果没有设置各项发货
				switch($P["P_selltype"]){
				  	case 0:
				  		$O_content=$P["P_sell"];
				  	break;
				  	case 1:
				  		for($i=0;$i<$O_num;$i++){
							$C_id=getrs("select * from sl_card where C_del=0 and C_use=0 and C_sort=".intval($P["P_sell"]),"C_id");
							$C_content=getrs("select * from sl_card where C_id=".intval($C_id),"C_content");
							if($C_content==""){
								$O_content=$O_content."商品缺货，请联系客服||";
							}else{
								$O_content=$O_content.$C_content."||";
							}
							mysqli_query($conn,"update sl_card set C_use=1 where C_id=".intval($C_id));
						}
						$O_content=substr($O_content,0,strlen($O_content)-2);
				  	break;
				  	case 2:
				  		mysqli_query($conn,"update sl_product set P_rest=P_rest-$O_num where P_id=".$O_pid);
				  		$O_content="实物商品，由商家手动发货";
				  	break;
				}
			}else{
				$O_gg=splitx($O_gg,"|",0);
				$gg=splitx(splitx($P["P_gg"],"@",0),"_",1);
				$gg=explode("|",$gg);
				for($z=0;$z<count($gg);$z++){
					if($O_gg==$gg[$z]){
						switch(splitx(splitx($P["P_ggsell"],"\n",$z),"|",0)){
						  	case 0:
						  		$O_content=splitx(splitx($P["P_ggsell"],"\n",$z),"|",1);
						  	break;
						  	case 1:
						  		for($i=0;$i<$O_num;$i++){
									$C_id=getrs("select * from sl_card where C_del=0 and C_use=0 and C_sort=".intval(splitx(splitx($P["P_ggsell"],"\n",$z),"|",1)),"C_id");
									$C_content=getrs("select * from sl_card where C_id=".intval($C_id),"C_content");
									if($C_content==""){
										$O_content=$O_content."商品缺货，请联系客服||";
									}else{
										$O_content=$O_content.$C_content."||";
									}
									mysqli_query($conn,"update sl_card set C_use=1 where C_id=".intval($C_id));
								}
								$O_content=substr($O_content,0,strlen($O_content)-2);
						  	break;
						  	case 2:
						  		mysqli_query($conn,"update sl_product set P_rest=P_rest-$O_num where P_id=".$O_pid);
						  		$O_content="实物商品，由商家手动发货";
						  	break;
						}
					}
				}
			}

		  	mysqli_query($conn, "update sl_product set P_sold=P_sold+$O_num where P_id=$O_pid");
			mysqli_query($conn, "insert into sl_list(L_mid,L_no,L_title,L_time,L_money,L_genkey) values(1,'".date('YmdHis').rand(10000000,99999999)."','购买商品-".t($O_title)."','".date('Y-m-d H:i:s')."',0,'$genkey')");
			mysqli_query($conn,"update sl_orders set O_content='$O_content',O_state=1,O_address='免费商品，无需邮箱' where O_genkey='$genkey' and not O_genkey=''");
			Header("Location: ?type=fahuo&id=$O_pid&genkey=$genkey");
			die();
		}

		if($O_type==2){
			mysqli_query($conn,"update sl_orders set O_state=1 where O_genkey='$genkey' and not O_genkey=''");
			if($O_content=="all"){
				Header("Location: ../?type=courseinfo&id=$O_cid");
			}else{
				Header("Location: ../?type=courseinfo&id=$O_cid&page=$O_content");
			}
			die();
		}
	}
}else{
	//未生成有效订单，重新生成
	header("location:../buy.php?genkey=$genkey&type=".$_GET["type"]."info&id=".intval($_GET["id"]));
	die();
}

if($O_type==0){
	$id=$O_pid;
}
if($O_type==1){
	$id=$O_nid;
}
if($O_type==2){
	$id=$O_cid;
	if($O_content=="all"){
		$page=1;
	}else{
		$page=$O_content;
	}
}

$address=intval($_GET["address"]);
$A_address=getrs("select * from sl_address where A_id=".$address,"A_address");
$A_name=getrs("select * from sl_address where A_id=".$address,"A_name");
$A_phone=getrs("select * from sl_address where A_id=".$address,"A_phone");

$F_domain=splitx($_SERVER["HTTP_HOST"].$_SERVER["PHP_SELF"],"/member",0);
$D_domain=splitx($C_fdomain.$_SERVER["PHP_SELF"],"/member",0);

if(member_auth(intval($_GET["M_id"]),t($_GET["M_pwd"]))){
	$_SESSION["M_login"] = getrs("select * from sl_member where M_id=".intval($_GET["M_id"])." and M_del=0","M_login");
    $_SESSION["M_id"] = intval($_GET["M_id"]);
    $_SESSION["M_pwd"] = t($_GET["M_pwd"]);

    $genkey=gen_key(20);
    mysqli_query($conn,"update sl_member set M_pwdcode='".$genkey."' where M_id=".intval($_GET["M_id"]));
    $_SESSION["M_pwdcode"] = $genkey;
}

if($_SESSION["M_id"]==""){
	$M_id=1;
	$login="<a href=\"../member/login.php\">[登录]</a> <a href=\"../member/reg.php\">[注册]</a>";
}else{
	$M_id=intval($_SESSION["M_id"]);
	$login="<a href=\"../member/\">[会员中心]</a> <a href=\"../member/login.php?action=unlogin\">[退出]</a>";
}

$sql="select * from sl_member where M_id=$M_id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$M_id=$row["M_id"];
$M_head=$row["M_head"];
$M_login=$row["M_login"];
$M_email=$row["M_email"];
if($M_id==1){
	$M_email="";
}

$M_viptime=$row["M_viptime"];
$M_viplong=$row["M_viplong"];

if($M_viplong-(time()-strtotime($M_viptime))/86400>0){
	$vip_pic="<img src=\"../member/img/vip.png\" style=\"margin-left:5px;height:17px;\">";
}else{
	$vip_pic="";
}

$M_info="
<img src=\"../media/$M_head\" style=\"width:30px;height:30px;border-radius:10px\">
<div style=\"display:inline-block;vertical-align:top;font-size:12px;margin-left:10px;\"> <b>$M_login</b>$vip_pic<br>$login</div>";

if(isMobile()){
	$port_info="?port_type=wap";
}else{
	$port_info="";
}

if($O_type==0){//商品
	$P=getrs("select * from sl_product where P_id=$O_pid");
	$P_selltype=$P["P_selltype"];
	$P_address=$P["P_address"];
	$P_ggsell=$P["P_ggsell"];
	$P_gg=$P["P_gg"];
	$P_msg=$P["P_msg"];


	if($P_msg!=""){
		$msg=explode("|",$P_msg);
		for($i=0;$i<count($msg);$i++){
			if(splitx($msg[$i],"_",3)==1){
				$re_info="必填";
				$re=" required='required'";
			}else{
				$re_info="选填";
				$re="";
			}


			switch(splitx($msg[$i],"_",2)){
				case "text":
					$msgx=$msgx."<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">".splitx($msg[$i],"_",0)."</label>
							    <div class=\"col-sm-10\">
							      <input type=\"text\" class=\"form-control\" name=\"email[]\"  placeholder=\"".splitx($msg[$i],"_",0)."（".$re_info."）\" $re>
							    </div>
							  </div>";
				break;
				case "textarea":
					$msgx=$msgx."<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">".splitx($msg[$i],"_",0)."</label>
							    <div class=\"col-sm-10\">
							      <textarea class=\"form-control\" placeholder=\"".splitx($msg[$i],"_",0)."（".$re_info."）\" name=\"email[]\" $re></textarea>
							    </div>
							  </div>";
				break;
				case "radio":
					$con=explode(",",splitx($msg[$i],"_",1));
					for($j=0;$j<count($con);$j++){
						$msgy=$msgy."<label><input type=\"radio\" name=\"email[]\" value=\"".$con[$j]."\"> ".$con[$j]."</label> ";
					}

					$msgx=$msgx."<div class=\"form-group\">
							    <label  class=\"col-sm-2 control-label\">".splitx($msg[$i],"_",0)."</label>
							    <div class=\"col-sm-10\">
							      ".$msgy."
							    </div>
							  </div>";
				break;

				case "checkbox":
					$con=explode(",",splitx($msg[$i],"_",1));
					for($j=0;$j<count($con);$j++){
						$msgy=$msgy."<label><input type=\"checkbox\" name=\"email[]\" value=\"".$con[$j]."\"> ".$con[$j]."</label> ";
					} 

					$msgx=$msgx."<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\" value=\"".splitx($msg[$i],"_",0)."\">".splitx($msg[$i],"_",0)."</label>
							    <div class=\"col-sm-10\">
							      ".$msgy."
							    </div>
							  </div>";
				break;
				case "select":

				$con=explode(",",splitx($msg[$i],"_",1));
					for($j=0;$j<count($con);$j++){
						$msgy=$msgy."<option value=\"".$con[$j]."\">".$con[$j]."</option>";
					}

					$msgx=$msgx."<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">".splitx($msg[$i],"_",0)."</label>
							    <div class=\"col-sm-10\">
							      <select class=\"form-control\" name=\"email[]\">".$msgy."</select>
							    </div>
							  </div>";
				break;
			}
			$msgy="";
		}
	}

	if($P_ggsell==""){
		if($P_selltype==2){
			if(strpos($P_address,"name")!==false){
				$email=$email."<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">收件人</label>
							    <div class=\"col-sm-10\"><input class=\"form-control\"  name=\"email[]\" placeholder=\"收件人（必填）\" value=\"$A_name\" required></div></div>";
			}
			if(strpos($P_address,"mobile")!==false){
				$email=$email."<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">手机号码</label>
							    <div class=\"col-sm-10\"><input class=\"form-control\"  name=\"email[]\"  placeholder=\"手机号码（必填）\" value=\"$A_phone\" required></div></div>";
			}
			if(strpos($P_address,"address")!==false){
				$email=$email."<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">收件地址</label>
							    <div class=\"col-sm-10\"><textarea class=\"form-control\"  placeholder=\"收件地址（必填）\" name=\"email[]\" required>$A_address</textarea></div></div>";
			}

			$email=$email."<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">给卖家留言</label>
							    <div class=\"col-sm-10\"><textarea class=\"form-control\" placeholder=\"给卖家留言（选填）\" name=\"email[]\"></textarea></div></div>";
			$info="该商品为实物商品，支付成功后，由商家手动发货";
			if($config->postage=="true"){
				if($O_price*$O_num>$C_baoyou){
					$postage="<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">邮费</label>
							    <div class=\"col-sm-10\"><p class=\"form-control-static\">0元（已满".$C_baoyou."元包邮）</p></div></div>";
				}else{
					$postage="<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">邮费</label>
							    <div class=\"col-sm-10\"><p class=\"form-control-static\"><span style=\"color:#ff0000;font-weight:bold;\">".$C_postage."元</span>（满".$C_baoyou."元可包邮）</p></div></div>";
				}
			}
		}else{
			if($msgx==""){
				$email="<div class=\"form-group\">
						<label class=\"col-sm-2 control-label\">电子邮箱</label>
						<div class=\"col-sm-10\"><input class=\"form-control\" id=\"email\" name=\"email[]\" value=\"$M_email\" placeholder=\"电子邮箱（选填）\" ></div></div>
						<div class=\"form-group\">
						<label class=\"col-sm-2 control-label\">给卖家留言</label>
						<div class=\"col-sm-10\"><textarea class=\"form-control\" placeholder=\"给卖家留言（选填）\" name=\"email[]\"></textarea></div></div>";
			}else{
				$email=$msgx;
			}
			$info="该商品为虚拟商品，支付成功后，商品将自动发送到您的电子邮箱";
			$postage="";
		}
	}else{
		$O_gg=splitx($O_ggx,"|",0);
		$gg=splitx(splitx($P_gg,"@",0),"_",1);
		$gg=explode("|",$gg);
		for($z=0;$z<count($gg);$z++){
			if($O_gg==$gg[$z]){
				if(splitx(splitx($P_ggsell,"\n",$z),"|",0)==2){
					if(strpos($P_address,"name")!==false){
						$email=$email."<div class=\"form-group\">
									    <label class=\"col-sm-2 control-label\">收件人</label>
									    <div class=\"col-sm-10\"><input class=\"form-control\"  name=\"email[]\" placeholder=\"收件人（必填）\" value=\"$A_name\" required></div></div>";
					}
					if(strpos($P_address,"mobile")!==false){
						$email=$email."<div class=\"form-group\">
									    <label class=\"col-sm-2 control-label\">手机号码</label>
									    <div class=\"col-sm-10\"><input class=\"form-control\"  name=\"email[]\"  placeholder=\"手机号码（必填）\" value=\"$A_phone\" required></div></div>";
					}
					if(strpos($P_address,"address")!==false){
						$email=$email."<div class=\"form-group\">
									    <label class=\"col-sm-2 control-label\">收件地址</label>
									    <div class=\"col-sm-10\"><textarea class=\"form-control\"  placeholder=\"收件地址（必填）\" name=\"email[]\" required>$A_address</textarea></div></div>";
					}

					$email=$email."<div class=\"form-group\">
									    <label class=\"col-sm-2 control-label\">给卖家留言</label>
									    <div class=\"col-sm-10\"><textarea class=\"form-control\" placeholder=\"给卖家留言（选填）\" name=\"email[]\"></textarea></div></div>";
					$info="该商品为实物商品，支付成功后，由商家手动发货";
					if($config->postage=="true"){
						if($O_price*$O_num>$C_baoyou){
							$postage="<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">邮费</label>
							    <div class=\"col-sm-10\"><p class=\"form-control-static\">0元（已满".$C_baoyou."元包邮）</p></div></div>";
						}else{
							$postage="<div class=\"form-group\">
							    <label class=\"col-sm-2 control-label\">邮费</label>
							    <div class=\"col-sm-10\"><p class=\"form-control-static\"><span style=\"color:#ff0000;font-weight:bold;\">".$C_postage."元</span>（满".$C_baoyou."元可包邮）</p></div></div>";
						}
					}
				}else{
					if($msgx==""){
						$email="<div class=\"form-group\">
						<label class=\"col-sm-2 control-label\">电子邮箱</label>
						<div class=\"col-sm-10\"><input class=\"form-control\" id=\"email\" name=\"email[]\" value=\"$M_email\" placeholder=\"电子邮箱（选填）\" ></div></div>
						<div class=\"form-group\">
						<label class=\"col-sm-2 control-label\">给卖家留言</label>
						<div class=\"col-sm-10\"><textarea class=\"form-control\" placeholder=\"给卖家留言（选填）\" name=\"email[]\"></textarea></div></div>";
					}else{
						$email=$msgx;
					}
					
					$info="该商品为虚拟商品，支付成功后，商品将自动发送到您的电子邮箱";
					$postage="";
				}
			}
		}
	}
}
if($O_type==1){
	$info="支付成功后，文章页面将自动刷新并显示全部内容，在这之前请不要关闭页面";
	$email="<div class=\"form-group\">
				<label class=\"col-sm-2 control-label\">电子邮箱</label>
				<div class=\"col-sm-10\"><input class=\"form-control\" name=\"email\" id=\"email\" placeholder=\"电子邮箱\" value=\"$M_email\"></div></div>";
}
if($O_type==2){
	$info="支付成功后，自动跳转到课程页面，在这之前请不要关闭页面";
	$email="<div class=\"form-group\">
			<label class=\"col-sm-2 control-label\">电子邮箱</label>
					<div class=\"col-sm-10\"><input class=\"form-control\" name=\"email\" id=\"email\" placeholder=\"电子邮箱\" value=\"$M_email\">
					</div></div>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"> 
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>收银台 - <?php echo $C_title?></title>
	<link href="../media/<?php echo $C_ico?>" rel="shortcut icon" />
	<meta name="description" content="<?php echo $C_description?>" />
	<link rel="stylesheet" href="css/bootstrap.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="../js/qrcode.min.js"></script>
	<script src="../js/autoMail.js"></script>
	<script src="https://pv.sohu.com/cityjson?ie=utf-8"></script>
	<style type="text/css">
	a{color: #666666;}
	a:hover{color: #000000;text-decoration:none}
	#mailBox{background:#fff;border:1px solid #ddd;padding:3px 5px 5px;position:absolute;z-index:9999;display:none;-webkit-box-shadow:0px 2px 7px rgba(0, 0, 0, 0.35);-moz-box-shadow:0px 2px 7px rgba(0, 0, 0, 0.35);}
	#mailBox p{width:100%;margin:0;padding:0;height:20px;line-height:20px;clear:both;font-size:12px;color:#ccc;cursor:default;}
	#mailBox ul{padding:0;margin:0;}
	#mailBox li{font-size:15px;height:30px;line-height:30px;color:#939393;font-family:'Tahoma';list-style:none;cursor:pointer;overflow:hidden;}
	#mailBox .cmail{color:#000;background:#e8f4fc;}
	#buy {margin-bottom: 10px;}
	#buy label {
			width: 100%;
			text-align: center;
			padding: 5px 0;
            cursor: pointer;
            border: #CCCCCC solid 2px;
            -moz-border-radius: 3px;
            -webkit-border-radius: 3px;
            border-radius: 3px;
            position: relative;
        }
        #buy label .icon{
        	position: absolute;right: -2px;bottom: 0px;height: 15px;
        }

        #buy .checked {
            border: #ff0000 solid 2px;
            -moz-border-radius: 3px;
            -webkit-border-radius: 3px;
            border-radius: 3px;
            color: #ff0000;
        }

        #buy input[type="radio"] {
            display: none;
        }
	</style>
	<script type="text/javascript">
	function isAlipay(){
        var ua = window.navigator.userAgent.toLowerCase();
        if (ua.match(/Alipay/i) == 'alipay') {
            return true; // 是支付宝端
        } else {
            return false;
        }
    }
    function isWeiXin(){
        var ua = window.navigator.userAgent.toLowerCase();
        if (ua.match(/MicroMessenger/i) == 'micromessenger') {
            return true; // 是微信端
        } else {
            return false;
        }
    }
    <?php if (strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),"micromessenger")!==false && $_REQUEST["jsApiParameters"]!=""){?>
	function jsApiCall(){
		$type="<?php echo $type?>";
		WeixinJSBridge.invoke(
			'getBrandWCPayRequest',
			<?php echo stripslashes(str_replace("__", "\"", $_REQUEST["jsApiParameters"]))?>,
			function(res){
				if(res.err_msg.indexOf(":ok")>-1){
					if($type=="news"){
						window.location.href="<?php echo $from?>/pay/7pay/return.php?type=news&id=<?php echo $id?>&genkey=<?php echo $genkey?>";
					}else{
						window.location.href="<?php echo $from?>/member/unlogin.php?type=fahuo&genkey=<?php echo $genkey?>";
					}
				}else{
					//alert(res.err_msg);
				}
			}
		);
	}

	function callpay(){
		if (typeof WeixinJSBridge == "undefined"){
		    if( document.addEventListener ){
		        document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
		    }else if (document.attachEvent){
		        document.attachEvent('WeixinJSBridgeReady', jsApiCall); 
		        document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
		    }
		}else{
		    jsApiCall();
		}
	}
	callpay();

	<?php }?>
	</script>

</head>
<body style="background: #f7f7f7;padding-top:10px ">
<div class="pop none" id="divpop" style="display:none;" onclick="$('#divpop').hide();">
　　<img src="img/top.png" style='float: right;margin: 10px;max-width: calc(100% - 20px)'>
</div>
<div class="container" style="padding: 20px;background: #ffffff;border-radius: 10px;">
<div style="font-size: 18px"><a href="../"><img src="../media/<?php echo $C_logo?>" style="height: 40px;margin-right: 10px;padding-right: 10px;border-right: solid 1px #DDDDDD;"></a>收银台</div>

<div style="float: right;margin-top: -35px;">
<?php echo $M_info;?>
</div>
</div>

<?php if($_SESSION["M_id"]==""){?>
<div class="container" style="padding: 20px;background: #ffffff;margin-top: 10px;border:solid 1px #0099ff;border-radius: 10px;">
提示：您正在使用免登录购物功能，付款后商品将直接发送到您的邮箱
<a href="login.php" class="btn btn-primary pull-right btn-xs">登录帐号</a>
</div>
<?php }?>

<div class="container" style="padding: 20px;background: #ffffff;margin-top: 10px;position: relative;border-radius: 10px;">

<div style="position: absolute;top: 10px;right: 10px;text-align: center;padding: 10px;background: #ffffff;font-size: 12px;" id="qrcode2" class="hidden-xs">
<div id="qrcode_url"></div>
<div style="margin-top: 5px;">扫码进入手机版</div>
</div>

<form id="pay_form" method="post" class="form-horizontal">
<input type="hidden" name="genkey" value="<?php echo $genkey?>">
<input type="hidden" name="O_id" value="<?php echo $O_id?>">
<input type="hidden" name="O_client" value="">

<div class="form-group">
    <label  class="col-sm-2 control-label">订单名称</label>
    <div class="col-sm-10"><p class="form-control-static"><?php echo $O_title;?></p></div>
</div>
<?php
if($O_type==0){
	echo "<div class=\"form-group\">
    <label  class=\"col-sm-2 control-label\">订单详情</label>
    <div class=\"col-sm-10\"><p class=\"form-control-static\">".str_replace("|"," ",$O_ggx)." ".$O_num."件</p></div></div>";
}
?>
<div class="form-group">
    <label  class="col-sm-2 control-label">订单金额</label>
    <div class="col-sm-10"><span style="font-size: 25px;color: #ff0000"><span id="O_money"><?php echo $O_price*$O_num;?></span>元</span><?php echo $vip_pic?></div>
</div>

<p><?php echo $postage?></p>
<div class="form-group">
    <label  class="col-sm-2 control-label">购买说明</label>
    <div class="col-sm-10"><p class="form-control-static"><span style="font-size: 12px;color: #999999"><?php echo $info?></span></p></div>
</div>

<?php if($config->quan=="true" && $_SESSION["M_id"]!="" && $O_type==0){?>

<div class="form-group">
    <label  class="col-sm-2 control-label">可用优惠</label>
    <div class="col-sm-10"><select class="form-control" name="quan" id="quan" onchange="usequan()">
        	<option value="0">暂无可用优惠</option>
        	<?php
        	//全场优惠
        	$sql="select * from sl_quan where Q_del=0 and Q_mid=".intval($_SESSION["M_id"])." and not Q_mid=0 and ((Q_fid=".$P_mid." and Q_pid=0) or (Q_pid=".$P_id." and Q_fid=".$P_mid.")) and Q_usetime>now()";
			$result = mysqli_query($conn,  $sql);
			if (mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_assoc($result)) {
					if($row["Q_discount"]>0){
						$D_info=" 打".((100-$row["Q_discount"])/10)."折";
					}else{
						$D_info="";
					}
					if($row["Q_minuse"]>0){
						$M_info=" 减".$row["Q_minuse"]."元";
					}else{
						$M_info="";
					}
					if($row["Q_money"]<=$O_price*$O_num){
						echo "<option value=\"".$row["Q_id"]."\">[".$row["Q_title"]."] 满".$row["Q_money"]."元".$M_info.$D_info."</option>";
					}else{
						echo "<optgroup label=\"[".$row["Q_title"]."] 满".$row["Q_money"]."元".$M_info.$D_info."【不可用】\"></optgroup>";

					}
				}
			}
        	?>
        </select></div>
</div>
<?php }?>

<div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">支付方式</label>
    <div class="col-sm-10">
    	<div id="buy">
		<div class="row">
		<?php if ($C_alipaynewon==1){?><div class="col-xs-6 col-md-2"><label aa="pay" type="支付宝商户"><input type="radio" value="alipaynew" name="pay"> <img src="img/alipay.png" height="25" alt="支付宝商户"></label></div> <?php }?>
		<?php if ($C_alipayon==1){?><div class="col-xs-6 col-md-2"><label aa="pay" type="支付宝商户（旧版）"><input type="radio" value="alipay" name="pay"> <img src="img/alipay.png" height="25" alt="支付宝商户（旧版）"></label></div> <?php }?>
		<?php if ($C_dmfon==1){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="dmf" name="pay"> <img src="img/alipay.png" height="25" alt="当面付"></label></div> <?php }?>
		<?php if ($C_7payon==1){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="7pay" name="pay"> <img src="img/alipay.png" height="25" alt="7支付"></label></div> <?php }?>
		<?php if (strpos($C_payjs_type,"alipay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="payjs_alipay" name="pay"> <img src="img/alipay.png" height="25" alt="PAYJS"></label></div> <?php }?>
		<?php if (strpos($C_codepay_type,"alipay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="codepay_alipay" name="pay"> <img src="img/alipay.png" height="25" alt="码支付"></label></div> <?php }?>

		<?php if (strpos($C_jipay_type,"alipay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="jipay_alipay" name="pay"> <img src="img/alipay.png" height="25" alt="极支付"></label></div> <?php }?>

		<?php if (strpos($C_hupay_type,"alipay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="hupay_alipay" name="pay"> <img src="img/alipay.png" height="25" alt="虎皮椒"></label></div> <?php }?>

		<?php if (strpos($C_epay_type,"alipay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="epay_alipay" name="pay"> <img src="img/alipay.png" height="25" alt="易支付"></label></div> <?php }?>

		<?php if ($C_wxpayon==1){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="wxpay" name="pay"> <img src="img/weixin.png" height="25"></label></div> <?php }?>

		<?php if(strpos($C_payjs_type,"wxpay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="payjs" name="pay"> <img src="img/weixin.png" height="25"></label></div> <?php }?>
		<?php if(strpos($C_codepay_type,"wxpay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="codepay_wxpay" name="pay"> <img src="img/weixin.png" height="25"</label></div> <?php }?>
		<?php if(strpos($C_jipay_type,"wxpay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="jipay_wxpay" name="pay"> <img src="img/weixin.png" height="25"</label></div> <?php }?>
		<?php if(strpos($C_hupay_type,"wxpay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="hupay_wxpay" name="pay"> <img src="img/weixin.png" height="25"</label></div> <?php }?>
		<?php if(strpos($C_epay_type,"wxpay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="epay_wxpay" name="pay"> <img src="img/weixin.png" height="25"</label></div> <?php }?>

		<?php if ($C_qpayon==1){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="qpay" name="pay"> <img src="img/qqpay.png" height="25"></label></div> <?php }?>
		<?php if(strpos($C_codepay_type,"qqpay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="codepay_qpay" name="pay"> <img src="img/qqpay.png" height="25"></label></div> <?php }?>

		<?php if(strpos($C_epay_type,"qqpay")!==false){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="epay_qpay" name="pay"> <img src="img/qqpay.png" height="25"></label></div> <?php }?>

		<?php if($C_paypalon==1){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="paypal" name="pay"> <img src="img/paypal.png" height="25"></label></div> <?php }?>

		<?php if($C_money!=""){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="hk" name="pay"> <img src="img/hk.png" height="25"></label></div> <?php }?>

		<?php if ($M_id>1){?><div class="col-xs-6 col-md-2"><label aa="pay"><input type="radio" value="money" name="pay"> <img src="img/money.png" height="25"></label></div> <?php }?>
		</div>
    </div>
</div>

</div>

<div><?php echo $email?></div>
<input type="hidden" value="" name="city">
<div class="form-group">
    <label class="col-sm-2 control-label"></label>
    <div class="col-sm-10">
    	<button class="btn btn-danger btn-lg hidden-xs" type="button" onclick="payx()" id="money_btn">立即支付</button>
    	<button class="btn btn-danger btn-lg btn-block visible-xs" type="button" onclick="payx()" id="money_btn">立即支付</button>
    </div>
</div>

</form>
</div>
<!-- 模态框（Modal） -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title" id="myModalLabel">
					扫码支付
				</h4>
			</div>
			<div class="modal-body" style="text-align: center;" id="modal_body">
				<img src="img/alipay.png" style="margin-bottom: 20px;" id="pay_img"><br>
				<div id="billImage" style="width: 200px;display: inline-block;margin-bottom: 10px"></div>
				<div id="pay_info">请使用支付宝扫码支付</div>
			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title" id="myModalLabel">
					转账汇款
				</h4>
			</div>
			<div class="modal-body" style="text-align: center;" id="modal_body">
				<div class="form-horizontal">
				<?php
				$C_m=explode("|",$C_money);
				for($i=0;$i<count($C_m);$i++){

					if(substr(splitx($C_m[$i],"_",1), -4)==".jpg" || substr(splitx($C_m[$i],"_",1), -4)==".png"){
						$m2="<img src=\"../media/".splitx($C_m[$i],"_",1)."\" style=\"width:200px\">";
					}else{
						$m2="<p class=\"form-control-static\">".splitx($C_m[$i],"_",1)."</p>";
					}

					switch(splitx($C_m[$i],"_",0)){
						case "m1":
							$m1="支付宝";
						break;
						case "m2":
							$m1="微信支付";
						break;
						case "m3":
							$m1="银行卡";
						break;
					}
					echo '<div class="form-group">
    <label for="firstname" class="col-sm-2 control-label">'.$m1.'</label>
    <div class="col-sm-10" style="text-align:left">
      '.$m2.'
    </div>
  </div>';
				}

				?>
				<hr>
				<p>说明：转账后请主动联系客服人员完成订单。</p>
			</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
$from="<?php echo gethttp().$F_domain?>";
$domain="<?php echo gethttp().$D_domain?>";
$paypal="<?php echo $C_paypal?>";
$id=<?php echo $id?>;
$page="<?php echo $page?>";
$O_id=<?php echo $O_id?>;
$O_title="<?php echo strip_tags($O_title)?>";
$amount=<?php echo round($O_price*$O_num/$C_rate,2)?>;
$os0="<?php echo $O_type."|".$id."|".$genkey."||".$O_num."|".intval($_SESSION["M_id"])."|".intval($_SESSION["uid"]);?>";
$genkey="<?php echo $genkey;?>";
$C_wx_appid="<?php echo $C_wx_appid?>";
$C_payjs_id="<?php echo $C_payjs_id?>";
$money=<?php echo $O_price*$O_num?>;
$type="<?php echo $O_type?>";

</script>
<script src="js/unlogin.js"></script>
</body>
</html>