<fh-function>
$page=$_GET["page"];
$tag=t($_GET["tag"]);
$orderby=$_GET["orderby"];

switch($orderby){
  case "normal":
  case "":
    $order=" order by P_top desc,P_order asc,P_time desc,P_id desc";
  break;
  case "hot":
    $order=" order by P_sold desc";
  break;
  case "time":
    $order=" order by P_time desc";
  break;
  case "price":
    $order=" order by P_price asc";
  break;
  case "price2":
    $order=" order by P_price desc";
  break;
}

$url=gethttp().$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
if($tag==""){
  $taginfo="";
}else{
  $taginfo=" and CONCAT(\" \",P_tag,\" \") like '% ".$tag." %'";
}

$M_id=intval($_GET["M_id"]);
if($page==""){
  $page=1;
}
if($M_id!=0){
  $M_info=" and P_mid=$M_id ".$taginfo;
}else{
  $M_info=" and P_sh=1".$taginfo;
}

$sql="select * from sl_psort where S_id=".$id;
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  if (mysqli_num_rows($result) > 0) {
    $S_sub=$row["S_sub"];
  }

if($id==0){
  $sql="select count(P_id) as P_count from sl_product where P_del=0 ".$M_pinfo."  $M_info order by P_order,P_time desc,P_id desc";
}else{
  if($S_sub==0){
    $sql="select count(P_id) as P_count from sl_product,sl_psort where S_del=0 $M_info and P_del=0 ".$M_pinfo."  and P_sort=S_id and S_sub=".$id." order by P_order,P_time desc,P_id desc";
  }else{
    $sql="select count(P_id) as P_count from sl_product,sl_psort where S_del=0 $M_info and P_del=0 ".$M_pinfo."  and P_sort=S_id and S_id=".$id." order by P_order,P_time desc,P_id desc";
  }
}

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$P_count=$row["P_count"];

$page_num=intval($P_count/10)+1;
if($P_count%10 ==0){
  $page_num=$page_num-1;
}

function url($url,$key,$value){
  $url=str_replace("&".$key."=".str_replace("%3A",":",urlencode($value)),"",$url);
  return $url;
}

</fh-function>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>[S_title] - [fh_title]</title>
<link href="media/[fh_ico]" rel="shortcut icon" />
<meta name="description" content="[S_content]" />
<meta name="keywords" content="[S_keywords]" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.bootcss.com/weui/1.1.2/style/weui.min.css">
    <link rel="stylesheet" href="https://cdn.bootcss.com/jquery-weui/1.2.0/css/jquery-weui.min.css">
    <link href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="template/t8/css/font-awesome.min.css">
    <link rel="stylesheet" href="template/t8/css/main.css">
    <link rel="stylesheet" href="template/t8/css/class.css">
    <link rel="stylesheet" href="template/t8/css/theme-color.css">
    <link href="css/Pager.css" rel="stylesheet" type="text/css" />
    <style>
    .ware-des {
    margin: 0;
    line-height: 20px;
    font-size: 1rem;
    color: #bbbbbb;
    word-break: break-all;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.choose{color: #f00;font-weight: bold;}
.n{color: #AAA;font-weight:normal;}
.active2{color: #956bff}
</style>
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<header class="zyw-header">
    <div class="zyw-container white-color">
        <div class="head-l"><a href="javascript:window.history.back(-1)" target="_self"><img src="template/t8/img/svg/head-return.svg" alt=""></a></div>
        <div class="head-search">
            <i class="fa fa-search" aria-hidden="true"></i>
            <input type="text" placeholder="输入您当前要搜索的商品" class="white-color">
        </div>
        <div class="head-r"><a href="">取消</a></div>
    </div>
</header>


<footer class="zyw-footer">
    <div class="zyw-container white-bgcolor">
        <div class="weui-tabbar">
            <a href="./" class="weui-tabbar__item ">
                <div class="weui-tabbar__icon">
                    <img src="template/t8/img/tab1.png" alt="">
                </div>
                <p class="weui-tabbar__label">首页</p>
            </a>
            <a href="?type=product&id=0" class="weui-tabbar__item weui-bar__item--on">
                <div class="weui-tabbar__icon">
                    <img src="template/t8/img/tab2_2.png" alt="">
                </div>
                <p class="weui-tabbar__label">商品</p>
            </a>
            <a href="?type=news&id=0" class="weui-tabbar__item">
                <div class="weui-tabbar__icon">
                    <img src="template/t8/img/tab3.png" alt="">
                </div>
                <p class="weui-tabbar__label">文章</p>
            </a>
            <a href="member" class="weui-tabbar__item">
                <div class="weui-tabbar__icon">
                    <img src="template/t8/img/tab4.png" alt="">
                </div>
                <p class="weui-tabbar__label">我的</p>
            </a>
        </div>
    </div>
</footer>


<section class="zyw-container">
    <div class="class-cont clearfix">
        <ul id="myTab" class="nav nav-tabs nav-stacked class-hd" style="width: 20%">
<li class="
<fh-function>
if($id==0){
    $api=$api."active";
}else{
    $api=$api."";
}
</fh-function>"><a href="?type=product&id=0" ><span style="font-weight:bold">全部商品</span></a></li>

            <fh-function>
$sql="select * from sl_psort where S_del=0 and S_sub=0 order by S_order,S_id desc";
                s[[
if($id==$row["S_id"] || $row["S_id"]==getrs("select S_sub from sl_psort where S_id=$id","S_sub")){
    $active="active";
    $show="display:block";
}else{
    $active="";
    $show="display:none";
}

                  $api=$api."<li class=\"".$active."\" ><a href=\"?type=product&id=".$row["S_id"]."\" style=\"padding:10px 0\"><span style=\"font-weight:bold\">".$row["S_title"]."</span></a><ul style=\"".$show."\">";

$sql2="select * from sl_psort where S_del=0 and S_sub=".$row["S_id"]." order by S_order,S_id desc";
                s2[[
if($id==$row2["S_id"]){
    $active="active2";
}else{
    $active="";
}

                  $api=$api."<li class=\"".$active."\" style=\"height:40px;line-height:40px;border-top:solid 1px #EEE;background:#fff\"><a href=\"?type=product&id=".$row2["S_id"]."\">".$row2["S_title"]."</a></li>";
]]


                  $api=$api."</ul></li>";

                ]]
            </fh-function>

        </ul>
        <div id="myTabContent" class="tab-content class-bd " style="width: 80%;background: #eee">
<div class="tab-pane fade in active" id="nznz">
                <div class="class-bd-cont" style="padding: 0 20px">
                    <div class="bd-box">
                        <div style="background: #fff;height: 40px;line-height: 40px;margin:0 -20px 10px -20px;border-left: solid 1px #EEE">
                        <a class="<fh-function>if($orderby=="normal" || $orderby==""){$api="choose";}else{$api="n";}</fh-function>" style="display: inline-block;width: 25%;text-align: center;" href="<fh-function>$api=url($url,"orderby",$_GET["orderby"])."&orderby=normal";</fh-function>">综合</a><a class="<fh-function>if($orderby=="hot"){$api="choose";}else{$api="n";}</fh-function>" style="display: inline-block;width: 25%;text-align: center;" href="<fh-function>$api=url($url,"orderby",$_GET["orderby"])."&orderby=hot";</fh-function>">销量</a><a class="<fh-function>if($orderby=="time"){$api="choose";}else{$api="n";}</fh-function>" style="display: inline-block;width: 25%;text-align: center;" href="<fh-function>$api=url($url,"orderby",$_GET["orderby"])."&orderby=time";</fh-function>">时间</a><a class="<fh-function>if($orderby=="price" || $orderby=="price2"){$api="choose";}else{$api="n";}</fh-function>" style="display: inline-block;width: 25%;text-align: center;" href="<fh-function>
                        if($orderby!="price" && $orderby!="price2"){
                        	$api=url($url,"orderby",$_GET["orderby"])."&orderby=price";
                        }
                        if($orderby=="price"){
                        	$api=url($url,"orderby",$_GET["orderby"])."&orderby=price2";
                        }
                        if($orderby=="price2"){
                        	$api=url($url,"orderby",$_GET["orderby"])."&orderby=price";
                        }
                        
                    </fh-function>"><fh-function>
                        if($orderby!="price" && $orderby!="price2"){
                        	$api="价格";
                        }
                        if($orderby=="price"){
                        	$api="价格↑";
                        }
                        if($orderby=="price2"){
                        	$api="价格↓";
                        }
                        
                    </fh-function></a>
                    </div>
                        <div class="bd-box-info">
                            <div class="row">
            <fh-function>

if($id==0){
  $sql="select * from sl_product where P_del=0 ".$M_pinfo."  $M_info $order limit ".(($page-1)*10).",10";
}else{
  if($S_sub==0){
    $sql="select * from sl_product,sl_psort where S_del=0 and P_del=0 ".$M_pinfo."  $M_info and P_sort=S_id and S_sub=".$id." $order limit ".(($page-1)*10).",10";
  }else{
    $sql="select * from sl_product,sl_psort where S_del=0 and P_del=0 ".$M_pinfo."  $M_info and P_sort=S_id and S_id=".$id." $order limit ".(($page-1)*10).",10";
  }
}
$result = mysqli_query($conn,  $sql);
if (mysqli_num_rows($result) > 0) {
while($row = mysqli_fetch_assoc($result)) {


if($row["P_limit"]>0 and $row["P_limitlong"]>0 and $row["P_limitlong"]-(time()-strtotime($row["P_limittime"]))/3600>0){
              $P_price=$row["P_limit"];
              $l=date('Y-m-d H:i:s',strtotime('+'.$row["P_limitlong"].' hour',strtotime($row["P_limittime"])));
            }else{
              $P_price=p($row["P_price"]);
              $l="";
            }



$api=$api."<div class=\"col-xs-6 info-item scms-pic\">
    <div style=\"border-radius: 10px;background: #fff;overflow: hidden;\">
                                    <a href=\"?type=productinfo&id=".$row["P_id"]."\">
                                        <img src=\"".pic(splitx($row["P_pic"],"|",0))."\" alt=\"\" style=\"width:100%\"></a>
<div style=\"padding: 8px;\">
                                    <div style=\"font-size:12px;height:35px;overflow:hidden;margin-bottom:5px;\">".mb_substr($row["P_title"],0,20,"utf-8")."</div>
                                    <div style=\"color:#ff0000;text-align:left\">￥".$P_price."</div>
                                    <div style=\"font-size: 12px;float:right;margin-top:-18px;color:#AAAAAA\">已售：".$row["P_sold"]."</div>
                                </div>
</div>
                                </div>";
                }
            }else{
                $api=$api."<div class=\"col-xs-6 info-item scms-pic\">
                                    <a href=\"#\"><img src=\"".pic("nopic.png")."\" alt=\"\" ></a>
                                    <p class=\"ware-des\" >该分类下暂无商品</p>
                                    <div style=\"color:#ff0000;text-align:left\">￥0</div>
                                    <div style=\"font-size: 12px;float:right;margin-top:-18px;color:#AAAAAA\">已售：0</div>
                                </div>";
            }
            </fh-function>

            </div>
            </div>
            </div>
            </div>
        </div>
        <div id="pager"></div>
    </div>

</section>
<script src="https://cdn.bootcss.com/jquery/1.11.0/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/jquery-weui/1.2.0/js/jquery-weui.min.js"></script>
<script src="template/t8/js/bootstrap.min.js"></script>
<script>
$(".scms-pic").attr("style","float: none;display:inline-block;vertical-align:top;padding:0 10px;");
</script>
<script src="js/jquery.pager.js" type="text/javascript"></script>
<script>
$(".scms-pic").attr("style","float: none;display:inline-block;vertical-align:top;padding:0 0 0 5px;margin-bottom:10px;");
$(document).ready(function() {
    $("#pager").pager({ pagenumber: <fh-function> $api=$api.$page;</fh-function>, pagecount: <fh-function> $api=$api.$page_num;</fh-function>, buttonClickCallback: PageClick });
});

PageClick = function(pageclickednumber) {
  window.location="<fh-function>$api=$api.url($url,"page",$_GET["page"]);</fh-function>&page="+pageclickednumber;

}
</script>
[fh_kefu]
<div style="display: none">[fh_code]</div>
</body>
</html>