
<html>
<head>
<meta http-equiv="x-ua-compatible" content="ie=7" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>[fh_title]</title>
<link href="media/[fh_ico]" rel="shortcut icon" />
<meta name="description" content="[fh_description]" />
<meta name="keywords" content="[fh_keyword]" />

<link href="template/t11/css/global.css?t=0364443001588475098" rel="stylesheet" type="text/css" />
<link href="template/t11/css/basic.css?t=0364443001588475098" rel="stylesheet" type="text/css" />
<link href="template/t11/css/index.css?t=0364443001588475098" rel="stylesheet" type="text/css" />
<script language="javascript" src="template/t11/js/global.js?t=0364443001588475098"></script>
<script language="javascript" src="template/t11/js/basic.js?t=0364443001588475098"></script>
<script language="javascript" src="template/t11/js/jquery.min.js?t=0364443001588475098"></script>
<script language="javascript" src="template/t11/js/layer.js?t=0364443001588475098"></script>
<script language="javascript" src="template/t11/js/index.js?t=0364443001588475098"></script>
<script type="text/javascript" src="template/t11/js/jquery.SuperSlide.2.1.3.js?t=0364443001588475098"></script>
<style type="text/css">
.bg0{background: #333}
.bg1{background: #FF6668}
.bg2{background: #3ABC8F}
.bg3{background: #B16BFF}
.bg4{background: #55A3F2}
.bg5{background: #E38902}
body div{margin:auto}

ul{
    list-style: none;
}
.drop-down-content{
    display: none;
    z-index: 99999;
    position: absolute;
    background: #ffffff;
    top:170px;
    text-align: center;
    padding: 0px;
    margin-left: 10px;
    box-shadow: 0px 0px 5px #888888;
}
.drop-down-content li a{
  margin-left: 0px !important;
  padding: 10px !important;
  font-size: 14px !important;
}
.drop-down-content li:hover a{
    background-color:#f7f7f7;
}
.nav .drop-down:hover .drop-down-content{
    display: block;
}
.nav>li{
    float: left;
}
</style>
</head>
<body>
<div class="bfb bfbtop">
<div class="yjcode">

<div class="dts">欢迎来到[fh_title]</div>
<div class="toplogin">

<fh-function>
			if($_SESSION["M_login"]==""){
				$api="<a href=\"member/login.php\" class=\"a1\">登录</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
				<a href=\"member/reg.php\">免费注册</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;";
			}else{
			$api="<a href=\"member/\" class=\"a1\">".$_SESSION["M_login"]."</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
      <a href=\"member/cart.php\" class=\"a1\">购物车</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
			<a href=\"member/login.php?action=unlogin\">退出</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;";
      }
</fh-function>

 </div>
</div>
</div>

<div class="bfb bfbtop1">
<div class="yjcode">
 <div class="top1">
  <h1 class="logo"><a href="./"><img alt="[fh_title]" border="0" src="media/[fh_logo]" height="50" /></a></h1>
  
  <div class="resou">
  <form name="topf1" method="post" action="./?type=search">
  <ul class="u1">
  <li class="l1" onMouseOver="topover()" onMouseOut="topout()">
  <span id="topnwd">全部</span>
  <div id="topdiv" style="display:none;">
  <a href="javascript:void();" onClick="topjconc(0,'全部')">全部</a>
  <a href="javascript:void();" onClick="topjconc(1,'商品')">商品</a>
  <a href="javascript:void();" onClick="topjconc(2,'店铺')">店铺</a>
  <a href="javascript:void();" onClick="topjconc(3,'文章')">文章</a>
  </div>
  </li>
  <li class="l2"><input name="keyword" id="topt" type="text" /><input type="hidden" name="type" id="type" value="0"></li>
  <li class="l3"><input type="submit" value="搜 索" /></li>
  </ul>
  </form>
<div class="d1">
  热门搜索：
<fh-function>
$keyword=explode(",",$H_data["C_hotwords"]);
for($i=0;$i<count($keyword);$i++){
	$api=$api."<a href=\"./?type=search&keyword=".$keyword[$i]."\" target=\"_blank\">".$keyword[$i]."</a>&nbsp;&nbsp;&nbsp;";
}
</fh-function>

    </div>
  </div>


<style>
.shopx{float: right;margin-top: 45px;font-size: 18px;background: #f7f7f7;padding: 10px;border-radius: 5px;border: solid 1px #EEEEEE}
.shopx:hover{background: #0099ff;color: #ffffff}
</style>
<fh-function>
$C_rzon=getrs("select C_rzon from sl_config","C_rzon");
if($C_rzon==1){
  $api=$api."<a href=\"member/seller.php\"><div class=\"shopx\"><img src=\"template/t11/img/shop.png\" width=\"22\" style=\"vertical-align: top;\"> 商家入驻</div></a>";
}
</fh-function>
  <div class="menu fontyh">
   <!--左B-->
      <span id="typeallnum" style="display:none;"><fh-function>$api=$api.getrs("select count(S_id) as S_count from sl_psort where S_del=0 and S_sub=0","S_count");</fh-function></span>
   <div class="m1" onmouseover="leftmenuover()" onmouseout="leftmenuout()">
   <span class="t">全部商品分类</span>
   <!--主导航下拉开始-->
   <div class="menun fontyh" id="leftmenu" style="display:none;">

<fh-function>
  function is_haves($a,$b){
  if(in_array($a,$b)){
      return true;
  }else{
      return false;
  }
}
$i=1;
$sql="select * from sl_psort where S_del=0 and S_sub=0 order by S_order,S_id desc";
                s[[
                $api=$api."<div class=\"menu1\" id=\"yhmenu".$i."\" onmouseover=\"yhmenuover(".$i.")\" onmouseout=\"yhmenuout(".$i.")\">
     <div class=\"mleft\">
      <ul class=\"u1\"><li class=\"l1\"></li><li class=\"l2\"><a href=\"?type=product&id=".$row["S_id"]."\"><b>".$row["S_title"]."</b></a></li><li class=\"l1\"></li></ul>
      <ul class=\"u2\">";

$sql2="select * from sl_psort where S_del=0 and S_sub=".$row["S_id"]." order by S_order,S_id desc limit 9";
                s2[[
                        $api=$api."<li><a href=\"?type=product&id=".$row2["S_id"]."\" title=\"".$row2["S_title"]."\">".$row2["S_title"]."</a></li>";
                    ]]
$api=$api."
            </ul>
     </div>
     <div class=\"rmenu rmenu1\" style=\"display:none;margin-top:-".(110*$i)."px;height:658px;overflow:hidden;\" id=\"rmenu".$i."\">
      <div class=\"esmenu\">


      <ul class=\"esu1\">
      <li class=\"l1\"><span class=\"s1\"></span><span class=\"s2\">分类：</span></li>
      <li class=\"l2\">
      <div>";

$sql2="select * from sl_psort where S_del=0 and S_sub=".$row["S_id"]." order by S_order,S_id desc";
                s2[[
                        $api=$api."<span class=\"sfont\"><a href=\"?type=product&id=".$row2["S_id"]."\">".$row2["S_title"]."</a></span>";
                    ]]
$api=$api."
             </div>
      </li>
      </ul>";

$arr = array();
$sql2="select * from sl_product,sl_psort where S_del=0 and P_del=0 ".$M_pinfo."  and P_sh=1 and P_sort=S_id and S_sub=".$row["S_id"]." order by P_top desc,P_order,P_time desc,P_id desc";
$result2 = mysqli_query($conn,  $sql2);
if (mysqli_num_rows($result2) > 0) {
while($row2 = mysqli_fetch_assoc($result2)) {
        $sx=explode("\r\n",$row2["P_shuxing"]);
        for($ii=0;$ii<count($sx);$ii++){
          if(splitx($sx[$ii],":",0)!=""){
            $c=json_decode("{\"S_title\":\"".splitx($sx[$ii],":",0)."\"}",true);
            if(!is_haves($c,$arr)){
              array_push($arr,$c);
            }
          }
        }
    }
} 


for($ii=0;$ii<count($arr);$ii++){
  $arr[$ii]["list"]=array();
  $result2 = mysqli_query($conn,  $sql2);
  if (mysqli_num_rows($result) > 0) {
  while($row2 = mysqli_fetch_assoc($result2)) {
          $sx=explode("\r\n",$row2["P_shuxing"]);
          for($m=0;$m<count($sx);$m++){
            $s=splitx($sx[$m],":",0);
            if($s==$arr[$ii]["S_title"]){
              $v=splitx($sx[$m],":",1);
                if($v!=""){
                  $x=json_decode("{\"shuxing\":\"".$v."\"}",true);
                  if(!is_haves($x,$arr[$ii]["list"])){
                    array_push($arr[$ii]["list"],$x);
                  }
                }
            }
        }
      }
  }
}



for($ii=0;$ii<count($arr);$ii++){
  for($jj=0;$jj<count($arr[$ii]["list"]);$jj++){
    $shuxing=$shuxing."<span class=\"sfont\"><a href=\"?type=product&id=".$row["S_id"]."&f0=".$arr[$ii]["S_title"].":".$arr[$ii]["list"][$jj]["shuxing"]."\">".$arr[$ii]["list"][$jj]["shuxing"]."</a></span>";
  }

  $api=$api. "
  <ul class=\"esu1\">
      <li class=\"l1\"><span class=\"s1\"></span><span class=\"s2\">".$arr[$ii]["S_title"]."：</span></li>
      <li class=\"l2\">
      <div>".$shuxing."</div>
      </li>
      </ul>";
  $shuxing="";
}

      
      $api=$api. "</div>
      <div class=\"shoptj\" style=\"height:658px;overflow:hidden;\">
      	<ul class=\"shopu1\">
      <li class=\"l1\"><a href=\"./\" target=\"_blank\"><img width=\"110\" height=\"110\" src=\"media/[fh_ico]\" /></a></li>
      <li class=\"l2\"><a href=\"./\" target=\"_blank\">官方旗舰店</a><span class=\"s1\">共有 <span class=\"red\">".getrs("select count(P_id) as P_count from sl_product where P_del=0 ".$M_pinfo."  and P_mid=0","P_count")."</span> 件商品在售</span></li>
      </ul>";


$sql2="select * from sl_member where M_del=0 and M_type=1 order by rand() desc limit 5";
                s2[[
                  
                    $api=$api."<ul class=\"shopu1\">
      <li class=\"l1\"><a href=\"./?type=product&M_id=".$row2["M_id"]."\" target=\"_blank\"><img width=\"110\" height=\"110\" src=\"media/".$row2["M_head"]."\"/></a></li>
      <li class=\"l2\"><a href=\"./?type=product&M_id=".$row2["M_id"]."\" target=\"_blank\">".$row2["M_shop"]."</a><span class=\"s1\">共有 <span class=\"red\">".getrs("select count(P_id) as P_count from sl_product where P_del=0 ".$M_pinfo."  and P_sh=1 and P_mid=".$row2["M_id"],"P_count")."</span> 件商品在售</span></li>
      </ul>";
                ]]

      	$api=$api."

            </div>
     </div>
    </div>";
    $i=$i+1;
                    ]]



</fh-function>

        
        <!--商品E-->
   </div>
   <!--主导航下拉结束-->
   </div> 
   <!--左E-->

   <div class="m2">
<ul class="nav">
   	<fh-function>
                $sql="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=0 order by U_order,U_id desc";
                s[[
                  if($type==$row["U_type"] && $id==$row["U_typeid"]){
                    $class="nav-li active";
                  }else{
                    $class="nav-li margin-left-0";
                  }

                  if($row["U_type"]=="link"){
                    $link=$row["U_link"];
                    $target="_blank";
                  }else{
                    $link="?type=".$row["U_type"]."&id=".$row["U_typeid"];
                    $target="_self";
                  }

                    $api=$api."<li class=\"drop-down\"><a style=\"padding-bottom: 15px;\" href=\"".$link."\" target=\"".$target."\" title=\"".$row["U_title"]."\">".$row["U_title"]."</a><ul class=\"drop-down-content\">";

                    $sql2="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=".$row["U_id"]." order by U_order,U_id desc";
                    s2[[
                      
                      if($row2["U_type"]=="link"){
                        $link2=$row2["U_link"];
                        $target="_blank";
                      }else{
                        $link2="?type=".$row2["U_type"]."&id=".$row2["U_typeid"];
                        $target="_self";
                      }
                            $api=$api."<li><a href=\"".$link2."\" target=\"".$target."\">".$row2["U_title"]."</a></li>";
                        ]]

$api=$api."</ul></li>";
                ]]

              </fh-function>
            </ul>
      </div>
  </div>
 
 </div>
</div>
</div>
<span id="leftnone" style="display:none">0</span>
<script language="javascript">
leftmenuover();
yhifdis(0);
</script>

<!--切换B-->
<div class="banner" id="banner" >

<fh-function>
if(getrs("select count(S_id) as S_count from sl_slide where S_del=0 and S_mid=$fmid","S_count")>0 && $fmid>0){
  $sql="select * from sl_slide where S_del=0 and S_mid=$fmid order by S_order,S_id desc";
}else{
  $sql="select * from sl_slide where S_del=0 and S_mid=0 order by S_order,S_id desc";
}
        s[[
                $api=$api."<a href=\"".$row["S_link"]."\" class=\"d1\" target=\"_blank\" style=\"background:url(".pic($row["S_pic"]).") center no-repeat;\"></a>";
            ]]

</fh-function>


<div class="d2" id="banner_id">
<ul style="margin-left:-16px;">

<fh-function>
if(getrs("select count(S_id) as S_count from sl_slide where S_del=0 and S_mid=$fmid","S_count")>0 && $fmid>0){
  $sql="select * from sl_slide where S_del=0 and S_mid=$fmid order by S_order,S_id desc";
}else{
  $sql="select * from sl_slide where S_del=0 and S_mid=0 order by S_order,S_id desc";
}
    s[[
            $api=$api."<li></li>";
        ]]
</fh-function>
</ul>
</div>
</div>
<script type="text/javascript">banner();</script>
<!--切换E-->

<div class="yjcode">
 <div class="qhright">
 
 <ul class="biaoyu">
 <li class="l1">加入我们，携手共赢</li>
 <li class="l2"><marquee direction="left" style="width: calc(100% - 20px);vertical-align:top; " onMouseOver="this.stop()" onMouseOut="this.start()">[fh_notice]</marquee></li>
 </ul>
  
 <div class="gdmain" id="Marquee1">
 <!--滚动开始-->
 <div class="gd"><span class="s1"><fh-function>$api=$api.$M_count;</fh-function></span><span class="s2">网站总会员</span></div>
 <div class="gd"><span class="s1"><fh-function>$api=$api.$P_count;</fh-function></span><span class="s2">在售商品数</span></div>
 <div class="gd"><span class="s1"><fh-function>$api=$api.$N_count;</fh-function></span><span class="s2">在售文章数</span></div>
 <div class="gd"><span class="s1"><fh-function>$api=$api.$L_count;</fh-function></span><span class="s2">交易总数</span></div>
 <div class="gd"><span class="s1"><fh-function>$api=$api.$L_sum;</fh-function></span><span class="s2">总成交金额</span></div>
 <div class="gd"><span class="s1"><fh-function>$api=$api.$S_count;</fh-function></span><span class="s2">已入驻商家</span></div>

  <script>
 var Mar1 = document.getElementById("Marquee1");
 var child_div1=Mar1.getElementsByTagName("div")
 var picH1 = 60;//移动高度
 var scrollstep1=3;//移动步幅,越大越快
 var scrolltime1=50;//移动频度(毫秒)越大越慢
 var stoptime1=3000;//间断时间(毫秒)
 var tmpH1 = 0;
 Mar1.innerHTML += Mar1.innerHTML;
 function start1(){
	if(tmpH1 < picH1){
		tmpH1 += scrollstep1;
		if(tmpH1 > picH1 )tmpH1 = picH1 ;
		Mar1.scrollTop = tmpH1;
		setTimeout(start1,scrolltime1);
	}else{
		tmpH1 = 0;
		Mar1.appendChild(child_div1[0]);
		Mar1.scrollTop = 0;
		setTimeout(start1,stoptime1);
	}
 }
 start1();
 </script>
 <!--滚动结束-->
 </div>

 <div class="zhuce"><a href="member/reg.php" target="_blank">免费注册会员，加入我们</a></div>
  
 <ul class="zxjy">
 <li class="l1">交易播报</li>
 <li class="l2">
 <div class="gdmain2" id="Marquee2">
 <!--滚动开始-->
<fh-function>

$sql="select * from sl_list where L_del=0 and L_money>0 order by L_id desc limit 20";
    s[[
            $api=$api."<div class=\"gd\">".fdate($row["L_time"])." 产生交易 ".$row["L_money"]."元</div>";
        ]]

</fh-function>

  <script>
 var Mar2 = document.getElementById("Marquee2");
 var child_div2=Mar2.getElementsByTagName("div")
 var picH2 = 16;//移动高度
 var scrollstep2=3;//移动步幅,越大越快
 var scrolltime2=50;//移动频度(毫秒)越大越慢
 var stoptime2=4000;//间断时间(毫秒)
 var tmpH2 = 0;
 Mar2.innerHTML += Mar2.innerHTML;
 function start2(){
	if(tmpH2 < picH2){
		tmpH2 += scrollstep2;
		if(tmpH2 > picH2 )tmpH2 = picH2 ;
		Mar2.scrollTop = tmpH2;
		setTimeout(start2,scrolltime2);
	}else{
		tmpH2 = 0;
		Mar2.appendChild(child_div2[0]);
		Mar2.scrollTop = 0;
		setTimeout(start2,stoptime2);
	}
 }
 start2();
 </script>
 <!--滚动结束-->
 </div>
 </li>
 </ul>
  
 <ul class="ggcap">
 <li class="l1 l11" id="iksa1" onClick="iksaover(1)"><span><fh-function>$api=$api.getrs("select * from sl_nsort where S_del=0 and S_sub=0 order by S_order,S_id desc limit 1","S_title");</fh-function></span></li>
 <li class="l1" id="iksa2" onClick="iksaover(2)"><span><fh-function>$api=$api.getrs("select * from sl_nsort where S_del=0 and S_sub=0 order by S_order,S_id desc limit 1,1","S_title");</fh-function></span></li>
 <li class="l1" id="iksa3" onClick="iksaover(3)"><span><fh-function>$api=$api.getrs("select * from sl_nsort where S_del=0 and S_sub=0 order by S_order,S_id desc limit 2,1","S_title");</fh-function></span></li>
 </ul>
 <div class="ksm" id="ksm1">
<fh-function>

$sql="select * from sl_news,sl_nsort where N_del=0 ".$M_ninfo."  and N_sh=1 and S_del=0 and N_sort=S_id and S_sub in (select S_id from(select S_id from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 1)as t) order by N_order,N_id desc limit 5";
    s[[
            $api=$api."<span><a href=\"?type=newsinfo&id=".$row["N_id"]."\" title=\"".$row["N_title"]."\" target=\"_blank\">".$row["N_title"]."</a></span>";
        ]]
</fh-function>
  </div>
 <div class="ksm" id="ksm2" style="display:none;">
  <fh-function>
$sql="select * from sl_news,sl_nsort where N_del=0 ".$M_ninfo."  and N_sh=1 and S_del=0 and N_sort=S_id and S_sub in (select S_id from(select S_id from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 1,1)as t) order by N_order,N_id desc limit 5";
    s[[
            $api=$api."<span><a href=\"?type=newsinfo&id=".$row["N_id"]."\" title=\"".$row["N_title"]."\" target=\"_blank\">".$row["N_title"]."</a></span>";
        ]]
</fh-function>
  </div>
 <div class="ksm" id="ksm3" style="display:none;">
  <fh-function>
$sql="select * from sl_news,sl_nsort where N_del=0 ".$M_ninfo."  and N_sh=1 and S_del=0 and N_sort=S_id and S_sub in (select S_id from(select S_id from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 2,1)as t) order by N_order,N_id desc limit 5";
    s[[
            $api=$api."<span><a href=\"?type=newsinfo&id=".$row["N_id"]."\" title=\"".$row["N_title"]."\" target=\"_blank\">".$row["N_title"]."</a></span>";
        ]]
</fh-function>
  </div>
 </div>
</div>

<div class="yjcode">
  <!--推荐产品B-->
 <ul class="procap">
 <li class="l1">限时优惠促销</li>
 <li class="l2"><a href="?type=product&id=0" target="_blank">查看更多>></a></li>
 </ul>
 
 <div class="xianshitj">
<fh-function>
$i=1;
$sql="select * from sl_product,sl_psort where S_del=0 and P_del=0 ".$M_pinfo."  and P_sh=1 and P_sort=S_id order by P_top desc,P_order,P_time desc,P_id desc limit 5";
                s[[ 
                if($row["P_mid"]==0){
                	$zy="<span class=\"s0\">自营</span>";
            	}else{
            		$zy="<span class=\"s1\">".getrs("select M_shop from sl_member where M_id=".$row["P_mid"],"M_shop")."</span>";
        		}

            if($row["P_limit"]>0 and $row["P_limitlong"]>0 and $row["P_limitlong"]-(time()-strtotime($row["P_limittime"]))/3600>0){
              $P_price=$row["P_limit"];
              $l=date('Y-m-d H:i:s',strtotime('+'.$row["P_limitlong"].' hour',strtotime($row["P_limittime"])));
            }else{
              $P_price=p($row["P_price"]);
              $l="";
            }

$api=$api." <span id=\"dqsj".$i."\" style=\"display:none;\">2030/03/19 17:35:10</span>
 <ul class=\"u1 u1".$i."\">
 <li class=\"l1\"><a href=\"?type=productinfo&id=".$row["P_id"]."\" target=\"_blank\">
<div style=\"background-image:url(".pic(splitx($row["P_pic"],"|",0)).");background-repeat: no-repeat;background-position:center center;width:205px;height:205px;background-size: cover;position:relative;\" class=\"sss\" limit=\"".$l."\"></div>

</a>
 
 </li>
 <li class=\"l2\">
 <span class=\"s1\">本站</span><span class=\"s2\">精选</span>
 <a href=\"?type=productinfo&id=".$row["P_id"]."\" target=\"_blank\" title=\"".$row["P_title"]."\">".$row["P_title"]."</a>
 </li>
 <li class=\"l3\">￥".$P_price."</li>
 <li class=\"l4\">累计已售".$row["P_sold"]."件</li>

 <li class=\"l6\">".$zy."</li>
 <div style=\"float:right;margin-top:-25px\"><a href=\"?type=product&id=".$row["S_id"]."\">".$row["S_title"]."</a></div>
 </ul>
 ";
$i=$i+1;
                    ]]
</fh-function>
  </div>
 <!--推荐产品E-->
<fh-function>
$x=0;
$sql="select * from sl_psort where S_del=0 and S_sub=0 and S_show=1 order by S_order,S_id desc";
                s[[
                $api=$api."<div class=\"prolist\">

 <div class=\"pleft bg".($x%6)."\">
  <ul class=\"u1\">
  <li class=\"l1\"><span>".$row["S_title"]."</span></li>
  <li class=\"l2\"><span></span><span></span></li>
  <li class=\"l3 l31\" id=\"ejl".$x."_0\" onMouseOver=\"ejlover(".$x.",0)\">
  <a href=\"javascript:void(0);\">最新上架</a>
  </li>";
$i=1;
$sql2="select * from sl_psort where S_del=0 and S_show=1 and S_sub=".$row["S_id"]." order by S_order,S_id desc";
                s2[[
                        $api=$api."<li class=\"l3\" id=\"ejl".$x."_".$i."\" onMouseOver=\"ejlover(".$x.",".$i.")\">
  <a href=\"javascript:void(0);\">".$row2["S_title"]."</a>
  </li>";
  $i=$i+1;
                    ]]
  $api=$api."
    </ul>
  <span id=\"ejl".$x."all\" style=\"display:none;\">".(getrs("select count(S_id) as S_count from sl_psort where S_del=0 and S_show=1 and S_sub=".$row["S_id"],"S_count")+1)."</span>
 </div>

 <div class=\"proright\" id=\"rsmall".$x."_0\">
  <ul class=\"u1\">
  <li class=\"l1\">最新上架</li>
  <li class=\"l2\">精选商品共 <span>".getrs("select count(P_id) as P_count from sl_product,sl_psort where P_del=0 ".$M_pinfo."  and P_sh=1 and S_del=0 and P_sort=S_id and S_sub=".$row["S_id"],"P_count")."</span> 件</li>
  <li class=\"l3\"><a href=\"?type=product&id=".$row["S_id"]."\" target=\"_blank\">查看更多 >></a></li>
  </ul>

  <div class=\"dtj\">";
	$sql2="select * from sl_product,sl_psort where P_del=0 ".$M_pinfo."  and P_sh=1 and S_del=0 and P_sort=S_id and S_sub=".$row["S_id"]." order by P_view desc,P_time desc,P_id desc limit 5";
                s2[[

if($row2["P_limit"]>0 and $row2["P_limitlong"]>0 and $row2["P_limitlong"]-(time()-strtotime($row2["P_limittime"]))/3600>0){
  $P_price=$row2["P_limit"];
  $l=date('Y-m-d H:i:s',strtotime('+'.$row2["P_limitlong"].' hour',strtotime($row2["P_limittime"])));
}else{
  $P_price=p($row2["P_price"]);
  $l="";
}

                        $api=$api."<ul class=\"utj\">
  <li class=\"l1\">
  <a target=\"_blank\" href=\"?type=productinfo&id=".$row2["P_id"]."\"><img class=\"img1\" border=0 src=\"".pic(splitx($row2["P_pic"],"|",0))."\" /></a><span class=\"s1 bg".($x%6)."\">推荐</span>
  <span class=\"s2\" style=\"border:#ddd solid 1px;\">

  	<div style=\"background-image:url(".pic(splitx($row2["P_pic"],"|",0)).");background-repeat: no-repeat;background-position:center center;width:160px;height:160px;background-size: cover;position:relative;\" class=\"sss\" limit=\"".$l."\"></div>
  </span>
  </li>
  <li class=\"l2\"><a target=\"_blank\" href=\"?type=productinfo&id=".$row2["P_id"]."\" title=\"".$row2["P_title"]."\">".$row2["P_title"]."</a><span>￥".$P_price."</span></li>
  </li>
  </ul>";
                    ]]
$api=$api."

    </div>";
$sql2="select * from sl_psort,sl_product where S_del=0 and P_sh=1 and P_del=0 ".$M_pinfo."  and P_sort=S_id and S_sub=".$row["S_id"]." order by P_order,P_time desc,P_id desc limit 5";
                s2[[

if($row2["P_limit"]>0 and $row2["P_limitlong"]>0 and $row2["P_limitlong"]-(time()-strtotime($row2["P_limittime"]))/3600>0){
  $P_price=$row2["P_limit"];
  $l=date('Y-m-d H:i:s',strtotime('+'.$row2["P_limitlong"].' hour',strtotime($row2["P_limittime"])));
}else{
  $P_price=p($row2["P_price"]);
  $l="";
}

                        $api=$api."<ul class=\"u2\">
  <li class=\"l1\"><a target=\"_blank\" href=\"?type=productinfo&id=".$row2["P_id"]."\">


    <div style=\"background-image:url(".pic(splitx($row2["P_pic"],"|",0)).");background-repeat: no-repeat;background-position:center center;width:179px;height:179px;background-size: cover;position:relative;\" class=\"sss\" limit=\"".$l."\"></div>

  </a></li>
  <li class=\"l2\"><a target=\"_blank\" href=\"?type=productinfo&id=".$row2["P_id"]."\">".$row2["P_title"]."</a></li>
  <li class=\"l3\">￥<strong>".$P_price."</strong></li>
  <li class=\"l4\"><span class=\"s1\">已售".$row2["P_sold"]."</span><a href=\"?type=product&id=".$row2["S_id"]."\" class=\"s2\">".$row2["S_title"]."</a></li>
  </li>
  </ul>";
                    ]]

    $api=$api."</div>";

$j=1;
$sql2="select * from sl_psort where S_del=0 and S_show=1 and S_sub=".$row["S_id"]." order by S_order,S_id desc";
                s2[[
                        $api=$api."<div class=\"proright\" style=\"display:none;\" id=\"rsmall".$x."_".$j."\">
  <ul class=\"u1\">
  <li class=\"l1\">".$row2["S_title"]."</li>
  <li class=\"l2\">精选商品共 <span>".getrs("select count(P_id) as P_count from sl_product where P_sh=1 and P_sort=".$row2["S_id"],"P_count")."</span> 件</li>
  <li class=\"l3\"><a href=\"?type=product&id=".$row2["S_id"]."\" target=\"_blank\">查看更多 >></a></li>
  </ul>

  <div class=\"dtj\">";

$sql3="select * from sl_product where P_del=0 ".$M_pinfo."  and P_sh=1 and P_sort=".$row2["S_id"]." order by P_view desc,P_time desc,P_id desc limit 5";
                s3[[

if($row3["P_limit"]>0 and $row3["P_limitlong"]>0 and $row3["P_limitlong"]-(time()-strtotime($row3["P_limittime"]))/3600>0){
  $P_price=$row3["P_limit"];
  $l=date('Y-m-d H:i:s',strtotime('+'.$row3["P_limitlong"].' hour',strtotime($row3["P_limittime"])));
}else{
  $P_price=p($row3["P_price"]);
  $l="";
}

                        $api=$api."<ul class=\"utj\">
  <li class=\"l1\">
  <a target=\"_blank\" href=\"?type=productinfo&id=".$row3["P_id"]."\"><img class=\"img1\" border=0 src=\"".pic(splitx($row3["P_pic"],"|",0))."\" /></a><span class=\"s1 bg".($x%6)."\">推荐</span>
  <span class=\"s2\" style=\"border:#ddd solid 1px;\">

  	<div style=\"background-image:url(".pic(splitx($row3["P_pic"],"|",0)).");background-repeat: no-repeat;background-position:center center;width:179px;height:179px;background-size: cover;position:relative;\" class=\"sss\" limit=\"".$l."\"></div>

  </span>
  </li>
  <li class=\"l2\"><a target=\"_blank\" href=\"?type=productinfo&id=".$row3["P_id"]."\" title=\"".$row3["P_title"]."\">".$row3["P_title"]."</a><span>￥".$P_price."</span></li>
  </li>
  </ul>";
                    ]]
    $api=$api."
    </div>";
  
$sql3="select * from sl_product where P_del=0 ".$M_pinfo."  and P_sh=1 and P_sort=".$row2["S_id"]." order by P_time desc,P_id desc limit 5";
                s3[[
if($row3["P_limit"]>0 and $row3["P_limitlong"]>0 and $row3["P_limitlong"]-(time()-strtotime($row3["P_limittime"]))/3600>0){
  $P_price=$row3["P_limit"];
  $l=date('Y-m-d H:i:s',strtotime('+'.$row3["P_limitlong"].' hour',strtotime($row3["P_limittime"])));
}else{
  $P_price=p($row3["P_price"]);
  $l="";
}
                        $api=$api."<ul class=\"u2\">
  <li class=\"l1\"><a target=\"_blank\" href=\"?type=productinfo&id=".$row3["P_id"]."\">
    <div style=\"background-image:url(".pic(splitx($row3["P_pic"],"|",0)).");background-repeat: no-repeat;background-position:center center;width:179px;height:179px;background-size: cover;position:relative;\" class=\"sss\" limit=\"".$l."\"></div>
    
  </a></li>
  <li class=\"l2\"><a target=\"_blank\" href=\"?type=productinfo&id=".$row3["P_id"]."\">".$row3["P_title"]."</a></li>
  <li class=\"l3\">￥<strong>".$P_price."</strong></li>
  <li class=\"l4\"><span class=\"s1\">已售".$row3["P_sold"]."</span><a href=\"?type=product&id=".$row2["S_id"]."\" class=\"s2\">".$row2["S_title"]."</a></li>
  </li>
  </ul>";
                    ]]

    $api=$api."
 </div>";
 $j+=1;
                    ]]


$api=$api."</div>";
$x+=1;
                ]]
</fh-function>

<span id="bigiall" style="display:none;">6</span>
<!--列表E-->


<!--资讯B-->
<ul class="newscap">
<li class="l1">资讯速递</li>
<li class="l2">
<fh-function>
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc";
        s[[

        $api=$api."&nbsp;&nbsp;/&nbsp;&nbsp;<a href=\"?type=news&id=".$row["S_id"]."\">".$row["S_title"]."</a>";
        ]]
        </fh-function>

</li>
</ul>
<div class="newsleft">

 <div class="ntp">

<fh-function>
  $i=1;


        $sql2="select * from sl_news where N_del=0 ".$M_ninfo."  and N_sh=1 order by N_top desc,N_order,N_id desc limit 2";
        s2[[


if(strpos($row2["N_content"],"[fh_free]")!==false || $row2["N_price"]==0){
    $intro=mb_substr(strip_tags(splitx($row2["N_content"],"[fh_free]",0)),0,200,"utf-8");
  }else{
    $intro="内容加密";
  }


$api=$api."  <ul class=\"u1 uh".$i."\">
 <li class=\"l1\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\"><img src=\"".pic($row2["N_pic"])."\" width=\"190\" height=\"155\" /></a></li>
 <li class=\"l2\">
 <a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\" class=\"a1\" title=\"".$row2["N_title"]."\">".$row2["N_title"]."</a>
 <span class=\"s1\">　　".$intro."</span>
 <a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\" class=\"a2\">阅读详情</a>
 </li>
 </ul>";
 $i=$i+1;


        ]]
        </fh-function>


  </div>
 <div class="nqh">
 
		<div class="picMarquee-left">
			<div class="hd">
            <span>精彩热点聚集</span>
				<a class="next"></a>
				<a class="prev"></a>
			</div>
			<div class="bd">
				<ul class="picList">


<fh-function>
 

        $sql2="select * from sl_news where N_del=0 ".$M_ninfo."  and N_sh=1 order by N_view desc limit 5";
        s2[[


if(strpos($row2["N_content"],"[fh_free]")!==false || $row2["N_price"]==0){
    $intro=mb_substr(strip_tags(splitx($row2["N_content"],"[fh_free]",0)),0,200,"utf-8");
  }else{
    $intro="内容加密";
  }


$api=$api."  <li>
            <div class=\"pic\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\"><img src=\"".pic($row2["N_pic"])."\" /></a></div>
            <div class=\"title\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\" title=\"".$row2["N_title"]."\">".$row2["N_title"]."</a></div>
          </li>";

        ]]

        </fh-function>



                					
									</ul>
			</div>
		</div>
<script id="jsID" type="text/javascript">
		 var ary = location.href.split("&");
		jQuery(".picMarquee-left").slide( { mainCell:".bd ul",autoPlay:true,effect:ary[1],vis:ary[2],interTime:ary[3],opp:ary[4],pnLoop:ary[5],trigger:ary[6],mouseOverStop:ary[7] });
		</script>
 
 </div>
  <div class="nty nty1">
  <ul class="uty1">
  <fh-function>
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 1";
        s[[

        $api=$api."<li class=\"l1\">".$row["S_title"]."</li>
  <li class=\"l2\"><a href=\"?type=news&id=".$row["S_id"]."\">更多>></a></li>";
        ]]

        </fh-function>
  </ul>
  <ul class="uty2">

<fh-function>
  $i=1;
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 1";
        s[[

        $sql2="select * from sl_news,sl_nsort where N_del=0 ".$M_ninfo."  and N_sh=1 and S_del=0 and N_sort=S_id and S_sub=".$row["S_id"]." order by N_top desc,N_order,N_id desc limit 8";
        s2[[

if(strpos($row2["N_content"],"[fh_free]")!==false || $row2["N_price"]==0){
    $intro=mb_substr(strip_tags(splitx($row2["N_content"],"[fh_free]",0)),0,200,"utf-8");
  }else{
    $intro="内容加密";
  }

$api=$api."  <li class=\"l1\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\" title=\"".$row2["N_title"]."\">".$row2["N_title"]."</a></li>";
 $i=$i+1;
        ]]

        ]]
        </fh-function>

    </ul>
 </div>
  <div class="nty nty2">
  <ul class="uty1">
    <fh-function>
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 1,1";
        s[[

        $api=$api."<li class=\"l1\">".$row["S_title"]."</li>
  <li class=\"l2\"><a href=\"?type=news&id=".$row["S_id"]."\">更多>></a></li>";
        ]]

        </fh-function>

  
  </ul>
  <ul class="uty2">

    <fh-function>
  $i=1;
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 1,1";
        s[[

        $sql2="select * from sl_news,sl_nsort where N_del=0 ".$M_ninfo."  and N_sh=1 and S_del=0 and N_sort=S_id and S_sub=".$row["S_id"]." order by N_top desc,N_order,N_id desc limit 8";
        s2[[


if(strpos($row2["N_content"],"[fh_free]")!==false || $row2["N_price"]==0){
    $intro=mb_substr(strip_tags(splitx($row2["N_content"],"[fh_free]",0)),0,200,"utf-8");
  }else{
    $intro="内容加密";
  }


$api=$api."  <li class=\"l1\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\" title=\"".$row2["N_title"]."\">".$row2["N_title"]."</a></li>";
 $i=$i+1;
        ]]

        ]]
        </fh-function>

    </ul>
 </div>
 
</div>

<div class="newsright">
 <div class="ncap">
  <a href="javascript:void(0);" onMouseOver="newscaponc(0)" id="newscap0" class="a1"><fh-function>
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 2,1";
        s[[

        $api=$api.$row["S_title"];
        ]]

        </fh-function></a>
  <a href="javascript:void(0);" onMouseOver="newscaponc(1)" id="newscap1"><fh-function>
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 3,1";
        s[[

        $api=$api.$row["S_title"];
        ]]

        </fh-function></a>
  </div>

  <div class="nmain" id="nmain0">


<fh-function>
  $i=1;
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 2,1";
        s[[

        $sql2="select * from sl_news,sl_nsort where N_del=0 ".$M_ninfo."  and N_sh=1 and S_del=0 and N_sort=S_id and S_sub=".$row["S_id"]." order by N_top desc,N_order,N_id desc limit 2";
        s2[[

if(strpos($row2["N_content"],"[fh_free]")!==false || $row2["N_price"]==0){
    $intro=mb_substr(strip_tags(splitx($row2["N_content"],"[fh_free]",0)),0,200,"utf-8");
  }else{
    $intro="内容加密";
  }

$api=$api."<ul class=\"u1\">
  <li class=\"l1\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\"><img src=\"".pic($row2["N_pic"])."\" /></a></li>
  <li class=\"l2\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\" class=\"a1\" title=\"".$row2["N_title"]."\">".$row2["N_title"]."</a><span class=\"s1\">
　　".$intro."</span></li>
  </ul>";
 $i=$i+1;
        ]]

        ]]
        </fh-function>




    <ul class="u2">

<fh-function>
  $i=1;
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 2,1";
        s[[

        $sql2="select * from sl_news,sl_nsort where N_del=0 ".$M_ninfo."  and N_sh=1 and S_del=0 and N_sort=S_id and S_sub=".$row["S_id"]." order by N_top desc,N_order,N_id desc limit 2,10";
        s2[[


if(strpos($row2["N_content"],"[fh_free]")!==false || $row2["N_price"]==0){
    $intro=mb_substr(strip_tags(splitx($row2["N_content"],"[fh_free]",0)),0,200,"utf-8");
  }else{
    $intro="内容加密";
  }


$api=$api."<li class=\"l1\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\" title=\"".$row2["N_title"]."\">".$row2["N_title"]."</a></li>";
 $i=$i+1;
        ]]

        ]]
        </fh-function>

    </ul>
 </div>
  <div class="nmain" id="nmain1" style="display:none;">
    <fh-function>
  $i=1;
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 3,1";
        s[[

        $sql2="select * from sl_news,sl_nsort where N_del=0 ".$M_ninfo."  and N_sh=1 and S_del=0 and N_sort=S_id and S_sub=".$row["S_id"]." order by N_top desc,N_order,N_id desc limit 2";
        s2[[

if(strpos($row2["N_content"],"[fh_free]")!==false || $row2["N_price"]==0){
    $intro=mb_substr(strip_tags(splitx($row2["N_content"],"[fh_free]",0)),0,200,"utf-8");
  }else{
    $intro="内容加密";
  }


$api=$api."<ul class=\"u1\">
  <li class=\"l1\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\"><img src=\"".pic($row2["N_pic"])."\" /></a></li>
  <li class=\"l2\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\" class=\"a1\" title=\"".$row2["N_title"]."\">".$row2["N_title"]."</a><span class=\"s1\">
　　".$intro."</span></li>
  </ul>";
 $i=$i+1;
        ]]

        ]]
        </fh-function>




    <ul class="u2">

<fh-function>
  $i=1;
        $sql="select * from sl_nsort where S_del=0 and S_show=1 and S_sub=0 order by S_order,S_id desc limit 3,1";
        s[[

        $sql2="select * from sl_news,sl_nsort where N_del=0 ".$M_ninfo."  and N_sh=1 and S_del=0 and N_sort=S_id and S_sub=".$row["S_id"]." order by N_top desc,N_order,N_id desc limit 2,10";
        s2[[

if(strpos($row2["N_content"],"[fh_free]")!==false || $row2["N_price"]==0){
    $intro=mb_substr(strip_tags(splitx($row2["N_content"],"[fh_free]",0)),0,200,"utf-8");
  }else{
    $intro="内容加密";
  }

$api=$api."<li class=\"l1\"><a href=\"?type=newsinfo&id=".$row2["N_id"]."\" target=\"_blank\" title=\"".$row2["N_title"]."\">".$row2["N_title"]."</a></li>";
 $i=$i+1;
        ]]

        ]]
        </fh-function>

    </ul>
 </div>
 </div>
<!--资讯E-->

</div>

<div class="bfb bfbbottom">
<div class="yjcode">

 <div class="d1">
<ul class="u1">
<fh-function>
$sql="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=0 and not U_type='index' order by U_order,U_id desc";
s[[

  if($row["U_type"]=="link"){
    $link=$row["U_link"];
    $target="_blank";
  }else{
    $link="?type=".$row["U_type"]."&id=".$row["U_typeid"];
    $target="_self";
  }


     $api=$api."
  <li>
 <span><a href=\"".$link."\" target=\"".$target."\">".$row["U_title"]."</a></span>";

$sql2="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=".$row["U_id"]." order by U_order,U_id desc";
s2[[

  if($row2["U_type"]=="link"){
    $link2=$row2["U_link"];
    $target2="_blank";
  }else{
    $link2="?type=".$row2["U_type"]."&id=".$row2["U_typeid"];
    $target2="_self";
  }

    $api=$api."<a href=\"".$link2."\" target=\"".$target2."\" class=\"a1\">".$row2["U_title"]."</a><br>";
  ]]
      $api=$api."
   </li>";
    ]]

</fh-function>


</ul>
 
  
 </div>
 
 <div class="d2">


 <strong>联系我们</strong><br>
 [fh_contact]
</div>
 
 <div class="d3">
<img src="media/[fh_qrcode]" width="100" height="100" /><br>二维码
  </div>
 <ul class="u2">
 <li class="l1">
友情链接：
<fh-function>
        $sql="select * from sl_link where L_del=0 order by L_id desc";
        s[[

        $api=$api."<a href=\"".$row["L_link"]."\" target=\"_blank\">".$row["L_title"]."</a>&nbsp;&nbsp;";
        ]]
        </fh-function>

 <br>
[fh_copyright][fh_beian][fh_code]
 </li>
 <li class="l2">
  </li>
 </ul>
 
</div>
</div>

<script language="javascript">
function indexYJTSCLO(){
layer.closeAll();
}
if(document.getElementById("rightcontact")){
getIndexCookie();
document.getElementById("rightcontact").className="contact fontyh disyes";
document.getElementById("righttel").className="tel fontyh disno";
}

function limit(){
  $(".sss").each(function(){
      if($(this).attr("limit")!=""){
      var leftTime = new Date($(this).attr("limit")) - new Date();
      var d, h, m, s;
      if (leftTime < 0) {
        return;
      }
      d = Math.floor(leftTime / 1000 / 60 / 60 / 24);
      h = Math.floor((leftTime / 1000 / 60 / 60) % 24);
      m = Math.floor((leftTime / 1000 / 60) % 60);
      s = Math.floor((leftTime / 1000) % 60);
      const str = `${d}天${h}:${m}:${s}`;
        $(this).html("<div style=\"position: absolute;left: 0px;bottom: 0px;background: rgba(0,0,0,0.5);color: #fff;width:100%;height:25px;font-size:12px;line-height:25px;text-align:left\"><img src=\"https://misc.360buyimg.com/product/search/1.0.8/css/i/search.presell.gif\" style=\"margin:5px 5px -5px 5px;display:inline-block;height:17px;width:17px\">限时特惠 "+str+" 后结束</div>");
      }
    });
}
limit();
setInterval(limit, 1000);

</script>
[fh_kefu]
</body>
</html>