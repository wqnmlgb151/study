<fh-function>
$page=$_GET["page"];
$tag=t($_GET["tag"]);

$POST=$_GET;

$url=gethttp().$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
if($tag==""){
  $taginfo="";
}else{
  $taginfo=" and CONCAT(\" \",P_tag,\" \") like '% ".$tag." %'";
}

$M_id=intval($_GET["M_id"]);
if($page==""){
  $page=1;
}
if($M_id!=0){
  $M_info=" and P_mid=$M_id ".$taginfo;
}else{
  $M_info=" and P_sh=1".$taginfo;
}

$sql="select * from sl_psort where S_id=".$id;
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  if (mysqli_num_rows($result) > 0) {
    $S_sub=$row["S_sub"];
  }

if($id==0){
  $sql="select count(P_id) as P_count from sl_product where P_del=0 ".$M_pinfo."  ".shuxing("P_shuxing")." $M_info order by P_order,P_time desc,P_id desc";
}else{
  if($S_sub==0){
    $sql="select count(P_id) as P_count from sl_product,sl_psort where S_del=0 ".shuxing("P_shuxing")." $M_info and P_del=0 ".$M_pinfo."  and P_sort=S_id and S_sub=".$id." order by P_order,P_time desc,P_id desc";
  }else{
    $sql="select count(P_id) as P_count from sl_product,sl_psort where S_del=0 ".shuxing("P_shuxing")." $M_info and P_del=0 ".$M_pinfo."  and P_sort=S_id and S_id=".$id." order by P_order,P_time desc,P_id desc";
  }
}

$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$P_count=$row["P_count"];

$page_num=intval($P_count/15)+1;
if($P_count%15 ==0){
  $page_num=$page_num-1;
}

function url($url,$key,$value){
  $url=str_replace("&".$key."=".str_replace("%3A",":",urlencode($value)),"",$url);
  return $url;
}

</fh-function>
<html>
<head>
<meta http-equiv="x-ua-compatible" content="ie=7" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>[S_title] - [fh_title]</title>
<link href="media/[fh_ico]" rel="shortcut icon" />
<meta name="description" content="[S_content]" />
<meta name="keywords" content="[S_keywords]" />

<link href="template/t11/css/global.css?t=0823577001588645663" rel="stylesheet" type="text/css" />
<link href="template/t11/css/basic.css?t=0823577001588645663" rel="stylesheet" type="text/css" />
<link href="template/t11/css/product/index.css?t=0823577001588645663" rel="stylesheet" type="text/css" />
<script language="javascript" src="template/t11/js/global.js?t=0823577001588645663"></script>
<script language="javascript" src="template/t11/js/basic.js?t=0823577001588645663"></script>
<script language="javascript" src="template/t11/js/jquery.min.js?t=0823577001588645663"></script>
<script language="javascript" src="template/t11/js/layer.js?t=0823577001588645663"></script>
<script language="javascript" src="template/t11/js/product/index.js?t=0823577001588645663"></script>
<link href="css/Pager.css" rel="stylesheet" type="text/css" />
<style type="text/css">
body{background-color:#F2F2F3;}
body div{margin:auto}
ul{
    list-style: none;
}
.drop-down-content{
    display: none;
    z-index: 99999;
    position: absolute;
    background: #ffffff;
    top:170px;
    text-align: center;
    padding: 0px;
    margin-left: 10px;
    box-shadow: 0px 0px 5px #888888;
}
.drop-down-content li a{
  margin-left: 0px !important;
  padding: 10px !important;
  font-size: 14px !important;
}
.drop-down-content li:hover a{
    background-color:#f7f7f7;
}
.nav .drop-down:hover .drop-down-content{
    display: block;
}
.nav>li{
    float: left;
}
</style>
</head>
<body>
<div class="bfb bfbtop">
<div class="yjcode">

<div class="dts">欢迎来到[fh_title]</div>
<div class="toplogin">

<fh-function>
      if($_SESSION["M_login"]==""){
        $api="<a href=\"member/login.php\" class=\"a1\">登录</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
        <a href=\"member/reg.php\">免费注册</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;";
      }else{
      $api="<a href=\"member/\" class=\"a1\">".$_SESSION["M_login"]."</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
      <a href=\"member/cart.php\" class=\"a1\">购物车</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
      <a href=\"member/login.php?action=unlogin\">退出</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;";
      }
</fh-function>

 </div>
</div>
</div>

<div class="bfb bfbtop1">
<div class="yjcode">
 <div class="top1">
  <h1 class="logo"><a href="./"><img alt="[fh_title]" border="0" src="media/[fh_logo]" height="50" /></a></h1>
  
  <div class="resou">
  <form name="topf1" method="post" action="./?type=search">
  <ul class="u1">
  <li class="l1" onMouseOver="topover()" onMouseOut="topout()">
  <span id="topnwd">全部</span>
  <div id="topdiv" style="display:none;">
  <a href="javascript:void();" onClick="topjconc(0,'全部')">全部</a>
  <a href="javascript:void();" onClick="topjconc(1,'商品')">商品</a>
  <a href="javascript:void();" onClick="topjconc(2,'店铺')">店铺</a>
  <a href="javascript:void();" onClick="topjconc(3,'文章')">文章</a>
  </div>
  </li>
  <li class="l2"><input name="keyword" id="topt" type="text" /><input type="hidden" name="type" id="type" value="0"></li>
  <li class="l3"><input type="submit" value="搜 索" /></li>
  </ul>
  </form>
  <div class="d1">
  热门搜索：
   <fh-function>
$keyword=explode(",",$H_data["C_hotwords"]);
for($i=0;$i<count($keyword);$i++){
  $api=$api."<a href=\"./?type=search&keyword=".$keyword[$i]."\" target=\"_blank\">".$keyword[$i]."</a>&nbsp;&nbsp;&nbsp;";
}
</fh-function>
    </div>
  </div>
  
<style>
.shopx{float: right;margin-top: 45px;font-size: 18px;background: #f7f7f7;padding: 10px;border-radius: 5px;border: solid 1px #EEEEEE}
.shopx:hover{background: #0099ff;color: #ffffff}
</style>
<fh-function>
$C_rzon=getrs("select C_rzon from sl_config","C_rzon");
if($C_rzon==1){
  $api=$api."<a href=\"member/seller.php\"><div class=\"shopx\"><img src=\"template/t11/img/shop.png\" width=\"22\" style=\"vertical-align: top;\"> 商家入驻</div></a>";
}
</fh-function>
 
  <div class="menu fontyh">
   <!--左B-->
      <span id="typeallnum" style="display:none;"><fh-function>$api=$api.getrs("select count(S_id) as S_count from sl_psort where S_del=0 and S_sub=0","S_count");</fh-function></span>
   <div class="m1" onmouseover="leftmenuover()" onmouseout="leftmenuout()">
   <span class="t">全部商品分类</span>
   <!--主导航下拉开始-->
   <div class="menun fontyh" id="leftmenu" style="display:none;">


<fh-function>
  function is_haves($a,$b){
  if(in_array($a,$b)){
      return true;
  }else{
      return false;
  }
}
$i=1;
$sql="select * from sl_psort where S_del=0 and S_sub=0 order by S_order,S_id desc";
                s[[
                $api=$api."<div class=\"menu1\" id=\"yhmenu".$i."\" onmouseover=\"yhmenuover(".$i.")\" onmouseout=\"yhmenuout(".$i.")\">
     <div class=\"mleft\">
      <ul class=\"u1\"><li class=\"l1\"></li><li class=\"l2\"><a href=\"?type=product&id=".$row["S_id"]."\"><b>".$row["S_title"]."</b></a></li><li class=\"l1\"></li></ul>
      <ul class=\"u2\">";

$sql2="select * from sl_psort where S_del=0 and S_sub=".$row["S_id"]." order by S_order,S_id desc limit 9";
                s2[[
                        $api=$api."<li><a href=\"?type=product&id=".$row2["S_id"]."\" title=\"".$row2["S_title"]."\">".$row2["S_title"]."</a></li>";
                    ]]
$api=$api."
            </ul>
     </div>
     <div class=\"rmenu rmenu1\" style=\"display:none;margin-top:-".(110*$i)."px;height:658px;overflow:hidden;\" id=\"rmenu".$i."\">
      <div class=\"esmenu\">


      <ul class=\"esu1\">
      <li class=\"l1\"><span class=\"s1\"></span><span class=\"s2\">分类：</span></li>
      <li class=\"l2\">
      <div>";

$sql2="select * from sl_psort where S_del=0 and S_sub=".$row["S_id"]." order by S_order,S_id desc";
                s2[[
                        $api=$api."<span class=\"sfont\"><a href=\"?type=product&id=".$row2["S_id"]."\">".$row2["S_title"]."</a></span>";
                    ]]
$api=$api."
             </div>
      </li>
      </ul>";


$arr = array();
$sql2="select * from sl_product,sl_psort where S_del=0 and P_del=0 ".$M_pinfo."  and P_sh=1 and P_sort=S_id and S_sub=".$row["S_id"]." order by P_top desc,P_order,P_time desc,P_id desc";
$result2 = mysqli_query($conn,  $sql2);
if (mysqli_num_rows($result2) > 0) {
while($row2 = mysqli_fetch_assoc($result2)) {
        $sx=explode("\r\n",$row2["P_shuxing"]);
        for($ii=0;$ii<count($sx);$ii++){
          if(splitx($sx[$ii],":",0)!=""){
            $c=json_decode("{\"S_title\":\"".splitx($sx[$ii],":",0)."\"}",true);
            if(!is_haves($c,$arr)){
              array_push($arr,$c);
            }
          }
        }
    }
} 


for($ii=0;$ii<count($arr);$ii++){
  $arr[$ii]["list"]=array();
  $result2 = mysqli_query($conn,  $sql2);
  if (mysqli_num_rows($result) > 0) {
  while($row2 = mysqli_fetch_assoc($result2)) {
          $sx=explode("\r\n",$row2["P_shuxing"]);
          for($m=0;$m<count($sx);$m++){
            $s=splitx($sx[$m],":",0);
            if($s==$arr[$ii]["S_title"]){
              $v=splitx($sx[$m],":",1);
                if($v!=""){
                  $x=json_decode("{\"shuxing\":\"".$v."\"}",true);
                  if(!is_haves($x,$arr[$ii]["list"])){
                    array_push($arr[$ii]["list"],$x);
                  }
                }
            }
        }
      }
  }
}



for($ii=0;$ii<count($arr);$ii++){
  for($jj=0;$jj<count($arr[$ii]["list"]);$jj++){
    $shuxing=$shuxing."<span class=\"sfont\"><a href=\"?type=product&id=".$row["S_id"]."&f0=".$arr[$ii]["S_title"].":".$arr[$ii]["list"][$jj]["shuxing"]."\">".$arr[$ii]["list"][$jj]["shuxing"]."</a></span>";
  }

  $api=$api. "
  <ul class=\"esu1\">
      <li class=\"l1\"><span class=\"s1\"></span><span class=\"s2\">".$arr[$ii]["S_title"]."：</span></li>
      <li class=\"l2\">
      <div>".$shuxing."</div>
      </li>
      </ul>";
  $shuxing="";
}

      
      $api=$api. "</div>
      <div class=\"shoptj\" style=\"height:658px;overflow:hidden;\">
      	<ul class=\"shopu1\">
      <li class=\"l1\"><a href=\"./\" target=\"_blank\"><img width=\"110\" height=\"110\" src=\"media/[fh_ico]\" /></a></li>
      <li class=\"l2\"><a href=\"./\" target=\"_blank\">官方旗舰店</a><span class=\"s1\">共有 <span class=\"red\">".getrs("select count(P_id) as P_count from sl_product where P_del=0 ".$M_pinfo."  and P_mid=0","P_count")."</span> 件商品在售</span></li>
      </ul>";


$sql2="select * from sl_member where M_del=0 and M_type=1 order by rand() desc limit 5";
                s2[[
                  
                    $api=$api."<ul class=\"shopu1\">
      <li class=\"l1\"><a href=\"./?type=product&M_id=".$row2["M_id"]."\" target=\"_blank\"><img width=\"110\" height=\"110\" src=\"media/".$row2["M_head"]."\"/></a></li>
      <li class=\"l2\"><a href=\"./?type=product&M_id=".$row2["M_id"]."\" target=\"_blank\">".$row2["M_shop"]."</a><span class=\"s1\">共有 <span class=\"red\">".getrs("select count(P_id) as P_count from sl_product where P_del=0 ".$M_pinfo."  and P_sh=1 and P_mid=".$row2["M_id"],"P_count")."</span> 件商品在售</span></li>
      </ul>";
                ]]

      	$api=$api."

            </div>
     </div>
    </div>";
    $i=$i+1;
                    ]]
</fh-function>
        <!--商品E-->
   </div>
   <!--主导航下拉结束-->
   </div> 
   <!--左E-->

   <div class="m2">

    <ul class="nav">
    <fh-function>
                $sql="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=0 order by U_order,U_id desc";
                s[[
                  if($type==$row["U_type"] && $id==$row["U_typeid"]){
                    $class="nav-li active";
                  }else{
                    $class="nav-li margin-left-0";
                  }

                  if($row["U_type"]=="link"){
                    $link=$row["U_link"];
                    $target="_blank";
                  }else{
                    $link="?type=".$row["U_type"]."&id=".$row["U_typeid"];
                    $target="_self";
                  }

                    $api=$api."<li class=\"drop-down\"><a style=\"padding-bottom: 15px;\" href=\"".$link."\" target=\"".$target."\" title=\"".$row["U_title"]."\">".$row["U_title"]."</a><ul class=\"drop-down-content\">";

                    $sql2="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=".$row["U_id"]." order by U_order,U_id desc";
                    s2[[
                      
                      if($row2["U_type"]=="link"){
                        $link2=$row2["U_link"];
                        $target="_blank";
                      }else{
                        $link2="?type=".$row2["U_type"]."&id=".$row2["U_typeid"];
                        $target="_self";
                      }
                            $api=$api."<li><a href=\"".$link2."\" target=\"".$target."\">".$row2["U_title"]."</a></li>";
                        ]]

$api=$api."</ul></li>";
                ]]

              </fh-function>
            </ul>
      </div>
  </div>
 
 </div>
</div>
</div>

<div class="yjcode">

 <ul class="mydqwz">
 <li class="l1">
 当前位置：<a href="./">首页</a> > 
 <a href="">[S_title]</a> >      </li>
 </ul>
 
 <!--筛选B-->
 <div class="proxuan" id="proxuan" style="min-height: 100px">
 
  <ul class="u1">
  <li class="l1">商品类目：</li>
  <li class="l2">
  <span><a href="?type=product&id=0" class="<fh-function>
  if($id==0){
$api=$api."ah";
}else{
$api=$api."an";
}</fh-function>">全部</a></span>

<fh-function>
        $sql="select * from sl_psort where S_sub=0 and S_del=0 order by S_id desc";
        s[[
        if($id==$row["S_id"] || getrs("select * from sl_psort where S_id=$id","S_sub")==$row["S_id"]){
        $class="a1";
    }else{
    $class="";
}
        $api=$api."<span><a href=\"?type=product&id=".$row["S_id"]."\"  class=\"".$class."\">".$row["S_title"]."</a></span>";
        ]]
        </fh-function>

    </li>
  </ul>
 

  

<fh-function>
if($id!=0){	
if(getrs("select * from sl_psort where S_id=$id","S_sub")==0){
	$class="ah";
	$idx=$id;
}else{
	$class="an";
	$idx=getrs("select * from sl_psort where S_id=$id","S_sub");
}

$api=$api."<ul class=\"u1\">
  <li class=\"l1\">二级分类：</li>
  <li class=\"l2\"><span><a href=\"?type=product&id=$idx\" class=\"$class\">全部</a></span>";

        $sql="select * from sl_psort where (S_sub=$id or S_sub=".getrs("select * from sl_psort where S_id=$id","S_sub").") and not S_sub=0 and S_del=0 order by S_id desc";
        s[[
        if($id==$row["S_id"]){
        $class="a1";
    }else{
    $class="";
}
        $api=$api."<span><a href=\"?type=product&id=".$row["S_id"]."\"  class=\"".$class."\">".$row["S_title"]."</a></span>";
        ]]
$api=$api."</li></ul>";
}
</fh-function>

    

<fh-function>

$arr = array();
if($id==0){
  //$sql="select * from sl_product where P_del=0 ".$M_pinfo."  $M_info order by P_top desc,P_order,P_time desc,P_id desc";
}else{
  if($S_sub==0){
    $sql="select * from sl_product,sl_psort where S_del=0 $M_info and P_del=0 ".$M_pinfo."  and P_sort=S_id and S_sub=".$id." order by P_top desc,P_order,P_time desc,P_id desc";
  }else{
    $sql="select * from sl_product,sl_psort where S_del=0 $M_info and P_del=0 ".$M_pinfo."  and P_sort=S_id and S_id=".$id." order by P_top desc,P_order,P_time desc,P_id desc";
  }
}

$result = mysqli_query($conn,  $sql);
if (mysqli_num_rows($result) > 0) {
while($row = mysqli_fetch_assoc($result)) {
        $sx=explode("\r\n",$row["P_shuxing"]);
        for($i=0;$i<count($sx);$i++){
          if(splitx($sx[$i],":",0)!=""){
            $c=json_decode("{\"S_title\":\"".splitx($sx[$i],":",0)."\"}",true);
            if(!is_haves($c,$arr)){
              array_push($arr,$c);
            }
          }
        }
    }
} 


for($i=0;$i<count($arr);$i++){
  $arr[$i]["list"]=array();
  $result = mysqli_query($conn,  $sql);
  if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
          $sx=explode("\r\n",$row["P_shuxing"]);
          for($m=0;$m<count($sx);$m++){
            $s=splitx($sx[$m],":",0);
            if($s==$arr[$i]["S_title"]){
              $v=splitx($sx[$m],":",1);
                if($v!=""){
                  $x=json_decode("{\"shuxing\":\"".$v."\"}",true);
                  if(!is_haves($x,$arr[$i]["list"])){
                    array_push($arr[$i]["list"],$x);
                  }
                }
            }
        }
      }
  }
}


for($i=0;$i<count($arr);$i++){
  for($j=0;$j<count($arr[$i]["list"]);$j++){
    if($_GET["f".$i]==$arr[$i]["S_title"].":".$arr[$i]["list"][$j]["shuxing"]){
      $selected="a1";
    }else{
      $selected="";
    }


    $shuxing=$shuxing."<span><a href=\"".url($url,"f".$i,$_GET["f".$i])."&f".$i."=".$arr[$i]["S_title"].":".$arr[$i]["list"][$j]["shuxing"]."\" class=\"".$selected."\">".$arr[$i]["list"][$j]["shuxing"]."</a></span>";
  }

if($_GET["f".$i]==""){
  $selected="ah";
}else{
  $selected="an";
}



  $api=$api. "<ul class=\"u1\">
  <li class=\"l1\">".$arr[$i]["S_title"]."：</li>
  <li class=\"l2\">
  <span><a href=\"".url($url,"f".$i,$_GET["f".$i])."&f".$i."=\" class=\"".$selected."\">不限</a></span>".$shuxing."</li>
  </ul>";
  
  $shuxing="";
}

</fh-function>


 </div>
 <!--筛选E-->


 <!--交易B-->
 <div class="projyi" id="projyi">
  <div class="ptj">￥<fh-function>$api=$api.$L_sum;</fh-function></div>
  <ul class="u1">
  <li class="l1"></li>
  <li class="l2">交易动态</li>
  <li class="l3"></li>
  <li class="l4">网站真实交易数据</li>
  </ul>
 <!--滚动开始-->
 <div class="gdmain" id="Marquee1">


<fh-function>

$sql="select * from sl_orders,sl_member where M_del=0 and M_id=O_mid and O_del=0 order by O_id desc limit 20";
    s[[
            $api=$api."<div class=\"gd\">
 <ul class=\"u2\">
 <li class=\"l1\">".date("m-d",strtotime($row["O_time"]))."</li>
 <li class=\"l2\">".enname($row["M_login"]) ."￥".($row["O_price"]*$row["O_num"])."</li>
 <li class=\"l3\"><span><a href=\"?type=productinfo&id=".$row["O_pid"]."\" target=\"_blank\">".$row["O_title"]."</a></span></li>
 </ul>
 </div>";
        ]]

</fh-function>


  <script>
 var Mar1 = document.getElementById("Marquee1");
 var child_div1=Mar1.getElementsByTagName("div")
 var picH1 = 70;//移动高度
 var scrollstep1=3;//移动步幅,越大越快
 var scrolltime1=40;//移动频度(毫秒)越大越慢
 var stoptime1=2000;//间断时间(毫秒)
 var tmpH1 = 0;
 Mar1.innerHTML += Mar1.innerHTML;
 function start1(){
	if(tmpH1 < picH1){
		tmpH1 += scrollstep1;
		if(tmpH1 > picH1 )tmpH1 = picH1 ;
		Mar1.scrollTop = tmpH1;
		setTimeout(start1,scrolltime1);
	}else{
		tmpH1 = 0;
		Mar1.appendChild(child_div1[0]);
		Mar1.scrollTop = 0;
		setTimeout(start1,stoptime1);
	}
 }
 start1();
 </script>
 </div>
 <!--滚动结束-->
 <div class="clear clear10"></div>
 </div>
 <!--交易E-->

 <script language="javascript">
 a=document.getElementById("proxuan").offsetHeight;
 b=a-191;
 document.getElementById("Marquee1").style.height=b+"px";
 document.getElementById("projyi").style.height=a+"px";
 </script>

    
    <!--图片B-->
  <div class="biglist">


<fh-function>
$i=1;
if($id==0){
  $sql="select * from sl_product,sl_psort where P_del=0 ".$M_pinfo."  ".shuxing("P_shuxing")." $M_info and P_sort=S_id order by P_top desc,P_order,P_time desc,P_id desc limit ".(($page-1)*15).",15";
}else{
  if($S_sub==0){
    $sql="select * from sl_product,sl_psort where S_del=0 ".shuxing("P_shuxing")." $M_info and P_del=0 ".$M_pinfo."  and P_sort=S_id and S_sub=".$id." order by P_top desc,P_order,P_time desc,P_id desc limit ".(($page-1)*15).",15";
  }else{
    $sql="select * from sl_product,sl_psort where S_del=0 ".shuxing("P_shuxing")." $M_info and P_del=0 ".$M_pinfo."  and P_sort=S_id and S_id=".$id." order by P_top desc,P_order,P_time desc,P_id desc limit ".(($page-1)*15).",15";
  }
}

    s[[

if($i % 5==0){
	$class="u0";
}else{
	$class="";
}

if($row["P_mid"]==0){
	$zy="<span class=\"s0\" style=\"float: right;margin-top:-20px\">自营</span>";
}else{
	$zy="<span class=\"s1\" style=\"float: right;margin-top:-20px\">".getrs("select M_shop from sl_member where M_id=".$row["P_mid"],"M_shop")."</span>";
}


if($row["P_limit"]>0 and $row["P_limitlong"]>0 and $row["P_limitlong"]-(time()-strtotime($row["P_limittime"]))/3600>0){
  $P_price=$row["P_limit"];
  $l=date('Y-m-d H:i:s',strtotime('+'.$row["P_limitlong"].' hour',strtotime($row["P_limittime"])));
}else{
  $P_price=p($row["P_price"]);
  $l="";
}

 $api=$api."<ul class=\"u1 ".$class."\">
  <li class=\"l1\">
    <a href=\"?type=productinfo&id=".$row["P_id"]."\" target=\"_blank\">


      <div style=\"background-image:url(".pic(splitx($row["P_pic"],"|",0)).");background-repeat: no-repeat;background-position:center center;width:220px;height:220px;background-size: cover;position:relative;\" class=\"sss\" limit=\"".$l."\"></div>

    </a>
  </li>
  <li class=\"l3\">
    <a href=\"?type=productinfo&id=".$row["P_id"]."\" title=\"".$row["P_title"]."\" target=\"_blank\">".$row["P_title"]."</a>
  </li>
  <li class=\"l2\">￥".$P_price."</li>
  <li class=\"l5\" ><a href=\"?type=product&id=".$row["S_id"]."\" charset=\"g_ac2\" title=\"".$row["S_title"]."\" target=\"_blank\">".$row["S_title"]."</a></li>
  <li class=\"l6\" style=\"height: 16px;\">
  ".$zy."
      </li>
  </ul>";
  $i+=1;
                ]]
</fh-function>
    </div>
  <!--图片E-->
<div style="font: 0px/0px sans-serif;clear: both;display: block"> </div>
  	<div id="pager"></div>

</div>

<div class="clear clear15"></div>
<div class="bfb bfbbottom">
<div class="yjcode">

 <div class="d1">
<ul class="u1">
<fh-function>
$sql="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=0 and not U_type='index' order by U_order,U_id desc";
s[[

  if($row["U_type"]=="link"){
    $link=$row["U_link"];
    $target="_blank";
  }else{
    $link="?type=".$row["U_type"]."&id=".$row["U_typeid"];
    $target="_self";
  }


     $api=$api."
  <li>
 <span><a href=\"".$link."\" target=\"".$target."\">".$row["U_title"]."</a></span>";

$sql2="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=".$row["U_id"]." order by U_order,U_id desc";
s2[[

  if($row2["U_type"]=="link"){
    $link2=$row2["U_link"];
    $target2="_blank";
  }else{
    $link2="?type=".$row2["U_type"]."&id=".$row2["U_typeid"];
    $target2="_self";
  }

    $api=$api."<a href=\"".$link2."\" target=\"".$target2."\" class=\"a1\">".$row2["U_title"]."</a><br>";
  ]]
      $api=$api."
   </li>";
    ]]

</fh-function>


</ul>
 
  
 </div>
 
 <div class="d2">


 <strong>联系我们</strong><br>

 [fh_contact]

</div>
 
 <div class="d3">
<img src="media/[fh_qrcode]" width="100" height="100" /><br>二维码
  </div>
 
 <ul class="u2">
 <li class="l1">

[fh_copyright][fh_beian][fh_code]
 </li>
 <li class="l2">
  </li>
 </ul>
 
</div>
</div>
<script src="js/jquery.pager.js" type="text/javascript"></script>
<script>
$(".scms-pic").attr("style","float: none;display:inline-block;vertical-align:top;");
$(document).ready(function() {
    $("#pager").pager({ pagenumber: <fh-function> $api=$api.$page;</fh-function>, pagecount: <fh-function> $api=$api.$page_num;</fh-function>, buttonClickCallback: PageClick });
});

PageClick = function(pageclickednumber) {
  window.location="<fh-function>$api=$api.url($url,"page",$_GET["page"]);</fh-function>&page="+pageclickednumber;
}

function limit(){
  $(".sss").each(function(){
      if($(this).attr("limit")!=""){
      var leftTime = new Date($(this).attr("limit")) - new Date();
      var d, h, m, s;
      if (leftTime < 0) {
        return;
      }
      d = Math.floor(leftTime / 1000 / 60 / 60 / 24);
      h = Math.floor((leftTime / 1000 / 60 / 60) % 24);
      m = Math.floor((leftTime / 1000 / 60) % 60);
      s = Math.floor((leftTime / 1000) % 60);
      const str = `${d}天${h}:${m}:${s}`;
        $(this).html("<div style=\"position: absolute;left: 0px;bottom: 0px;background: rgba(0,0,0,0.5);color: #fff;width:100%;height:25px;font-size:12px;line-height:25px;text-align:left\"><img src=\"https://misc.360buyimg.com/product/search/1.0.8/css/i/search.presell.gif\" style=\"margin:5px 5px -5px 5px;display:inline-block;height:17px;width:17px\">限时特惠 "+str+" 后结束</div>");
      }
    });
}
limit();
setInterval(limit, 1000);
</script>
[fh_kefu]

</body>
</html>