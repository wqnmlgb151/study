<fh-function>
mysqli_query($conn, "update sl_product set P_view=P_view+1 where P_id=".$id);
$sql="select * from sl_product,sl_psort where P_sort=S_id and P_id=".$id;
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  if (mysqli_num_rows($result) > 0) {
    $S_id=$row["S_id"];
    $P_id=$row["P_id"];
    $P_pic=$row["P_pic"];
    $P_tag=$row["P_tag"];
    $P_mid=$row["P_mid"];
    $P_selltype=$row["P_selltype"];

    switch ($row["P_selltype"]) {
    case 0:
    $P_rest=1;
    break;

    case 1:

    $P_rest=getrs("select count(C_id) as C_count from sl_card where C_sort=".intval($row["P_sell"])." and C_use=0","C_count");
    break;

    case 2:
    $P_rest=$row["P_rest"];
    break;
  }
  }
</fh-function>
<html>
<head>
<meta http-equiv="x-ua-compatible" content="ie=7" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<fh-function>
if(is_ssl()){
  $api=$api."<meta http-equiv=\"Content-Security-Policy\" content=\"upgrade-insecure-requests\" />";
}
</fh-function>
<title>[P_title] - [fh_title]</title>
<link href="media/[fh_ico]" rel="shortcut icon" />
<meta name="description" content="[P_description]" />
<meta name="keywords" content="[P_keywords]" />

<link href="template/t11/css/global.css?t=0880842001588674338" rel="stylesheet" type="text/css" />
<link href="template/t11/css/basic.css?t=0880842001588674338" rel="stylesheet" type="text/css" />
<link href="template/t11/css/index.css?t=0880842001588674338" rel="stylesheet" type="text/css" />
<script language="javascript" src="template/t11/js/global.js?t=0880842001588674338"></script>
<script language="javascript" src="template/t11/js/basic.js?t=0880842001588674338"></script>
<script language="javascript" src="template/t11/js/jquery.min.js?t=0880842001588674338"></script>
<script language="javascript" src="template/t11/js/layer.js?t=0880842001588674338"></script>
<script language="javascript" src="template/t11/js/index.js?t=0880842001588674338"></script>
<link href="template/t11/css/view.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="template/t11/js/view.js"></script>
<script type="text/javascript" src="template/t11/js/jquery-plugin-slide.js"></script>
<style type="text/css">
.buy,.car{
      float: left;
    width: 127px;
    height: 37px;
    margin: 0 10px 0 0;
    color: #fff;
    text-align: center;
    font-size: 16px;
    padding: 0;
    border-radius: 3px;
    cursor:pointer;
}
.car{background: none;width: 127px;text-align: center;}
body div{margin:auto}
ul{
    list-style: none;
}
.drop-down-content{
    display: none;
    z-index: 99999;
    position: absolute;
    background: #ffffff;
    top:170px;
    text-align: center;
    padding: 0px;
    margin-left: 10px;
    box-shadow: 0px 0px 5px #888888;
}
.drop-down-content li a{
  margin-left: 0px !important;
  padding: 10px !important;
  font-size: 14px !important;
}
.drop-down-content li:hover a{
    background-color:#f7f7f7;
}
.nav .drop-down:hover .drop-down-content{
    display: block;
}
.nav>li{
    float: left;
}
#price{font-size: 30px;}
</style>
</head>
<body>
<div class="bfb bfbtop">
<div class="yjcode">

<div class="dts">欢迎来到[fh_title]</div>
<div class="toplogin">

<fh-function>
      if($_SESSION["M_login"]==""){
        $api="<a href=\"member/login.php\" class=\"a1\">登录</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
        <a href=\"member/reg.php\">免费注册</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;";
      }else{
      $api="<a href=\"member/\" class=\"a1\">".$_SESSION["M_login"]."</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
      <a href=\"member/cart.php\" class=\"a1\">购物车</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
      <a href=\"member/login.php?action=unlogin\">退出</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;";
      }
</fh-function>

 </div>
</div>
</div>

<div class="bfb bfbtop1">
<div class="yjcode">
 <div class="top1">
  <h1 class="logo"><a href="./"><img alt="[fh_title]" border="0" src="media/[fh_logo]" height="50" /></a></h1>
  
  <div class="resou">
  <form name="topf1" method="post" action="./?type=search">
  <ul class="u1">
  <li class="l1" onMouseOver="topover()" onMouseOut="topout()">
  <span id="topnwd">全部</span>
  <div id="topdiv" style="display:none;">
  <a href="javascript:void();" onClick="topjconc(0,'全部')">全部</a>
  <a href="javascript:void();" onClick="topjconc(1,'商品')">商品</a>
  <a href="javascript:void();" onClick="topjconc(2,'店铺')">店铺</a>
  <a href="javascript:void();" onClick="topjconc(3,'文章')">文章</a>
  </div>
  </li>
  <li class="l2"><input name="keyword" id="topt" type="text" /><input type="hidden" name="type" id="type" value="0"></li>
  <li class="l3"><input type="submit" value="搜 索" /></li>
  </ul>
  </form>
  <div class="d1">
  热门搜索：
<fh-function>
$keyword=explode(",",$H_data["C_hotwords"]);
for($i=0;$i<count($keyword);$i++){
  $api=$api."<a href=\"./?type=search&keyword=".$keyword[$i]."\" target=\"_blank\">".$keyword[$i]."</a>&nbsp;&nbsp;&nbsp;";
}
</fh-function>
    </div>
  </div>
  
<style>
.shopx{float: right;margin-top: 45px;font-size: 18px;background: #f7f7f7;padding: 10px;border-radius: 5px;border: solid 1px #EEEEEE}
.shopx:hover{background: #0099ff;color: #ffffff}
</style>
<fh-function>
$C_rzon=getrs("select C_rzon from sl_config","C_rzon");
if($C_rzon==1){
  $api=$api."<a href=\"member/seller.php\"><div class=\"shopx\"><img src=\"template/t11/img/shop.png\" width=\"22\" style=\"vertical-align: top;\"> 商家入驻</div></a>";
}
</fh-function>
 
  <div class="menu fontyh">
   <!--左B-->
      <span id="typeallnum" style="display:none;"><fh-function>$api=$api.getrs("select count(S_id) as S_count from sl_psort where S_del=0 and S_sub=0","S_count");</fh-function></span>
   <div class="m1" onmouseover="leftmenuover()" onmouseout="leftmenuout()">
   <span class="t">全部商品分类</span>
   <!--主导航下拉开始-->
   <div class="menun fontyh" id="leftmenu" style="display:none;">


<fh-function>
  function is_haves($a,$b){
  if(in_array($a,$b)){
      return true;
  }else{
      return false;
  }
}
$i=1;
$sql="select * from sl_psort where S_del=0 and S_sub=0 order by S_order,S_id desc";
                s[[
                $api=$api."<div class=\"menu1\" id=\"yhmenu".$i."\" onmouseover=\"yhmenuover(".$i.")\" onmouseout=\"yhmenuout(".$i.")\">
     <div class=\"mleft\">
      <ul class=\"u1\"><li class=\"l1\"></li><li class=\"l2\"><a href=\"?type=product&id=".$row["S_id"]."\"><b>".$row["S_title"]."</b></a></li><li class=\"l1\"></li></ul>
      <ul class=\"u2\">";

$sql2="select * from sl_psort where S_del=0 and S_sub=".$row["S_id"]." order by S_order,S_id desc limit 9";
                s2[[
                        $api=$api."<li><a href=\"?type=product&id=".$row2["S_id"]."\" title=\"".$row2["S_title"]."\">".$row2["S_title"]."</a></li>";
                    ]]
$api=$api."
            </ul>
     </div>
     <div class=\"rmenu rmenu1\" style=\"display:none;margin-top:-".(110*$i)."px;height:658px;overflow:hidden;\" id=\"rmenu".$i."\">
      <div class=\"esmenu\">


      <ul class=\"esu1\">
      <li class=\"l1\"><span class=\"s1\"></span><span class=\"s2\">分类：</span></li>
      <li class=\"l2\">
      <div>";

$sql2="select * from sl_psort where S_del=0 and S_sub=".$row["S_id"]." order by S_order,S_id desc";
                s2[[
                        $api=$api."<span class=\"sfont\"><a href=\"?type=product&id=".$row2["S_id"]."\">".$row2["S_title"]."</a></span>";
                    ]]
$api=$api."
             </div>
      </li>
      </ul>";


$arr = array();

$sql2="select * from sl_product,sl_psort where S_del=0 and P_del=0 ".$M_pinfo."  and P_sh=1 and P_sort=S_id and S_sub=".$row["S_id"]." order by P_top desc,P_order,P_id desc";
$result2 = mysqli_query($conn,  $sql2);
if (mysqli_num_rows($result2) > 0) {
while($row2 = mysqli_fetch_assoc($result2)) {
        $sx=explode("\r\n",$row2["P_shuxing"]);
        for($ii=0;$ii<count($sx);$ii++){
          if(splitx($sx[$ii],":",0)!=""){
            $c=json_decode("{\"S_title\":\"".splitx($sx[$ii],":",0)."\"}",true);
            if(!is_haves($c,$arr)){
              array_push($arr,$c);
            }
          }
        }
    }
} 


for($ii=0;$ii<count($arr);$ii++){
  $arr[$ii]["list"]=array();
  $result2 = mysqli_query($conn,  $sql2);
  if (mysqli_num_rows($result) > 0) {
  while($row2 = mysqli_fetch_assoc($result2)) {
          $sx=explode("\r\n",$row2["P_shuxing"]);
          for($m=0;$m<count($sx);$m++){
            $s=splitx($sx[$m],":",0);
            if($s==$arr[$ii]["S_title"]){
              $v=splitx($sx[$m],":",1);
                if($v!=""){
                  $x=json_decode("{\"shuxing\":\"".$v."\"}",true);
                  if(!is_haves($x,$arr[$ii]["list"])){
                    array_push($arr[$ii]["list"],$x);
                  }
                }
            }
        }
      }
  }
}



for($ii=0;$ii<count($arr);$ii++){
  for($jj=0;$jj<count($arr[$ii]["list"]);$jj++){
    $shuxing=$shuxing."<span class=\"sfont\"><a href=\"?type=product&id=".$row["S_id"]."&f0=".$arr[$ii]["S_title"].":".$arr[$ii]["list"][$jj]["shuxing"]."\">".$arr[$ii]["list"][$jj]["shuxing"]."</a></span>";
  }

  $api=$api. "
  <ul class=\"esu1\">
      <li class=\"l1\"><span class=\"s1\"></span><span class=\"s2\">".$arr[$ii]["S_title"]."：</span></li>
      <li class=\"l2\">
      <div>".$shuxing."</div>
      </li>
      </ul>";
  $shuxing="";
}

      
      $api=$api. "</div>
      <div class=\"shoptj\" style=\"height:658px;overflow:hidden;\">
        <ul class=\"shopu1\">
      <li class=\"l1\"><a href=\"./\" target=\"_blank\"><img width=\"110\" height=\"110\" src=\"media/[fh_ico]\" /></a></li>
      <li class=\"l2\"><a href=\"./\" target=\"_blank\">官方旗舰店</a><span class=\"s1\">共有 <span class=\"red\">".getrs("select count(P_id) as P_count from sl_product where P_del=0 ".$M_pinfo."  and P_mid=0","P_count")."</span> 件商品在售</span></li>
      </ul>";


$sql2="select * from sl_member where M_del=0 and M_type=1 order by rand() desc limit 5";
                s2[[
                  
                    $api=$api."<ul class=\"shopu1\">
      <li class=\"l1\"><a href=\"./?type=product&M_id=".$row2["M_id"]."\" target=\"_blank\"><img width=\"110\" height=\"110\" src=\"media/".$row2["M_head"]."\"/></a></li>
      <li class=\"l2\"><a href=\"./?type=product&M_id=".$row2["M_id"]."\" target=\"_blank\">".$row2["M_shop"]."</a><span class=\"s1\">共有 <span class=\"red\">".getrs("select count(P_id) as P_count from sl_product where P_del=0 ".$M_pinfo."  and P_sh=1 and P_mid=".$row2["M_id"],"P_count")."</span> 件商品在售</span></li>
      </ul>";
                ]]


        $api=$api."

            </div>
     </div>
    </div>";
    $i=$i+1;
                    ]]



</fh-function>
        <!--商品E-->
   </div>
   <!--主导航下拉结束-->
   </div> 
   <!--左E-->

   <div class="m2">

    <ul class="nav">
    <fh-function>
                $sql="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=0 order by U_order,U_id desc";
                s[[
                  if($type==$row["U_type"] && $id==$row["U_typeid"]){
                    $class="nav-li active";
                  }else{
                    $class="nav-li margin-left-0";
                  }

                  if($row["U_type"]=="link"){
                    $link=$row["U_link"];
                    $target="_blank";
                  }else{
                    $link="?type=".$row["U_type"]."&id=".$row["U_typeid"];
                    $target="_self";
                  }

                    $api=$api."<li class=\"drop-down\"><a style=\"padding-bottom: 15px;\" href=\"".$link."\" target=\"".$target."\" title=\"".$row["U_title"]."\">".$row["U_title"]."</a><ul class=\"drop-down-content\">";

                    $sql2="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=".$row["U_id"]." order by U_order,U_id desc";
                    s2[[
                      
                      if($row2["U_type"]=="link"){
                        $link2=$row2["U_link"];
                        $target="_blank";
                      }else{
                        $link2="?type=".$row2["U_type"]."&id=".$row2["U_typeid"];
                        $target="_self";
                      }
                            $api=$api."<li><a href=\"".$link2."\" target=\"".$target."\">".$row2["U_title"]."</a></li>";
                        ]]

$api=$api."</ul></li>";
                ]]

              </fh-function>
            </ul>
      </div>
  </div>
 
 </div>
</div>
</div>
<script type="text/javascript" src="template/t11/js/jquery-plugin-slide.js"></script>
<script type="text/javascript" src="template/t11/js/lyz.delayLoading.min.js"></script>
<div class="yjcode">
 <div class="dqwz">
 <ul class="u1">
 <li class="l1">
 当前位置：<a href="./">首页</a> > <a href="?type=product&id=[S_id]">[S_title]</a>
  > <a href="">[P_title]</a>  </li>
 </ul>
 </div>
 <div class="jbmain">
  <!--图片区B-->
    <div class="qhtp">
    <!--切换B-->
  <div class="protp">
   <div class ='Homeslide' >
   <div class ='Homeslide_bigwrap'>
    <div class='Homeslide_hand0'></div>
    <div class='Homeslide_hand1'></div>
    <div class='Homeslide_bigpicdiv'><a href=''  id="tupiana"><img src=""></a></div>
   </div>
   <div class='Homeslide_thumb' style="display:none;"><ul>
    
   </ul></div>
   </div>
   <script type="text/javascript">
   var home_slide_data = 
   [

<fh-function>
$pic=explode("|",$P_pic);
for($i=0;$i<count($pic);$i++){
  $api=$api."{\"title\":\"\",\"onc\":\"\",\"image\":\"".pic($pic[$i])."\",\"thumb\":\"".pic($pic[$i])."\",\"mark\":\"".$i."\"},";
}
$api=substr($api,0,strlen($api)-1);
</fh-function>
         ]; 
   $('.Homeslide').homeslide(home_slide_data,false,3000);
   </script>
 </div>
 <!--切换E-->
   
  <ul class="u1">


    <div id="collection_product" pid="[P_id]"></div>

  </ul>

 
  </div>
  <!--图片区E-->

 <!--中间B-->
 <div class="jbmiddle" id="jbmiddle">
   <h1>[P_title]</h1>
      <ul class="pful">
   <li class="l1">
   <img src="template/t11/img/x1.png" class="img1" width="92" height="15" />
      <div class="pf" style="width:92px;"><img src="template/t11/img/x2.png" title="5分" width="92" height="15" /></div>
   </li>
   <li class="l2"><a href="#pj">[E_count]条评论</a></li>
      
      </ul>
   
   <div class="jg">
        <div class="jgm">
    <div class="d0">本站优惠价</div>
    <div class="dvip"></div>
    <div class="d1">￥<span id="price">[P_price]</span>[P_vip]</div>
    
    </div>
    
    <ul class="kc">
    <li class="l1">库存</li>
    <li class="l1">销量</li>
    <li class="l2"><span id="gg_rest">[P_resttitle]</span></li>
    <li class="l2">[P_sold]</li>
    </ul>
    
   </div>
   
    <ul class="u0">
   <li class="l2" style="height: auto;margin-left: 10px">[P_quan]</li>
   <li class="l2" style="height: auto;margin-left: 10px">[P_limit]</li>
   </ul>
   
   <ul class="u0">
   <li class="l1">服务</li>
   <li class="l2">由<strong>[P_shop]</strong>发货，并提供售后服务。</li>
   </ul>
   
   <!--套餐B-->
      <!--套餐E-->
<form id="buy" method="post" action="buy.php?type=productinfo&id=[P_id]">
  <ul class="u0">
   <li class="l2" style="height: auto;margin-left: 10px">[P_gg]</li>

<li class="l2" style="height: auto;margin-left: 10px">[fh_address]</li>
   
   </ul>

   <ul class="u6">
   <li class="l1"><input name="no" type="text" onChange="moneycha()" id="tkcnum" value="1" /></li>
   <li class="l2"><a href="javascript:void(0);" onClick="shujia()" class="a1">+</a><a href="javascript:void(0);" onClick="shujian()" class="a2">-</a></li>
   </ul>
   <ul class="u4">
   <li class="l1">
      

<fh-function>
              $api=$api."<input type=\"submit\" name=\"button\" class=\"buy\" value=\"立即购买\" />";
              $api=$api.unlogin_product("car",$id);
              </fh-function>

      
   </li>
   </ul>
   </form>
   <ul class="u3">
   <li class="l1">特色</li>
   <li class="l2">
   <a href="javascript:void(0);" onMouseOver="tscapover(1)" id="tscap1" class="a1">担保交易</a>
   <a href="javascript:void(0);" onMouseOver="tscapover(2)" id="tscap2">
    <fh-function>
  if($P_selltype==2){
    $api=$api."快递发货";
  }else{
    $api=$api."自动发货";
  }
    </fh-function>
   </a>      </li>
   </ul>
   <div class="tsmain" id="tsmain1">担保交易，安全保证，有问题不解决可申请退款。</div>
   <div class="tsmain" id="tsmain2" style="display:none;">
<fh-function>
  if($P_selltype==2){
    $api=$api."购物时请正确填写您的收件信息。";
  }else{
    $api=$api."自动发货商品，随时可以购买，零等待。";
  }
    </fh-function>

   </div>
   <div class="tsmain" id="tsmain3" style="display:none;">不同会员等级尊享不同购买折扣。</div>
   
      <ul class="fx">
   <li class="l1">分享</li>
   <li class="l2">
  
<div class="bshare-custom icon-medium"><div class="bsPromo bsPromo2"></div><a title="分享到微信" class="bshare-weixin" href="javascript:void(0);"></a><a title="分享到QQ空间" class="bshare-qzone" href="javascript:void(0);"></a><a title="分享到QQ好友" class="bshare-qqim" href="javascript:void(0);"></a><a title="分享到新浪微博" class="bshare-sinaminiblog" href="javascript:void(0);"></a><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a><span class="BSHARE_COUNT bshare-share-count" style="float: none;">0</span></div>
<script type="text/javascript" charset="utf-8" src="https://static.bshare.cn/b/buttonLite.js#style=-1&amp;uuid=&amp;pophcol=2&amp;lang=zh"></script>
<script type="text/javascript" charset="utf-8" src="https://static.bshare.cn/b/bshareC0.js"></script>
</li>
   </ul>
  </div>
 <!--中间E-->
 
  <!--卖家B-->
    <div class="jbuser">
  <ul class="u1">
  <li class="l1"><img src="template/t11/img/userbao.gif" width="200" height="72" /></li>
  </ul>
<fh-function>
if($P_mid==0){
  $api=$api."<div class=\"d1\">
    <img src=\"media/".getrs("select C_ico from sl_config","C_ico")."\" style=\"border:solid 1px #DDDDDD;padding:5px;width:40px;height:40px;margin-top:5px;margin-bottom:-5px\">
  <h3>官方自营店</h3>
  <ul class=\"du0\"><li class=\"l1\">信誉：</li><li class=\"l2\"><img title=\"信用值10000\" src=\"template/t11/img/dj/s-crown-5.gif\" /></li></ul>
  <ul class=\"du1\"><li class=\"l1\">掌柜：</li><li class=\"l2\">官方卖家</li></ul>
  <ul class=\"du1\"><li class=\"l1\">宝贝：</li><li class=\"l2\">".getrs("select count(P_id) as P_count from sl_product where P_mid=0 and P_del=0 ".$M_pinfo." ","P_count")."件</li></ul>
  <ul class=\"du1\"><li class=\"l1\">创店：</li><li class=\"l2\">".date("Y-m-d",filemtime("conn/conn.php"))."</li></ul>
    <ul class=\"du1\"><li class=\"l1\">联系：</li><li class=\"l2\"><a href=\"./?type=contact\">点击联系客服</a></li></ul>
    <ul class=\"du3\">
  <li class=\"l1\">描述<br><span class=\"g_ac99_h\">5.00</span></li>
  <li class=\"l1\">发货<br><span class=\"g_ac99_h\">5.00</span></li>
  <li class=\"l0\">售后<br><span class=\"g_ac99_h\">5.00</span></li>
  </ul>
  <ul class=\"du4\">
  <li class=\"l1\"><a href=\"./\" class=\"g_ac99\" target=\"_blank\">进入店铺</a></li>
    <li class=\"l2\" id=\"collection_shop\" mid=\"".$P_mid."\"></li>
  </ul>
  </div>";
}else{
$sql="Select * from sl_member where M_id=$P_mid";
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $M_head=$row["M_head"];
    $M_login=$row["M_login"];
    $M_shop=$row["M_shop"];
    $M_qq=$row["M_qq"];
    $M_sellertime=$row["M_sellertime"];
  }

  $api=$api."<div class=\"d1\">
    <img src=\"media/".$M_head."\" style=\"border:solid 1px #DDDDDD;padding:3px;width:40px;height:40px;margin-top:5px;margin-bottom:-5px\">
  <h3>".$M_shop."</h3>
  <ul class=\"du0\"><li class=\"l1\">信誉：</li><li class=\"l2\"><img title=\"信用值10000\" src=\"template/t11/img/dj/s-crown-5.gif\" /></li></ul>
  <ul class=\"du1\"><li class=\"l1\">掌柜：</li><li class=\"l2\">".$M_login."</li></ul>
  <ul class=\"du1\"><li class=\"l1\">宝贝：</li><li class=\"l2\">".getrs("select count(P_id) as P_count from sl_product where P_mid=$P_mid and P_del=0 ".$M_pinfo." ","P_count")."件</li></ul>
  <ul class=\"du1\"><li class=\"l1\">创店：</li><li class=\"l2\">".date("Y-m-d",strtotime($M_sellertime))."</li></ul>
    <ul class=\"du1\"><li class=\"l1\">QQ：</li><li class=\"l2\"><a href=\"http://wpa.qq.com/msgrd?v=3&uin=".$M_qq."&site=qq&menu=yes\">".$M_qq."</a></li></ul>
    <ul class=\"du3\">
  <li class=\"l1\">描述<br><span class=\"g_ac99_h\">5.00</span></li>
  <li class=\"l1\">发货<br><span class=\"g_ac99_h\">5.00</span></li>
  <li class=\"l0\">售后<br><span class=\"g_ac99_h\">5.00</span></li>
  </ul>
  <ul class=\"du4\">
  <li class=\"l1\"><a href=\"./shop.php?M_id=".$P_mid."\" class=\"g_ac99\" target=\"_blank\">进入店铺</a></li>
    <li class=\"l2\" id=\"collection_shop\" mid=\"".$P_mid."\"></li>
  </ul>
  </div>";
}

</fh-function>
  </div>
  <!--卖家E-->
 </div>
 </div>

<div class="yjcode">

 <!--左侧B-->
 <div class="left">
 <ul class="u1">
 <li class="l1">本店销售榜</li>

<fh-function>
$sql="select * from sl_product where P_del=0 ".$M_pinfo."  and P_sh=1 and P_mid=".$P_mid." order by P_top desc,P_id desc limit 10";
s[[
        $api=$api."<li class=\"l2\"><a href=\"?type=productinfo&id=".$row["P_id"]."\"><img alt=\"".$row["P_title"]."\" src=\"".pic(splitx($row["P_pic"],"|",0))."\" width=\"50\" height=\"50\" align=\"left\"></a>
          <a href=\"?type=productinfo&id=".$row["P_id"]."\" title=\"".$row["P_title"]."\" style=\"height: 38px;overflow: hidden;display:block\">".$row["P_title"]."</a>
          <strong class=\"feng\">￥".p($row["P_price"])."</strong></li>";
    ]]
</fh-function>

  </ul>
 </div>
 <!--左侧E-->
 
 <!--右侧B-->
 <div class="right">
 <ul class="ucap">
 <li class="l1 g_bc0_h" id="bqcap1" onClick="bqonc(1)">商品详情</li>
  <li class="l0" id="bqcap2" onClick="bqonc(2)">累计评价 <strong>[E_count]</strong></li>
 <li class="l0" id="bqcap5" onClick="bqonc(5)">购买记录 <strong>[B_count]</strong></li>
 <li class="l0" id="bqcap3" onClick="bqonc(3)">交易规则</li>
 </ul>
 <div class="viewtxt" id="bqdiv1">
 
 <!--正文介绍B-->
 <div class="txtad"></div>
 <div class="probqm">
[P_shuxing]
                    
 </div>
[P_content]
 </div>
 
  
 <div id="bqdiv2">
 <a name="pj"></a>
 <ul class="bqcap">
 <li class="l1">商品评价</li>
 </ul>
 <ul class="pjcap">
 <li class="l2">描述相符<br><strong>5</strong></li>
 <li class="l2">发货速度<br><strong>5</strong></li>
 <li class="l2">服务态度<br><strong>5</strong></li>
 <li class="l2">综合评分<br><strong>5</strong></li>
 <li class="l3"><a href="member">写评价赚积分</a></li>
 </ul>
 <div class="pjlist">


<fh-function>
                $sql="select * from sl_evaluate,sl_member,sl_orders where E_del=0 and E_mid=M_id and E_oid=O_id and O_pid=$P_id order by E_id desc";
                $result = mysqli_query($conn,  $sql);
                if (mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                  
                  $api=$api."<div class=\"pj pj1\">
  <ul class=\"u1\"><li class=\"l1\"><img src=\"media/".$row["M_head"]."\" width=\"50\" height=\"50\" /></li><li class=\"l2\">".enname($row["M_login"])."</li></ul>
  <ul class=\"u2\">
  <li class=\"l1\">
  ".$row["E_content"]."<br>
      </li>
    <li class=\"l3\">".$row["E_time"]."</li>";
if($row["E_reply"]!=""){
                      $api=$api."<li class=\"l3\">商家回复：".$row["E_reply"]."</li>";
                    }
  $api=$api."</ul>
  <div class=\"d2\">
  <span class=\"s1\">好评</span>      </div>
  <div class=\"d3\">
  <img src=\"template/t11/img/x1.png\" class=\"img1\" width=\"76\" height=\"15\" />
    <div class=\"pf\" style=\"width:76px;\"><img src=\"template/t11/img/x2.png\" title=\"5分\" width=\"76\" height=\"15\" /></div>
  </div>
 </div>";

                }
              }else{
              $api=$api."<div style=\"text-align: center;margin-top: 20px;\">暂无商品评价</div>";
            }
                    </fh-function>



  </div>
 
 </div>
 
 <!--问答B-->
 <div id="bqdiv5">
  <ul class="bqcap">
  <li class="l1">购买记录</li>
  </ul>
<div class="pjlist">


<fh-function>
                $sql="select * from sl_orders,sl_member where O_state>0 and O_mid=M_id and O_pid=".$P_id." and O_del=0 order by O_id desc";
                $result = mysqli_query($conn,  $sql);
                if (mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                $api=$api."<div class=\"pj pj1\">
  <ul class=\"u1\"><li class=\"l1\"><img src=\"media/".$row["M_head"]."\" width=\"50\" height=\"50\" /></li><li class=\"l2\">".enname($row["M_login"])."</li></ul>
  <ul class=\"u2\">
  <li class=\"l1\">
  购买了 <b>".$row["O_title"]."</b><br>
      </li>
    <li class=\"l3\">".$row["O_time"]."</li></ul>
  <div class=\"d2\">
  <span class=\"s1\"></span>      </div>
  <div class=\"d3\">
    <div class=\"pf\" style=\"width:76px;\"></div>
  </div>
 </div>";
                }
              }else{
              $api=$api."<div style=\"text-align: center;margin-top: 20px;\">暂无购买记录</div>";
            }
</fh-function>
  </div>
 </div>
 <!--问答E-->
 
 <div id="bqdiv3">
  <ul class="bqcap">
  <li class="l1">交易规则</li>
  </ul>
  <div class="viewtxt fontyh">
  <p><img src="template/t11/img/70521461640083.gif" style="float:none;margin:0 0 10px 0;" title="1.gif"/></p><p><img src="template/t11/img/84301461640083.jpg" title="1.jpg" style="float: none;"/><br/></p><p><br/></p><p><img src="template/t11/img/41531461640083.gif" style="float:none;margin:0 0 10px 0;" title="2.gif"/></p><p>1、自动：在上方保障服务中标有自动发货的商品，拍下后，将会自动收到来自卖家的商品获取（下载）链接；<br/></p><p>2、手动：未标有自动发货的的商品，拍下后，卖家会收到邮件、短信提醒，也可通过QQ或订单中的电话联系对方。</p><p><br/></p><p><img src="template/t11/img/40501461640083.gif" style="float:none;margin:0 0 10px 0;" title="3.gif"/></p><p>1、描述：源码描述(含标题)与实际源码不一致的（例：描述PHP实际为ASP、描述的功能实际缺少、版本不符等）；<br/></p><p>2、演示：有演示站时，与实际源码小于95%一致的（但描述中有&quot;不保证完全一样、有变化的可能性&quot;类似显著声明的除外）；</p><p>3、发货：手动发货源码，在卖家未发货前，已申请退款的；</p><p>4、服务：卖家不提供安装服务或需额外收费的（但描述中有显著声明的除外）；</p><p>5、其他：如质量方面的硬性常规问题等。</p><p><span style="color: rgb(247, 150, 70);">注：经核实符合上述任一，均支持退款，但卖家予以积极解决问题则除外。交易中的商品，卖家无法对描述进行修改！</span></p><p><br/></p><p><img src="template/t11/img/69921461640083.gif" style="float:none;margin:0 0 10px 0;" title="4.gif"/></p><p>1、在未拍下前，双方在QQ上所商定的内容，亦可成为纠纷评判依据（商定与描述冲突时，商定为准）；<br/></p><p>2、在商品同时有网站演示与图片演示，且站演与图演不一致时，默认按图演作为纠纷评判依据（特别声明或有商定除外）；</p><p>3、在没有&quot;无任何正当退款依据&quot;的前提下，写有&quot;一旦售出，概不支持退款&quot;等类似的声明，视为无效声明；</p><p>4、虽然交易产生纠纷的几率很小，但请尽量保留如聊天记录这样的重要信息，以防产生纠纷时便于网站工作人员介入快速处理。</p><p><br/></p>  </div>
 </div>
 
 </div>
 <!--右侧E-->
</div>
<div class="clear clear15"></div>


<div class="bfb bfbbottom">
<div class="yjcode">

 <div class="d1">
<ul class="u1">
<fh-function>
$sql="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=0 and not U_type='index' order by U_order,U_id desc";
s[[

  if($row["U_type"]=="link"){
    $link=$row["U_link"];
    $target="_blank";
  }else{
    $link="?type=".$row["U_type"]."&id=".$row["U_typeid"];
    $target="_self";
  }


     $api=$api."
  <li>
 <span><a href=\"".$link."\" target=\"".$target."\">".$row["U_title"]."</a></span>";

$sql2="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=".$row["U_id"]." order by U_order,U_id desc";
s2[[

  if($row2["U_type"]=="link"){
    $link2=$row2["U_link"];
    $target2="_blank";
  }else{
    $link2="?type=".$row2["U_type"]."&id=".$row2["U_typeid"];
    $target2="_self";
  }

    $api=$api."<a href=\"".$link2."\" target=\"".$target2."\" class=\"a1\">".$row2["U_title"]."</a><br>";
  ]]
      $api=$api."
   </li>";
    ]]

</fh-function>


</ul>
 
  
 </div>
 
 <div class="d2">


 <strong>联系我们</strong><br>


 [fh_contact]

</div>
 
 <div class="d3">
<img src="media/[fh_qrcode]" width="100" height="100" /><br>二维码
  </div>
 
 <ul class="u2">
 <li class="l1">
[fh_copyright][fh_beian][fh_code]
 </li>
 <li class="l2">
  </li>
 </ul>
 
</div>
</div>

[fh_kefu]
</body>
</html>