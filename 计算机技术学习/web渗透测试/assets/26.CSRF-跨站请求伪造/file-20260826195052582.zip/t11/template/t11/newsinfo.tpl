<fh-function>
mysqli_query($conn, "update sl_news set N_view=N_view+1 where N_id=".$id);
$sql="select * from sl_news,sl_nsort where N_sort=S_id and N_id=".$id;
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
  if (mysqli_num_rows($result) > 0) {
    $S_id=$row["S_id"];
    $S_sub=$row["S_sub"];
  }
</fh-function>
<html>
<head>
<meta http-equiv="x-ua-compatible" content="ie=7" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>[N_title] - [fh_title]</title>
<link href="media/[fh_ico]" rel="shortcut icon" />
<meta name="description" content="[N_description]" />
<meta name="keywords" content="[N_keywords]" />

<meta http-equiv="Expires" content="0">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-control" content="no-cache">
<meta http-equiv="Cache" content="no-cache">

<link href="template/t11/css/global.css?t=0823577001588645663" rel="stylesheet" type="text/css" />
<link href="template/t11/css/basic.css?t=0823577001588645663" rel="stylesheet" type="text/css" />
<link href="template/t11/css/news/index.css?t=0823577001588645663" rel="stylesheet" type="text/css" />
<script language="javascript" src="template/t11/js/global.js?t=0823577001588645663"></script>
<script language="javascript" src="template/t11/js/basic.js?t=0823577001588645663"></script>
<script language="javascript" src="template/t11/js/jquery.min.js?t=0823577001588645663"></script>
<script language="javascript" src="template/t11/js/layer.js?t=0823577001588645663"></script>
<script language="javascript" src="template/t11/js/index.js?t=0823577001588645663"></script>

<style type="text/css">
body div{margin:auto}
ul{
    list-style: none;
}
.drop-down-content{
    display: none;
    z-index: 99999;
    position: absolute;
    background: #ffffff;
    top:170px;
    text-align: center;
    padding: 0px;
    margin-left: 10px;
    box-shadow: 0px 0px 5px #888888;
}
.drop-down-content li a{
  margin-left: 0px !important;
  padding: 10px !important;
  font-size: 14px !important;
}
.drop-down-content li:hover a{
    background-color:#f7f7f7;
}
.nav .drop-down:hover .drop-down-content{
    display: block;
}
.nav>li{
    float: left;
}
</style>
</head>
<body>
<div class="bfb bfbtop">
<div class="yjcode">

<div class="dts">欢迎来到[fh_title]</div>
<div class="toplogin">

<fh-function>
      if($_SESSION["M_login"]==""){
        $api="<a href=\"member/login.php\" class=\"a1\">登录</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
        <a href=\"member/reg.php\">免费注册</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;";
      }else{
      $api="<a href=\"member/\" class=\"a1\">".$_SESSION["M_login"]."</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
      <a href=\"member/cart.php\" class=\"a1\">购物车</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
      <a href=\"member/login.php?action=unlogin\">退出</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;";
      }
</fh-function>

 </div>
</div>
</div>

<div class="bfb bfbtop1">
<div class="yjcode">
 <div class="top1">
  <h1 class="logo"><a href="./"><img alt="[fh_title]" border="0" src="media/[fh_logo]" height="50" /></a></h1>
  
  <div class="resou">
  <form name="topf1" method="post" action="./?type=search">
  <ul class="u1">
  <li class="l1" onMouseOver="topover()" onMouseOut="topout()">
  <span id="topnwd">全部</span>
  <div id="topdiv" style="display:none;">
  <a href="javascript:void();" onClick="topjconc(0,'全部')">全部</a>
  <a href="javascript:void();" onClick="topjconc(1,'商品')">商品</a>
  <a href="javascript:void();" onClick="topjconc(2,'店铺')">店铺</a>
  <a href="javascript:void();" onClick="topjconc(3,'文章')">文章</a>
  </div>
  </li>
  <li class="l2"><input name="keyword" id="topt" type="text" /><input type="hidden" name="type" id="type" value="0"></li>
  <li class="l3"><input type="submit" value="搜 索" /></li>
  </ul>
  </form>
  <div class="d1">
  热门搜索：
<fh-function>
$keyword=explode(",",$H_data["C_hotwords"]);
for($i=0;$i<count($keyword);$i++){
  $api=$api."<a href=\"./?type=search&keyword=".$keyword[$i]."\" target=\"_blank\">".$keyword[$i]."</a>&nbsp;&nbsp;&nbsp;";
}
</fh-function>
    </div>
  </div>
  
<style>
.shopx{float: right;margin-top: 45px;font-size: 18px;background: #f7f7f7;padding: 10px;border-radius: 5px;border: solid 1px #EEEEEE}
.shopx:hover{background: #0099ff;color: #ffffff}
</style>
<fh-function>
$C_rzon=getrs("select C_rzon from sl_config","C_rzon");
if($C_rzon==1){
  $api=$api."<a href=\"member/seller.php\"><div class=\"shopx\"><img src=\"template/t11/img/shop.png\" width=\"22\" style=\"vertical-align: top;\"> 商家入驻</div></a>";
}
</fh-function>
 
  <div class="menu fontyh">
   <!--左B-->
      <span id="typeallnum" style="display:none;"><fh-function>$api=$api.getrs("select count(S_id) as S_count from sl_psort where S_del=0 and S_sub=0","S_count");</fh-function></span>
   <div class="m1" onmouseover="leftmenuover()" onmouseout="leftmenuout()">
   <span class="t">全部商品分类</span>
   <!--主导航下拉开始-->
   <div class="menun fontyh" id="leftmenu" style="display:none;">

<fh-function>
  function is_haves($a,$b){
  if(in_array($a,$b)){
      return true;
  }else{
      return false;
  }
}
$i=1;
$sql="select * from sl_psort where S_del=0 and S_sub=0 order by S_order,S_id desc";
                s[[
                $api=$api."<div class=\"menu1\" id=\"yhmenu".$i."\" onmouseover=\"yhmenuover(".$i.")\" onmouseout=\"yhmenuout(".$i.")\">
     <div class=\"mleft\">
      <ul class=\"u1\"><li class=\"l1\"></li><li class=\"l2\"><a href=\"?type=product&id=".$row["S_id"]."\"><b>".$row["S_title"]."</b></a></li><li class=\"l1\"></li></ul>
      <ul class=\"u2\">";

$sql2="select * from sl_psort where S_del=0 and S_sub=".$row["S_id"]." order by S_order,S_id desc limit 9";
                s2[[
                        $api=$api."<li><a href=\"?type=product&id=".$row2["S_id"]."\" title=\"".$row2["S_title"]."\">".$row2["S_title"]."</a></li>";
                    ]]
$api=$api."
            </ul>
     </div>
     <div class=\"rmenu rmenu1\" style=\"display:none;margin-top:-".(110*$i)."px;height:658px;overflow:hidden;\" id=\"rmenu".$i."\">
      <div class=\"esmenu\">


      <ul class=\"esu1\">
      <li class=\"l1\"><span class=\"s1\"></span><span class=\"s2\">分类：</span></li>
      <li class=\"l2\">
      <div>";

$sql2="select * from sl_psort where S_del=0 and S_sub=".$row["S_id"]." order by S_order,S_id desc";
                s2[[
                        $api=$api."<span class=\"sfont\"><a href=\"?type=product&id=".$row2["S_id"]."\">".$row2["S_title"]."</a></span>";
                    ]]
$api=$api."
             </div>
      </li>
      </ul>";


$arr = array();

$sql2="select * from sl_product,sl_psort where S_del=0 and P_del=0 ".$M_pinfo."  and P_sh=1 and P_sort=S_id and S_sub=".$row["S_id"]." order by P_top desc,P_order,P_id desc";
$result2 = mysqli_query($conn,  $sql2);
if (mysqli_num_rows($result2) > 0) {
while($row2 = mysqli_fetch_assoc($result2)) {
        $sx=explode("\r\n",$row2["P_shuxing"]);
        for($ii=0;$ii<count($sx);$ii++){
          if(splitx($sx[$ii],":",0)!=""){
            $c=json_decode("{\"S_title\":\"".splitx($sx[$ii],":",0)."\"}",true);
            if(!is_haves($c,$arr)){
              array_push($arr,$c);
            }
          }
        }
    }
} 


for($ii=0;$ii<count($arr);$ii++){
  $arr[$ii]["list"]=array();
  $result2 = mysqli_query($conn,  $sql2);
  if (mysqli_num_rows($result) > 0) {
  while($row2 = mysqli_fetch_assoc($result2)) {
          $sx=explode("\r\n",$row2["P_shuxing"]);
          for($m=0;$m<count($sx);$m++){
            $s=splitx($sx[$m],":",0);
            if($s==$arr[$ii]["S_title"]){
              $v=splitx($sx[$m],":",1);
                if($v!=""){
                  $x=json_decode("{\"shuxing\":\"".$v."\"}",true);
                  if(!is_haves($x,$arr[$ii]["list"])){
                    array_push($arr[$ii]["list"],$x);
                  }
                }
            }
        }
      }
  }
}



for($ii=0;$ii<count($arr);$ii++){
  for($jj=0;$jj<count($arr[$ii]["list"]);$jj++){
    $shuxing=$shuxing."<span class=\"sfont\"><a href=\"?type=product&id=".$row["S_id"]."&f0=".$arr[$ii]["S_title"].":".$arr[$ii]["list"][$jj]["shuxing"]."\">".$arr[$ii]["list"][$jj]["shuxing"]."</a></span>";
  }

  $api=$api. "
  <ul class=\"esu1\">
      <li class=\"l1\"><span class=\"s1\"></span><span class=\"s2\">".$arr[$ii]["S_title"]."：</span></li>
      <li class=\"l2\">
      <div>".$shuxing."</div>
      </li>
      </ul>";
  $shuxing="";
}

      
      $api=$api. "</div>
      <div class=\"shoptj\" style=\"height:658px;overflow:hidden;\">
        <ul class=\"shopu1\">
      <li class=\"l1\"><a href=\"./\" target=\"_blank\"><img width=\"110\" height=\"110\" src=\"media/[fh_ico]\" /></a></li>
      <li class=\"l2\"><a href=\"./\" target=\"_blank\">官方旗舰店</a><span class=\"s1\">共有 <span class=\"red\">".getrs("select count(P_id) as P_count from sl_product where P_del=0 ".$M_pinfo."  and P_mid=0","P_count")."</span> 件商品在售</span></li>
      </ul>";


$sql2="select * from sl_member where M_del=0 and M_type=1 order by rand() desc limit 5";
                s2[[
                  
                    $api=$api."<ul class=\"shopu1\">
      <li class=\"l1\"><a href=\"./?type=product&M_id=".$row2["M_id"]."\" target=\"_blank\"><img width=\"110\" height=\"110\" src=\"media/".$row2["M_head"]."\"/></a></li>
      <li class=\"l2\"><a href=\"./?type=product&M_id=".$row2["M_id"]."\" target=\"_blank\">".$row2["M_shop"]."</a><span class=\"s1\">共有 <span class=\"red\">".getrs("select count(P_id) as P_count from sl_product where P_del=0 ".$M_pinfo."  and P_sh=1 and P_mid=".$row2["M_id"],"P_count")."</span> 件商品在售</span></li>
      </ul>";
                ]]


        $api=$api."

            </div>
     </div>
    </div>";
    $i=$i+1;
                    ]]



</fh-function>

        
        <!--商品E-->
   </div>
   <!--主导航下拉结束-->
   </div> 
   <!--左E-->

   <div class="m2">

    <ul class="nav">
    <fh-function>
                $sql="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=0 order by U_order,U_id desc";
                s[[
                  if($type==$row["U_type"] && $id==$row["U_typeid"]){
                    $class="nav-li active";
                  }else{
                    $class="nav-li margin-left-0";
                  }

                  if($row["U_type"]=="link"){
                    $link=$row["U_link"];
                    $target="_blank";
                  }else{
                    $link="?type=".$row["U_type"]."&id=".$row["U_typeid"];
                    $target="_self";
                  }

                    $api=$api."<li class=\"drop-down\"><a style=\"padding-bottom: 15px;\" href=\"".$link."\" target=\"".$target."\" title=\"".$row["U_title"]."\">".$row["U_title"]."</a><ul class=\"drop-down-content\">";

                    $sql2="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=".$row["U_id"]." order by U_order,U_id desc";
                    s2[[
                      
                      if($row2["U_type"]=="link"){
                        $link2=$row2["U_link"];
                        $target="_blank";
                      }else{
                        $link2="?type=".$row2["U_type"]."&id=".$row2["U_typeid"];
                        $target="_self";
                      }
                            $api=$api."<li><a href=\"".$link2."\" target=\"".$target."\">".$row2["U_title"]."</a></li>";
                        ]]

$api=$api."</ul></li>";
                ]]

              </fh-function>
            </ul>
      </div>
  </div>
 
 </div>
</div>
</div>

<div class="yjcode">

  
 <div class="dqwz">
 <ul class="u1">
 <li class="l1">
 当前位置：<a href="./">首页</a> > <a href="?type=news&id=[S_id]">[S_title]</a> > <a href="">[N_title]</a> </li>
 </ul>
 </div>

<div class="newsmain">
 <!--左B-->
 <div class="left">
 <h1 class="titcap fontyh"><a name="tit">[N_title]</a></h1>
 <ul class="u1">
 <li class="l1">时间：[N_date] 作者： [N_author] 阅读：[N_view] <span id="collection_news" nid="[N_id]"></span></li>
 </ul>
 <div class="zytad"></div>
 <div class="ntxt">[N_content]
</div>
  
 
 <div class="nxg">
 上一篇：<a href='[N_Purl]'>[N_Ptitle]</a><br>
 下一篇：<a href='[N_Nurl]'>[N_Ntitle]</a> </div>

 </div>
 <!--左E-->
 
 <!--右B-->
 <div class="right">
<div class="nty">

    <fh-function>
      $U_id=getrs("select * from sl_menu where U_hide=0 and U_del=0 and U_type='news' and (U_typeid=$S_sub or U_typeid=$S_id)","U_id");
      $U_sub=getrs("select * from sl_menu where U_hide=0 and U_del=0 and U_type='news' and (U_typeid=$S_sub or U_typeid=$S_id)","U_sub");

      if($U_id!=""){
        if($U_sub==0){
              $sql="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=".$U_id;
            }else{
              $sql="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=".$U_sub;
            }
            
            s[[
              if($row["U_type"]=="text" && ($row["U_typeid"]==$S_sub || $row["U_typeid"]==$S_id)){
                $active="active";
              }else{
                $active="";
              }

              if($row["U_type"]=="link"){
                    $link=$row["U_link"];
                    $target="_blank";
                  }else{
                    $link="?type=".$row["U_type"]."&id=".$row["U_typeid"];
                    $target="_self";
                  }

                    $api=$api."<a href=\"".$link."\" target=\"".$target."\" title=\"".$row["U_title"]."\">".$row["U_title"]."</a> ";

                ]]
      }
        </fh-function>

  </div>
  <ul class="hotpro">
 <li class="l1">商品推荐</li>
<fh-function>
$sql="select * from sl_product where P_del=0 ".$M_pinfo."  and P_sh=1 order by P_top desc,P_id desc limit 5";
s[[

        $api=$api."<li class=\"l2\"><a href=\"?type=productinfo&id=".$row["P_id"]."\"><img alt=\"".$row["P_title"]."\" src=\"".pic(splitx($row["P_pic"],"|",0))."\" width=\"50\" height=\"50\" align=\"left\"></a><a href=\"?type=productinfo&id=".$row["P_id"]."\" title=\"".$row["P_title"]."\">".$row["P_title"]."</a><br><strong class=\"feng\">￥".p($row["P_price"])."</strong></li>";
    ]]
</fh-function>



  </ul> 

 
 <div class="hotnew">
 <ul class="u1 fontyh">
 <li class="l1">资讯排行榜</li>
 <li class="l2"><a href="?type=news&id=0">更多>></a></li>
 </ul>
 <ul class="u2">
<fh-function>
  $i=1;
$sql="select * from sl_news where N_del=0 ".$M_ninfo."  and N_sh=1 order by N_top desc,N_id desc limit 10";
s[[

        $api=$api."<li class=\"l1\" ><span class=\"s".$i."\">".$i."</span></li>
 <li class=\"l2\" style=\"white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    word-break: break-all;\"><a href=\"?type=newsinfo&id=".$row["N_id"]."\" class=\"g_ac0\" title=\"".$row["N_title"]."\">".$row["N_title"]."</a></li>";
 $i+=1;
    ]]
</fh-function>

  </ul>
 </div> </div>
 <!--右E-->

</div>

</div>

<div class="bfb bfbbottom">
<div class="yjcode">

 <div class="d1">
<ul class="u1">
<fh-function>
$sql="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=0 and not U_type='index' order by U_order,U_id desc";
s[[

  if($row["U_type"]=="link"){
    $link=$row["U_link"];
    $target="_blank";
  }else{
    $link="?type=".$row["U_type"]."&id=".$row["U_typeid"];
    $target="_self";
  }


     $api=$api."
  <li>
 <span><a href=\"".$link."\" target=\"".$target."\">".$row["U_title"]."</a></span>";

$sql2="select * from sl_menu where U_hide=0 and U_del=0 and U_sub=".$row["U_id"]." order by U_order,U_id desc";
s2[[

  if($row2["U_type"]=="link"){
    $link2=$row2["U_link"];
    $target2="_blank";
  }else{
    $link2="?type=".$row2["U_type"]."&id=".$row2["U_typeid"];
    $target2="_self";
  }

    $api=$api."<a href=\"".$link2."\" target=\"".$target2."\" class=\"a1\">".$row2["U_title"]."</a><br>";
  ]]
      $api=$api."
   </li>";
    ]]

</fh-function>


</ul>
 
  
 </div>
 
 <div class="d2">


 <strong>联系我们</strong><br>


 [fh_contact]

</div>
 
 <div class="d3">
<img src="media/[fh_qrcode]" width="100" height="100" /><br>二维码
  </div>
 
 <ul class="u2">
 <li class="l1">
[fh_copyright][fh_beian][fh_code]
 </li>
 <li class="l2">
  </li>
 </ul>
 
</div>
</div>

[fh_kefu]
</body>
</html>